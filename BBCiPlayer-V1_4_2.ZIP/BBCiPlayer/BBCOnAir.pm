package Plugins::BBCiPlayer::BBCOnAir;

# Plugin to play live and on demand BBC radio streams
# (c) Triode, 2007-2015, triode1@btinternet.com
#
# Released under GPLv2
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
#
# Module: BBCOnAir.pm
# Function: Experimental http polling to obtain on-air BBC radio programme
#           information, possibly with real-time track artist/title.
#           Based on code from RadioVis.pm.
# Created: 04/2015 by utgg
#

use strict;

use base qw(Slim::Utils::Accessor);

use Scalar::Util qw(weaken);

use Slim::Networking::Async;
use Slim::Utils::Errno;
use JSON::XS::VersionOneAndTwo;

use Slim::Utils::Log;
use Slim::Utils::Prefs;

__PACKAGE__->mk_accessor( rw   => qw(path session text) );
__PACKAGE__->mk_accessor( weak => qw(song) );

use constant POLL_INTERVAL => 30; # Polling interval in seconds

my $log   = logger('plugin.bbciplayer.bbconair');
my $prefs = preferences('plugin.bbciplayer');


sub new {
	my $ref   = shift;
	my $path  = shift;
	my $song  = shift;

	my $self = $ref->SUPER::new;

	$log->info("bbconair: " . $path);

	my $weakself = $self;
	weaken($weakself); # to ensure object gets destroyed as this is stored inside parser

	$self->session(int(rand(1000000)));
	$self->path($path);
	$self->song($song);

	# swap the lines functions for all synced players
	if (1) {
		for my $client ($song->owner->allPlayers) {

			$log->debug("storing lines functions for $client");

			my $info = $client->pluginData('bbconair') || {};

			$info->{'session'}  = $self->session;
			$info->{'custom'} ||= $client->customPlaylistLines;
			$info->{'lines2'} ||= $client->lines2periodic;

			$client->pluginData('bbconair', $info);

			$client->customPlaylistLines(\&ourNowPlayingLines);
			$client->lines2periodic(\&ourNowPlayingLines);

			if (Slim::Buttons::Common::mode($client) =~ /playlist|screensaver/) {
				# force our lines if already in Playlist display
				$client->lines(\&ourNowPlayingLines);
			}
		}
	}

	# set title for url in case getCurrentTitle is called (avoiding standardTitle as we mix up artist title etc)
	Slim::Music::Info::setCurrentTitle($song->can('streamUrl') ? $song->streamUrl : $song->{'streamUrl'}, $song->track->title);

   # Initial fetch - will poll at regular intervals thereafter
	$weakself->_fetchOnAir();

	return $self;
}

sub _fetchOnAir {
	my $self = shift;
	my $song = $self->song || return;

	if (!$song->owner->isPlaying && $song->pluginData('bbconair')) {
		# force destruction of bbconair object if no longer playing
		# but only after we've actually returned from new!
		$song->pluginData->{'bbconair'} = undef;
		return;
	}

	my $url = "http://polling.bbc.co.uk/modules/onairpanel/include/" . $self->path . ".json";

	$log->debug("Fetching $url");


	Slim::Networking::SimpleAsyncHTTP->new(
		\&_parseOnAir,
		sub {
			$log->warn("error fetching BBCOnAir data");
			# If http fails, poll doing nothing until the stream finishes
			# It's better than destroying our own object, as we'll just come back again!
			$self->_pollAfterError();
		},
		{
			cache   => 0, # disallow cacheing of responses
			obj     => $self,
		},
	)->get($url);
}

sub _parseOnAir {
	my $http = shift;
	my $self = $http->params('obj');
	my $song = $self->song || return;

	my $onairdata = eval { from_json($http->content) };

	if ( $@ || $onairdata->{error} ) {
		$log->warn("error parsing BBCOnAir json data" . $@ . $onairdata->{error});
		# If we get an error, poll doing nothing until the stream finishes
		# It's better than destroying our own object, as we'll just come back again!
		$self->_pollAfterError();
		return;
	}

	if (!$song->owner->isPlaying) {
		# force destruction of bbconair object if no longer playing
		$song->pluginData->{'bbconair'} = undef;
		return;
	}

	my $title = $onairdata->{nowTitle};
	my $info = $onairdata->{nowInfo};
	my $realtime = $onairdata->{realtime};

	# Update instantly. The 30s polling means timing won't be great anyway
	$log->info("displaying now: $title $info");

	$song->pluginData('track'  => $title);
	$song->pluginData('artist' => $info);
	$song->pluginData->{'info'} = undef; # need to do this to clear key

	# Save $info part into self->text for display on vfd display squeezeboxes
	$self->text($info);

	$song->owner->master->currentPlaylistUpdateTime(Time::HiRes::time());
	my $notify = Slim::Utils::Versions->compareVersions($::VERSION, "7.5") >= 0 ? [ 'newmetadata' ] : [ 'playlist', 'newsong' ];
	Slim::Control::Request::notifyFromArray($song->owner->master, $notify);

	# Simply update (as soon as we can) every 30 seconds or so
	Slim::Utils::Timers::setTimer($self, Time::HiRes::time() + POLL_INTERVAL, \&_fetchOnAir);
}

sub _pollAfterError {
	my $self = shift;
	my $song = $self->song || return;

	if (!$song->owner->isPlaying && $song->pluginData('bbconair')) {
		# force destruction of bbconair object if no longer playing
		# but only after we've actually returned from new!
		$song->pluginData->{'bbconair'} = undef;
		return;
	}

	Slim::Utils::Timers::setTimer($self, Time::HiRes::time() + POLL_INTERVAL, \&_pollAfterError);
}

sub ourNowPlayingLines {
	my $client = shift;
	my $args   = shift || {};

	if (!Slim::Buttons::Playlist::showingNowPlaying($client) && !$args->{'screen2'}) {
		# fall through to show other items in playlist
		return Slim::Buttons::Playlist::lines($client, $args);
	}

	my $parts;

	my $song = $client->streamingSong;

	if (!$args->{'trans'} && $song && $song->pluginData && (my $self = $song->pluginData->{'bbconair'})) {

		my ($complete, $queue) = $client->scrollTickerTimeLeft($args->{'screen2'} ? 2 : 1);
		my $title =  $client->streamingSong->track->title;
		my $ticker = $complete == 0 ? $self->text : "";

		if ($prefs->get('livetxt_classic_line') == 0) {
			# scrolling on top line
			$parts = {
				line    => [ undef, $title ],
				overlay => [ undef, $client->symbols('notesymbol') ],
				ticker  => [ $ticker, undef ],
			};
		} else {
			# scrolling on bottom line (normal scrolling line)
			$parts = {
				line    => [ $title, undef ],
				ticker  => [ undef, $ticker ],
			};

			$client->nowPlayingModeLines($parts);
		}

		# special cases for Transporter second display
		if ($args->{'screen2'}) {
			$parts = { screen2 => $parts };
		} elsif ($client->display->showExtendedText) {
			$parts->{'screen2'} = {};
		}

	} else {

		$parts = $client->currentSongLines($args);
	}

	return $parts;
}

sub DESTROY {
	my $self  = shift;
	my $path  = $self->path;

	$log->info("close: $path");

	for my $client (Slim::Player::Client::clients()) {

		my $info = $client->pluginData('bbconair');

		next unless $info && $info->{'session'} == $self->session;

		$log->debug("restoring lines functions for $client");

		# reset current lines if in playlist mode
		if (Slim::Buttons::Common::mode($client) =~ /playlist|screensaver/) {
			$client->lines($info->{'custom'} || \&Slim::Buttons::Playlist::lines);
		}

		$client->customPlaylistLines($info->{'custom'});
		$client->lines2periodic($info->{'lines2'});
	}
}

1;
