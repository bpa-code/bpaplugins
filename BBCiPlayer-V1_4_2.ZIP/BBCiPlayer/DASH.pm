package Plugins::BBCiPlayer::DASH;

# DASH protocol handler
#
# (c) Triode, 2015, triode1@btinternet.com, B. Alton
#
# Released under GPLv2
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

use strict;

use base qw(IO::Handle);

use Slim::Utils::Errno;
use Slim::Utils::Log;
use XML::Simple;
use HTTP::Date;
use URI;
use Plugins::BBCiPlayer::DashAsyncHTTP;
use Plugins::BBCiPlayer::DashUtils ;

use Data::Dumper;

use bytes;

use constant PRE_FETCH => 2; # number of chunks to prefetch

my $log = logger('plugin.bbciplayer.dash');

Slim::Player::ProtocolHandlers->registerHandler('dash', __PACKAGE__);

my $codecIds = {
	"mp4a.40.1" => "AAC",
	"mp4a.40.2" => "AAC LC",
	"mp4a.40.5" => "AAC SBR",
};

sub new {
	my $class = shift;
	my $args = shift;

	my $song     = $args->{'song'};
	my $url      = ($song->can('streamUrl') ? $song->streamUrl : $song->{'streamUrl'}) || $args->{'url'};
	my $seekdata = $song->can('seekdata') ? $song->seekdata : $song->{'seekdata'};
	my $start    = $seekdata->{'timeOffset'};

	if ($start) {
		if($song->can('startOffset')) {
			$song->startOffset($start);
		} else {
			$song->{startOffset} = $start;
		}
		$args->{'client'}->master->remoteStreamStartTime(Time::HiRes::time() - $start);
		
	}

	$url =~ s/^dash/http/;
	$url =~ s/\|$//;

	$log->debug("open $url $start");

	my $self = $class->SUPER::new;

	${*$self}{'song'} = $song;
	${*$self}{'_chunks'} = [];
	${*$self}{'_pl_noupdate'} = 0;
	${*$self}{'_played'} = 0;
	${*$self}{'_startoffset'} = $start if ($start) ;
	
	$self->_fetchMPD($url, $start);

	return $self;
}
#
#  Parse XSD Duration time 
#
#     PT0H3M1.63S
#
#   Only deal with Hours, Mins and secs ans return secs.
#
sub parse_duration {
    my $xsd_duration = shift;
    my ($neg, $year, $month, $day, $hour, $min, $sec, $fracsec);

    if ($xsd_duration =~ /^(-)?
                          P
                          ((\d+)Y)?
                          ((\d+)M)?
                          ((\d+)D)?
                          (
                          T
                          ((\d+)H)?
                          ((\d+)M)?
                          (((\d+)(\.(\d+))?)S)?
                          )?
                         $/x)
    {
        ($neg, $year, $month, $day, $hour, $min, $sec, $fracsec) =
        ($1,   $3,    $5,      $7,   $10,   $12,  $15,  $17);
        unless (grep {defined} ($year, $month, $day, $hour, $min, $sec)) {
            $log->error("Duration contained no duration ". $xsd_duration);
            return;
        }
    } else {
        $log->error( "Duration string does not match standard: ". $xsd_duration);
        return;
    }
    
    my $duration_secs = $hour * 3600 + $min * 60  + $sec  + "0.$fracsec";
    
    return $duration_secs;
}

sub _parseUTCTime {

	my $http = shift;
	my $self = $http->params('obj');
	my $url  = $http->params('url');
	my $xml       = $http->params('xml');
	my $mpd_url   = $http->params('mpd_url');
	my $start     = $http->params('start');
	my $refetch   = $http->params('refetch');

	$log->debug("Received content:" . $http->content);
	my ($year, $month, $day, $hour, $min, $sec, $tz) = HTTP::Date::parse_date($http->content);
	my $epochtime = str2time($http->content);
	$log->info("Parsed time epoch=$epochtime  y=$year m=$month d=$day h=$hour m=$min s=$sec z=$tz ");
	${*$self}{'_dash_utctime'} = $epochtime;

	$self->_parseMPD_part2($xml, $mpd_url, $start, $refetch);
}


sub _getUTCTime {
	my $self = shift;
	my $url  = shift;
	my $xml  = shift;
	my $mpd_url = shift;
	my $start   = shift;
	my $refetch = shift;
	
	$log->debug("fetch UTCTime: $url");

	Slim::Networking::SimpleAsyncHTTP->new(
		\&_parseUTCTime, 
		sub { 
			my $http  = shift;
			my $error = shift;
			my $error_url   = $http->url;
			$log->warn("error fetching time  $url");
			if ( $error =~ /^(Connect timed out)/i ) {
				$log->error("- DASH asynchttp failed Get from $error_url - $error  ");
			} else {
				$self->close;
			}
		}, 
		{ obj => $self, url => $url, xml => $xml, mpd_url => $mpd_url, start => $start, refetch =>  $refetch },
	)->get($url);
}	


sub _make_BaseUrl {

	my $mpdurl  = shift;
	my $baseurl = shift;
	
	if ($baseurl =~ /^http:\/\//) {
	  return $baseurl;
	}
	  
	my $url = URI->new_abs($baseurl,$mpdurl);

	return $url->canonical->as_string;
	
}

sub _calc_liveedge {
	
	my $fetch_time             = shift;
	my $availability_starttime = shift;
	my $segment_duration_secs  = shift;
	my $start_number		=    shift;
	
	my $live_edge              = $start_number + int(($fetch_time - $availability_starttime) / $segment_duration_secs);
	$log->debug ("Live edge value = $live_edge");

	return $live_edge;

}

sub _processInitUrlTemplate {
	my $seg_template          = shift;
	my $seg_representation_id = shift;

	my $rep_id_pat     = '\$RepresentationID\$';
	
	my $result = $seg_template;

    if ($seg_representation_id) {
		$result =~ s/$rep_id_pat/$seg_representation_id/g;
	}
	
	return $result;
		
}

sub _processUrlTemplate {
	my $seg_template          = shift;
	my $seg_representation_id = shift;
	my $seg_bandwidth         = shift; 
	my $seg_time              = shift;
	my $seg_number            = shift;
	
	my $result = $seg_template;
	my $value;
	
	my $rep_id_pat     = '\$RepresentationID\$';
	my $bandwidth_pat  = '\$Bandwidth\$';
	my $time_pat       = '\$Time\$';
	
    if ($seg_representation_id) {
		$result =~ s/$rep_id_pat/$seg_representation_id/g;
	}

    if ($seg_bandwidth) {
		$result =~ s/$bandwidth_pat/$seg_bandwidth/g;
	}

    if ($seg_time ) {
		$result =~ s/$time_pat/$seg_time/g;
    }
		
    if ($seg_number) {
		my $nstart = 0;
        while( 1 ) {
			$nstart = index($result,'$Number$', $nstart);
			if ($nstart == -1) {
				$nstart = index($result,'$Number%', $nstart);
				last if ($nstart == -1);
			}
						  
			my $nend = index($result,'$', $nstart+1) ;
            if ($nend >= 0){
                my $var = substr($result,$nstart+1,$nend - $nstart -1);

                if ($var =~ m/^Number%/ ) {
                    $value = sprintf(substr($var,6),(int($seg_number)));
				} else {
                    $value = $seg_number;
                }
                my $pat = '\$' . $var .'\$';
				$result =~ s/$pat/$value/;
			}
			$nstart = $nstart +1;
		}
    }          
    $result =~ s/\$\$/\$/g;
    
    return $result ;
}

sub _makeInitUrl {
	
	my $seg_template          = shift;
	my $seg_representation_id = shift;
	my $mpdurl  			  = shift;
	my $baseurl 			  = shift;

    my $result         = _processInitUrlTemplate ( $seg_template,$seg_representation_id);
	my $segmentbaseurl = _make_BaseUrl($baseurl,$mpdurl);
  
	$result = URI->new_abs($result,$segmentbaseurl);

	return $result->as_string;
	
}



sub _make_SegmentTemplatelist {

	my $seg_template          = shift;
	my $seg_representation_id = shift;
	my $seg_bandwidth         = shift; 
	my $seg_time              = shift;
	my $seg_number            = shift;
	my $mpdurl  			  = shift;
	my $baseurl 			  = shift;
	
	my $segmentbaseurl = _make_BaseUrl($baseurl,$mpdurl);

	my $result = _processUrlTemplate ( $seg_template,$seg_representation_id, $seg_bandwidth, $seg_time, $seg_number);

}


sub _UpdateChunkList {

	my $template 		        = shift @_;
	
	my $repId                  	= $template->{'representationId'};
	my $bandwidth               = $template->{'bandwidth'};
	my $media					= $template->{'media'};
	my $segmentbaseurl			= $template->{'segmentbaseurl'};
	my $currentNumber			= $template->{'currentNumber'};
	my $finalNumber				= $template->{'finalNumber'};
	
	my @chunklist;
	
	my $lastnum   = $currentNumber + $template->{'segmentquota'};
	$lastnum = $template->{'finalNumber'} if ($lastnum > $template->{'finalNumber'});
	
	for (my $segnum = $template->{'currentNumber'}; $segnum <= $lastnum; $segnum++){
		my $result    =  _processUrlTemplate ( $media ,$repId, $bandwidth, 0, $segnum);
		my $seg_url   = URI->new_abs($result,$segmentbaseurl)->as_string;
		push @chunklist, { url => $seg_url, chunknum => $segnum };
	}

	$template->{'currentNumber'} = $lastnum;
	
  return @chunklist;	
  
}	



sub _fetchMPD {
	my $self = shift;
	my $url  = shift;
	my $start= shift || 0;

	$log->info("fetch playlist: $url start: $start, refetch=" . ${*$self}{'_pl_refetch'});

	my $old_refetch = ${*$self}{'_pl_refetch'} ;
	${*$self}{'_pl_refetch'} = undef;	

#	 Slim::Networking::SimpleAsyncHTTP->new(

	Plugins::BBCiPlayer::DashAsyncHTTP->new(
		\&_parseMPD, 
		sub { 
			my $http  = shift;
			my $error = shift;
			my $error_url   = $http->url;
			$log->error("-----------------------  DASH asynchttp failed Get from $error_url - $error");		
			$log->warn("error fetching $url");
			if ( $error =~ /^(Connect timed out)/i ) {
				$log->error("----------------------- Matched - refetch=".$http->params('refetch'). " DASH asynchttp failed Get from $error_url - $error  ");
				${*$self}{'_pl_refetch'} = $http->params('refetch');
			} else {
				$self->close;
			}
		}, 
		{ obj => $self, url => $url, start => $start, cache => 0 , refetch => $old_refetch },
	)->get($url);
}


 sub _parseMPD {
	my $http = shift;
	my $self = $http->params('obj');
	my $url  = $http->params('url');
	my $start= $http->params('start');
	my $refetch = $http->params('refetch');

	my $mpd_url;
	if ($http->params('redirected')) {
		$log->error("\n Redirected ". $http->params('redirected') . "\n");
		$mpd_url = $http->params('redirected');
	} else {
		$mpd_url = $url;
	}
	
	my $is_debug = $log->is_debug;

	$is_debug && $log->debug("got: $url start: $start  refetch=$refetch");
	$log->error("got: $url start: $start  refetch=$refetch");

	my @lines = split(/\n/, $http->content);
	
	
	my $xml = eval {
		XMLin( 
			$http->contentRef,
			KeyAttr => [],
			ForceContent => 1,
			ForceArray => [ 'AdaptationSet', 'Representation', 'Period' ]
		)
	};

	if ($@) {
		$log->error("$@");
		$self->close;
		return;
	}
	$log->debug("DASH Content \n" . Dumper($xml)) ;

#
#  MPD type  Static is BBC Listen Again - Dynamic is "live"
#
    my $mpd_profiles = $xml->{'profiles'};
    if ( $mpd_profiles !~ /urn:dvb:dash:profile:dvb-dash:isoff-ext-live:2014/) {
		$log->error("Unsupported mpd profile: $mpd_profiles");
		return;
	} 

	if ($xml->{'UTCTiming'}) {
		if ($xml->{'UTCTiming'}->{'schemeIdUri'} eq "urn:mpeg:dash:utc:http-iso:2014") {
			$self->_getUTCTime($xml->{'UTCTiming'}->{'value'},$xml,$mpd_url,$start,$refetch);
			return;
		} else {
			$log->error("Unsupported time scheme ". $xml->{'UTCTiming'}->{'schemeIdUri'});
			return;
		}
	} 
	$self->_parseMPD_part2 ($xml, $mpd_url, $start, $refetch);
}
#
#   For static program MPD parsing parseMPd2 is called as part of parseMPD.  
#   For dynamic where there is a need to get the server time before processing can continue.
#   So parseMPD_part2 is called from the routine which receives the time.
#

sub _parseMPD_part2 {
	my $self      = shift;
	my $xml       = shift;
	my $mpd_url   = shift;
	my $start     = shift;
	my $refetch   = shift;

	my $minimumUpdatePeriod ;
	my $timeShiftBufferDepth ;
	my $mediaPresentationDuration ;
	my $maxSegmentDuration ;    
	my $minBufferTime  ;     

	my $availabilityStartTime = HTTP::Date::str2time($xml->{'availabilityStartTime'});

    my $mpd_dynamic = (defined($xml->{'type'})) && ($xml->{'type'} eq 'dynamic') ;

	
    if ($mpd_dynamic)  { 
		$minimumUpdatePeriod       = parse_duration($xml->{'minimumUpdatePeriod'});
		$maxSegmentDuration        = parse_duration($xml->{'maxSegmentDuration'});
		$minBufferTime             = parse_duration($xml->{'minBufferTime'});
		$timeShiftBufferDepth      = parse_duration($xml->{'timeShiftBufferDepth'});
		${*$self}{'_dash_type'}    = 'dynamic' ;
	} else {
		$mediaPresentationDuration = parse_duration($xml->{'mediaPresentationDuration'}) ;
		$maxSegmentDuration        = parse_duration($xml->{'maxSegmentDuration'}) ;
		$minBufferTime             = parse_duration($xml->{'minBufferTime'}) ;
		$log->error(" media presentation duration = $mediaPresentationDuration  secs");      
		${*$self}{'_dash_type'}    = 'static' ;
#		${*$self}{'_pl_noupdate'}  = 1;
		${*$self}{'song'}->duration(int($mediaPresentationDuration));
	}
    
    
    $log->error("maxSegmentationDuration=$maxSegmentDuration      minbufferTime=$minBufferTime");
    $log->error("No of Period = ". scalar(@{$xml->{'Period'}})) ;
    if (scalar(@{$xml->{'Period'}}) != 1) {
		$log->error("Plugin currently support mpd with only one period.  Periods in this mpd  = ". scalar(@{$xml->{'Period'}}));
	} ;
	
    my $adaptationSet = $xml->{'Period'}[0]->{'AdaptationSet'} ; 
#    $log->error("AdaptationSet=" . Dumper($adaptationSet));
    
    my @reps =();
    
    foreach my $adaptation (@$adaptationSet) {
		
		if (($adaptation->{'contentType'} == 'audio'    ) 
		    && ($adaptation->{'mimeType'}    == 'audio/mp4') 
		    && ($codecIds->{$adaptation->{'codecs'}}         ) 
			) {
			
			foreach my $representation (@{$adaptation->{'Representation'}}) {
				push (@reps,{'id'             => $representation->{'id'}, 
				             'bandwidth'      => $representation->{'bandwidth'}, 
				             'representation' => $representation, 
				             'adaptation'     => $adaptation,
				             'period'         => 0});
			}
	    }
	}
	
#
#  Choose a representation
#
    my $select_rep = $reps[0];
    
    foreach my $rep (@reps) {
		if ($rep->{'bandwidth'} > $select_rep ->{'bandwidth'}) {
			$select_rep = $rep;
		}
	} 
	$log->info(' Chosen rep id '. $select_rep->{'id'} . 
	           ' Bandwidth = '  . $select_rep->{'bandwidth'});
	           
#
#  make up URL from Template and Base.
#
    my $baseUrl ;
    if    (defined($select_rep->{'representation'}->{'BaseURL'}->{'content'})) {
		$baseUrl = $select_rep->{'representation'}->{'BaseURL'}->{'content'} ;
	}
	elsif (defined($select_rep->{'adaptation'}->{'BaseURL'}->{'content'})) {
		$baseUrl = $select_rep->{'adaptation'}->{'BaseURL'}->{'content'} ;
	}
	elsif (defined($xml->{'Period'}[0]->{'BaseURL'}->{'content'})) {
		$baseUrl = $xml->{'Period'}[0]->{'BaseURL'}->{'content'};
	}
	elsif (defined($xml->{'BaseURL'}->{'content'})) {
		$baseUrl = $xml->{'BaseURL'}->{'content'}
	}	
	else {
		$log->error(" No BaseURL definition found");
	}
	
    $log->error("Before Baseurl = $baseUrl" ); 
    
    $baseUrl = _make_BaseUrl($mpd_url,$baseUrl);
    
    $log->error("After Baseurl = $baseUrl" ); 
#
#  This is BBC - assume only SegmentTemplate in Adaptation Set
#   
    my $segment_template ; 
    if ( defined($select_rep->{'adaptation'}->{'SegmentTemplate'})) {
		$segment_template = $select_rep->{'adaptation'}->{'SegmentTemplate'};
	} else { 
		$log->error(" No expected SegmentTemple in Adaptation Set in rep id ".$select_rep->{'id'});
		return;

    }
	my $seg_representation_id = $select_rep->{'id'} ;
    my $segment_number = $segment_template->{'startNumber'} ;
	my $init_url       = $segment_template->{'initialization'} ;
	my $media_url      = $segment_template->{'media'} ;
	
	${*$self}{'_dash_template'} = {
		'startNumber'			=> int($segment_template->{'startNumber'}), 
		'initialization'		=> $segment_template->{'initialization'},
		'media'					=> $segment_template->{'media'},
		'segmentDuration'		=> $segment_template->{'duration'} ,
		'timescale'				=> $segment_template->{'timescale'} ,
		'bandwidth'				=> $select_rep->{'bandwidth'},
		'representationId'		=> $select_rep->{'id'},
		'availabilitystarttime' => $availabilityStartTime,
		'minimumUpdatePeriod'	=> $minimumUpdatePeriod,
		'timeShiftBufferDepth'	=> $timeShiftBufferDepth,
		'minBufferTime'			=> $minBufferTime ,
		'mediaPresentationDuration' => $mediaPresentationDuration,
		'baseurl'				=> $baseUrl,

	};

	my @chunks = ();

    my $result         = _processInitUrlTemplate ( $segment_template->{'initialization'},$seg_representation_id);
	my $init_url       = URI->new_abs($result,$baseUrl)->as_string;
	${*$self}{'_dash_template'}->{'initurl'} = $init_url;
	
 	push @chunks, { url => $init_url, chunknum => 0 };

#
#   Time to process template for main body - only create a short playlist - add more when needed
#

#  How many segment in whole program
	my $segment_duration_secs  =  $segment_template->{'duration'} / $segment_template->{'timescale'}  ;

#   Create a list of duration larger of either 60 secs(1 mins) or minbuffertime
	my $num_segments  = int($mediaPresentationDuration / $segment_duration_secs) +1  ;
	my $segment_quota = int(($minBufferTime / $segment_duration_secs )) +1 ;
	if ( !$mpd_dynamic && (60 > $minBufferTime) ) {
		$segment_quota = int (60/ $segment_duration_secs);
	}
	if (defined(${*$self}{'_startoffset'})) {
		my $segmentsoffset = int(${*$self}{'_startoffset'} / $segment_duration_secs);
		${*$self}{'_dash_template'}->{'currentNumber'}    = int($segment_template->{'startNumber'}) + $segmentsoffset;
	} else {
		${*$self}{'_dash_template'}->{'currentNumber'}    = int($segment_template->{'startNumber'});
	}
	if ( $mpd_dynamic) {
		${*$self}{'_dash_template'}->{'currentNumber'}    = _calc_liveedge (${*$self}{'_dash_utctime'}, 
																			$availabilityStartTime,$segment_duration_secs, 
																			$segment_template->{'startNumber'}) -4;
		$num_segments = ${*$self}{'_dash_template'}->{'currentNumber'} + 5000000; # make live stream play a long time.
	}
	
	$log->info(" Starting Current number ". ${*$self}{'_dash_template'}->{'currentNumber'} . " start number ". int($segment_template->{'startNumber'}));
	${*$self}{'_dash_template'}->{'segmentquota'}     = int($segment_quota) ;
	${*$self}{'_dash_template'}->{'finalNumber'}      = int($num_segments);
	${*$self}{'_dash_template'}->{'representationId'} = $seg_representation_id;
	${*$self}{'_dash_template'}->{'bandwidth'}        = $select_rep->{'bandwidth'};
	${*$self}{'_dash_template'}->{'media'}            = $segment_template->{'media'};
	${*$self}{'_dash_template'}->{'segmentbaseurl'}   = $baseUrl;
	
	
	my $stream = ${*$self}{'song'}->streamUrl;
	my $track  = Slim::Schema::RemoteTrack->fetch($stream);
	$track->bitrate($select_rep->{'bandwidth'});

	push @chunks, _UpdateChunkList(${*$self}{'_dash_template'});
	$log->debug(" After Update list  Chunks ". Dumper(@chunks). "\n template ". Dumper(${*$self}{'_dash_template'}));
	
	if (scalar (@chunks) > 0 ) {
		${*$self}{'_chunks'} = \@chunks;

		for my $i(0 .. PRE_FETCH) {
			$self->_fetchChunk($chunks[$i]) if $chunks[$i];
		}
		${*$self}{'song'}->owner->master->currentPlaylistUpdateTime(Time::HiRes::time());
	}

	if (!${*$self}{'_pl_noupdate'}) {
		${*$self}{'_pl_refetch'} = time() + 10;
		$log->debug("refetch time ". ${*$self}{'_pl_refetch'} );		
		${*$self}{'_pl_url'}  = $mpd_url;
	}
}

sub _fetchChunk {
	my $self  = shift;
	my $chunk = shift;

	if (my $url = $chunk->{'url'}) {
		$log->debug("fetching [$chunk->{chunknum}]: $url");
		$chunk->{'fetching'} = 1;
		Slim::Networking::SimpleAsyncHTTP->new(
			sub {
				$log->is_debug && $log->debug("got [$chunk->{chunknum}] size " . length($_[0]->content));
				delete $chunk->{'fetching'};
				$chunk->{'chunkref'} = $_[0]->contentRef;
			},
			sub { 
				$log->warn("error fetching [$chunk->{chunknum}] $url");
				delete $chunk->{'fetching'};
			}, 
		)->get($url);
	}
}

sub isRemote { 1 }

sub isAudio { 1 }

sub canSeek {
	my ($class, $client, $song) = @_;

	return $song->duration ? 1 : 0;
}

sub getSeekData {
	my ($class, $client, $song, $newtime) = @_;
	
	return { timeOffset => $newtime };
}

sub contentType { 'aac' }

sub formatOverride { 'aac' }

sub getIcon {
	my ($class, $url) = @_;

	my $handler;

	if ( ($handler = Slim::Player::ProtocolHandlers->iconHandlerForURL($url)) && ref $handler eq 'CODE' ) {
		return &{$handler};
	}
	
	return Plugins::BBCiPlayer::Plugin->_pluginDataFor('icon');
}

sub close {
	my $self = shift;
	${*$self}{'_close'} = 1;
}

sub sysread {
#
# $self                        = $_[0] 
# where data is to be returned = $_[1]
# count of max bytes           = $_[2]
# offset into $_[1]            = $_[3]
#  
	
	my $self  = $_[0];
	my $maxBytes = $_[2];
    my $offset = $_[3] || 0;


	if (${*$self}{'_close'}) {
		$log->debug("closing");
		return 0;
	}
	my $chunks = ${*$self}{'_chunks'};
	my $chunkref;
	my $ret = 0;

	if (!defined(${*$self}{'_dash_type'} )) {
		$log->info("MPD not received - no DASH type defined");
		$! = EINTR;
		return undef;
	}
	
	$log->info("sysread - checking chunks : " . scalar @$chunks .  "played :" .${*$self}{'_played'} );
#
# Check if any chunks need to be converted from MPEG4 to ADTS to stream to SBs.
#	
	if (scalar @$chunks) {
		my %dashfile;
		if ($chunks->[0]->{'chunkref'}) {
			%dashfile = Plugins::BBCiPlayer::DashUtils::parseMpeg4(${$chunks->[0]->{'chunkref'}});
			
			if ((defined($dashfile{'ftyp'}))&& ($dashfile{'ftyp'}->{'brand'} eq 'iso6')){
			
				$log->info( "Got ftyp dash Compatible brand=". $dashfile{'ftyp'}->{'compatible_brands'}[1]);
				${*$self}{'_dash_mp4esds'} = $dashfile{'moov'}->{'trak'}->{'mdia'}->{'minf'}->{'stbl'}->{'stsd'}->{'entries'}->{'mp4a'}->{'esds'};		
				my $played = shift @$chunks;
				${*$self}{'_played'} = $played->{'chunknum'};
				$log->is_info && $log->info("played [$played->{chunknum}]");
				$! = EINTR;
				return undef;
			} elsif ( (defined($dashfile{'moof'}))) {
					$chunks->[0]->{'adtschunkref'} = Plugins::BBCiPlayer::DashUtils::convertDashSegtoADTS(${*$self}{'_dash_mp4esds'},$dashfile{'mdat'}->{'data'}, 
								$dashfile{'moof'}->{'traf'}->{'trun'}); 
					$chunkref = $chunks->[0]->{'adtschunkref'};
					$log->debug("adts converted length ". length($chunkref));
								
			} else {
				$log->error("Unexpected segment type  length chunkref ". 
					length(${$chunks->[0]->{'chunkref'}}) . "\n". Dumper($chunks->[0]));
				return 0;
			}
		}
	} elsif ( ${*$self}{'_played'} == ${*$self}{'_dash_template'}->{'finalNumber'}) {
			
		$log->debug("No more chunks left closing: last played " . 
		               ${*$self}{'_played'} . " last chunk num ". ${*$self}{'_dash_template'}->{'finalNumber'});
		return 0;
	} else {
		$log->debug("Last else chunks left". scalar(@$chunks). " last played " . 
		               ${*$self}{'_played'} . " last chunk num ". ${*$self}{'_dash_template'}->{'finalNumber'});
		
	}
#
#  Finally - service the sysread with data. 
#	
	if ($chunkref) {
		$_[1] = "";
		my $nextpos = $chunks->[0]->{'nextpos'} ||= 0;
		
#
#  Loop while still unused data in  current chunk and requestor needs more data
#

		if ($nextpos <= length($chunkref) && length($_[1]) < $maxBytes ) {
			my $availbytes = (length($chunkref) - $nextpos);
			$availbytes = $maxBytes if ($availbytes > $maxBytes); 
			$_[1] .= substr($chunkref, $nextpos, $availbytes);
			$nextpos += $availbytes;
			$ret  = $availbytes;
			$log->debug ("sysread - returned $availbytes bytes - requested $maxBytes  nextpos =$nextpos length ". length($chunkref));
		}
#
#  Check to see if current chunk all used up
#
		if ($nextpos >= length($chunkref)) {
			my $played = shift @$chunks;
			${*$self}{'_played'} = $played->{'chunknum'};
			$log->is_info && $log->info("played [$played->{chunknum}]");
		} else {
			$chunks->[0]->{'nextpos'} = $nextpos;
			$log->debug ("sysread - update chunknum " . $chunks->[0]->{'chunknum'} . "  nextpos set to $nextpos");
		}
	}

#
#  Add more chunk to playlist - if count below x ) 

	if ( (${*$self}{'_dash_template'}->{'currentNumber'} < ${*$self}{'_dash_template'}->{'finalNumber'}) &&
		(scalar(@$chunks) < ${*$self}{'_dash_template'}->{'segmentquota'})) {

		${*$self}{'_dash_template'}->{'currentNumber'} ++;
		push @$chunks, _UpdateChunkList(${*$self}{'_dash_template'});
		$log->info(" After sysread Update list  Chunks length". scalar(@$chunks). "\n template ". Dumper(${*$self}{'_dash_template'}));
	}	
			
	if (${*$self}{'_pl_refetch'} && time() > ${*$self}{'_pl_refetch'}) {
		$log->error(" ---------------------------------- refetch due time= ". time() . "   scheduled=". ${*$self}{'_pl_refetch'} );
		${*$self}{'_pl_refetch'} = time() +  10;
	}

	# fetch more chunks
	for my $i (0 .. PRE_FETCH) {
		my $new = $chunks->[$i];
		if ($new && !$new->{'chunkref'} && !$new->{'fetching'}) {
			$self->_fetchChunk($new);
			last;
		}
	}

	$log->debug(" DASH sysread returning $ret (" . length( ) .")  utc time=". ${*$self}{'_dash_utctime'} );	
	return $ret if $ret;

	# otherwise come back later - use EINTR as we don't have a file handle to put on select
	$! = EINTR;
	return undef;
}

1;
