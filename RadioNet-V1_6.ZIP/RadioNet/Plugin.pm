package Plugins::RadioNet::Plugin;

# Plugin to get station from Radio,net
#
# Released under GPLv2

use strict;

use base qw(Slim::Plugin::OPMLBased);


use File::Spec::Functions qw(:ALL);
use File::Slurp qw(read_file);
use Plugins::RadioNet::Settings;
use Slim::Utils::Prefs;

use Data::Dumper;

my $prefs = preferences('plugin.radionet');

my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.radionet',
	'defaultLevel' => 'ERROR',
	'description'  => getDisplayName(),
});

my @opmlfiles = ('menu-en.opml', 'menu-pt.opml', 'menu-pt-br.opml', 
				 'menu-it.opml', 'menu-se.opml', 'menu-fr.opml', 
				 'menu-es.opml', 'menu-es-mx.opml', 'menu-es-co.opml', 
				 'menu-de.opml', 'menu-de-at.opml', 'menu-pl.opml', 
				 'menu-dk.opml'); 

my @radionetdomains  = ('https://www.radio.net', 'https://www.radio.pt', 'https://br.radio.net', 
				 'https://www.radio.it', 'https://www.radio.se', 'https://www.radio.fr', 
				 'https://www.radio.es', 'https://mx.radio.net', 'https://co.radio.net', 
				 'https://www.radio.de', 'https://www.radio.at', 'https://www.radio.pl', 
				 'https://www.radio.dk'); 

sub getCanonicalDomain {
	
	my $pagedata = shift;
	
#	$log->debug(Dumper($pagedata));
	
	my $canonical_domain;

	if      (defined($pagedata->{'canonicalDomain'}) ) {
		$canonical_domain = $pagedata->{'canonicalDomain'};	
	} elsif (defined($pagedata->{'DOMAIN'}) ) {
		$canonical_domain = $pagedata->{'DOMAIN'};	
	} else {  # Only do this when web page has probably changed and so need updating
		$log->error(" Canonical Domain is not defined in Radio.net web page - plugin should be updated");
		$canonical_domain  = $radionetdomains[$prefs->get('radionetlocale')];;
	}

# Just in case https has been left off in a change
	$canonical_domain = 'https://'. $canonical_domain unless ($canonical_domain =~ m/^http(s?):\/\//i ) ;
	$log->debug(" Canonical domain $canonical_domain"); 

	return $canonical_domain;		
}	

sub initPlugin {
	my $class = shift;

	Plugins::RadioNet::Settings->new($class);
	Plugins::RadioNet::Settings->init($class);

	$class->SUPER::initPlugin(
		feed   => \&handleFeed,
		tag    => 'radionet',
		is_app => $class->can('nonSNApps') && $prefs->get('is_app') ? 1 : undef,
		menu   => 'radios',
		weight => 1,
	);

	Plugins::RadioNet::Settings->new;
}

sub handleFeed {
	my ($client, $cb, $params, $args) = @_;
	my $feed;
	
	my $fullfile = catdir( Plugins::RadioNet::Plugin->_pluginDataFor('basedir')
						  , $opmlfiles[$prefs->get('radionetlocale')] );
	
	$log->info(" Locale ". $prefs->get('radionetlocale') .  " file  $fullfile");
	
	my $content = eval { read_file($fullfile) };
	
	if ( $content ) {
		$feed = eval { Slim::Formats::XML::parseXMLIntoFeed(\$content) };
	} else {
		$log->error( "Unable to open file '$fullfile'");
	}

	$cb->({
		items  => $feed->{'items'},
	});
}

sub getDisplayName { 'PLUGIN_RADIONET' }

sub playerMenu { shift->can('nonSNApps') && $prefs->get('is_app') ? undef : 'RADIO' }

1;
