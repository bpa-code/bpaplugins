package Plugins::RadioNet::Settings;

use strict;
use base qw(Slim::Web::Settings);

use Slim::Utils::Prefs;
use Slim::Utils::Log;

use Data::Dumper;


my $prefs = preferences('plugin.radionet');
my $log = logger('plugin.radionet');

my @radionetdomain = ('api.radio.net', 'api.radio.pt', '??api-pt-br', 
						'api.radio.it', 'api.radio.se', 'api.radio.fr', 
						'api.radio.es', '??api-es-mx', '??api-es-co', 
						'api.radio.de', 'api.radio.at', 'api.radio.pl', 
						'api.radio.dk'); 
				 
my @apilanguages = ('en-US', 'pt-PT', 'pt-BR' , #  pt-br es-co.opml' 'menu-es-mx.opml'
				 'it-IT', 'sv-SE', 'fr-FR', 
				 'es-ES', 'es-MX', 'es-CO', 
				 'de-DE', 'de-AT', 'pl-PL', 
				 'dk-DK'); 

# Also NL, UK, IE, ZA, AU, CA and NZ

sub getlocaledomain {
	return $radionetdomain[$prefs->get('radionetlocale')];
}


sub init {
	$prefs->set('radionetlocale', 0)  unless (defined($prefs->get('radionetlocale')));
	$prefs->set('radionettoplimit', 20)  unless (defined($prefs->get('radionettoplimit')));
	$prefs->set('radionetcategorylimit', 200)  unless (defined($prefs->get('radionetcategorylimit')));

# Set locale to default if locale setting is not valid (API domain for some countries is TBD).
	$log->error('Locale setting - no valid domain '. getlocaledomain(). '  '.$prefs->get('radionetlocale')) if (getlocaledomain() =~ m/^\?\?/) ;
	$prefs->set('radionetlocale', 0) if (getlocaledomain() =~ m/^\?\?/) ;
}

sub name {
	return 'PLUGIN_RADIONET';
}

sub page {
	return 'plugins/RadioNet/settings/basic.html';
}

sub prefs {
	return (preferences('plugin.radionet'), qw( prefFormat is_app radionetlocale radionetcategorylimit radionettoplimit));
}

sub beforeRender {
	my $class = shift;
	my $params= shift;

#   Fix - show_app had output from "can" function which was a code reference 
#   which it seems was executed in Template and not just treated as a value.
	$params->{'show_app'} = Slim::Plugin::Base->can('nonSNApps') ? 1 : 0 ;

}

sub handler {
	my ($class, $client, $params) = @_;

	my $currentlocale = $prefs->get('radionetlocale');

	my $ret = $class->SUPER::handler($client, $params);

# If locale has changed - then genrete the top level menus.
	if ($params->{'saveSettings'} && ($params->{'pref_radionetlocale'} != $currentlocale)) {
			$log->error(" New locale ". $params->{'pref_radionetlocale'} . " and prefs ".$prefs->get('radionetlocale'));
			Plugins::RadioNet::Plugin::makeCountryMenu();
			Plugins::RadioNet::Plugin::makeGenreMenu();
			Plugins::RadioNet::Plugin::makeTopicMenu();
	}
	return $ret;
}


1;
