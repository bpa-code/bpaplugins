package Plugins::RadioNet::Plugin;

# Plugin to get station from Radio,net
#
# Released under GPLv2

use strict;

use base qw(Slim::Plugin::OPMLBased);

use File::Spec::Functions qw(:ALL);
use File::Slurp qw(read_file);
use MyText::Balanced;
use JSON::XS::VersionOneAndTwo;
use Digest::MD5 qw(md5_hex);
use URI::Escape;

use Slim::Utils::Log;
use Slim::Utils::Cache;
use Slim::Utils::Prefs;

use Plugins::RadioNet::Settings;

use Data::Dumper;


my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.radionet',
	'defaultLevel' => 'ERROR',
	'description'  => getDisplayName(),
});

my $prefs = preferences('plugin.radionet');


# The API key is assumed to be the same for for all users.

my $apikey = '';

# Initialise some global variables to make sure they have default values.

my $apilocaledomain   = 'api.radio.net';
my $topMenuLimit      = 20;
my $categoryMenuLimit = 200;

# short lists are in SystemEnglish (i.e. domain independent key) and not localised form.

my @shortlistgenres = ('80s','90s','Alternative','Blues','Chillout','Classical','Classic Rock',
						'Country','Electro','HipHop','Hits','House','Jazz','Latin','Oldies','Podcast','Pop',
						'Rock',"R'n'B",'Ska','Soul','Swing','Top 40 & Charts','Urban');
						
my @shortlisttopics =	(	'Summer/Holiday','News','Culture','Sports & Recreation','Politics','Religion','Language Courses',
							,'Children','DJ','Comedy','Society','Campus Radio','Interview','People','Christmas',
							,'Knowledge','Economy','Music','Education');

my @countriescitymenu; # Country list is fetched in initplugin and this menu is populated.
my @countriesrankmenu; # Country list is fetched in initplugin and this menu is populated.
my @genresmenu;        # Genres list is fetched in initplugin and this menu is populated with list and shortlist above.
my @topicsmenu;        # Topics list is fetched in initplugin and this menu is populated with list and shortlist above.

my $pluginName = 'radionetV2';
my $topTenStations;
my $genreShortlist;
my $topTopics;

use constant CACHEONEHOUR    =>  3600; 
use constant CACHETHREEHOURS => 10800; 
my $cache = Slim::Utils::Cache->new();

$cache->clear();


sub getCachedMenu {
	my $url = shift;

	my $cacheKey = $pluginName . ':' . md5_hex($url);

	if ( my $cachedMenu = $cache->get($cacheKey) ) {
		my $menu = ${$cachedMenu};
		return $menu;
	};
	return;
}

sub cacheMenu {
	my ( $url, $menu, $seconds ) = @_;	

	my $cacheKey = $pluginName . ':' . md5_hex($url);
	$cache->set( $cacheKey, \$menu, $seconds );

	return;
}

sub fixupCodeRefs {
	my $menu = shift;

	my %subItems = (
	'getCityByCountry'	 => \&getCityByCountry,
	'getByCountry'		 => \&getByCountry,
	'getbyGenres'   	 => \&getbyGenres,
	'getGenreStations' 	 => \&getGenreStations,
	'getCountryStations' => \&getCountryStations,
	'getCityStations'	 => \&getCityStations,
	'getTopicStations'   => \&getTopicStations,
	'getEditorsPicks' 	 => \&getEditorsPicks,
	'getNearYou' 		 => \&getNearYou,
	'getSearch'  		 => \&getSearch,
	'getStationById'	 => \&getStationById,
	'getTopStations' 	 => \&getTopStations
	);

	for my $menuItem (@$menu) {
		my $codeRef = $menuItem->{passthrough}[0]->{'codeRef'};
		if ( defined $codeRef ) {
			$log->error("Fixup failed for undefined routine: $codeRef ") unless (exists($subItems{$codeRef}));
			$menuItem->{'url'} = $subItems{$codeRef};
		}

		fixupCodeRefs($menuItem->{'items'}) if (defined $menuItem->{'items'}) ;
	}
	return;
}

sub initPlugin {
	my $class = shift;

	Plugins::RadioNet::Settings->new($class);
	Plugins::RadioNet::Settings->init($class);
	
	$class->SUPER::initPlugin(
		feed   => \&handleFeed,
		tag    => 'radionet',
		is_app => $class->can('nonSNApps') && $prefs->get('is_app') ? 1 : undef,
		menu   => 'radios',
		weight => 1,
	);

# Get APIkey
	my $sourceurl = 'http://www.radio.net';
	Slim::Networking::SimpleAsyncHTTP->new(
		sub { 						# Success - page fetched.
			my $http = shift;
			# extract current apikey - it follows the "apiKey : " text.
			my ($before, $after) = split ('apiKey: ',$http->content,2);
			$apikey = $1 if ($after =~ m/'(.*?)'/);  # extract the key
				
			$log->info("Radio.net apiKey=$apikey");
			
#  Get Other stuff from page
			($before, $after) = split (/\Qwindow.__CONTEXT_PROVIDER__ = \E/,$http->content,2);
			my 	@result = MyText::Balanced::extract_bracketed( $after, '{"}' );
			my 	$jsondata = eval { from_json($result[0]) };

			if ($@) {
					$log->error("Error parsing JSON data $@");
					return;
			};
			
# Keys available
# isStationPage,isStationSubpage,DOMAIN_ENVIRONMENT,languageShortlist,isNotFoundError,isPodcastPage,appVersion,countryShortlist,withPhrase,DOMAIN,seoText,originalUrl,popularSearches,topTenStations
# topicShortlist,christmasStations,editorsPicks,genreShortlist,topTenStations
#
#			$topTenStations = $jsondata->{'data'}->{'topTenStations'};
#			$genreShortlist = $jsondata->{'data'}->{'genreShortlist'};
#			$topicShortlist = $jsondata->{'data'}->{'topicShortlist'};

			makeCountryMenu();
			makeGenreMenu();
			makeTopicMenu();
		},
		sub { # Page fetch error 
			my $http = shift;
			my $error  = $http->error;			
			$log->error(" Failed to get initial page from Radio.net - fetch apikey error: $error");
			$apikey = '';
		}
	)->get($sourceurl);

	Plugins::RadioNet::Settings->new;
}

sub makeCountryMenu {

	$apilocaledomain = Plugins::RadioNet::Settings::getlocaledomain();
	my $sourceurl = "https://$apilocaledomain/info/v2/search/getcountries?apiKey=$apikey";
	Slim::Networking::SimpleAsyncHTTP->new(
		sub { 						# Success - page fetched.
			my $http = shift;
			
			my $countrieslist = eval { from_json($http->content) };
	
			if ($@) {
				$log->error("Error parsing JSON data $@");
				return;
			}
			
			@countriescitymenu = undef;
			my $icon = Plugins::RadioNet::Plugin->_pluginDataFor('icon');
			foreach my $country (@{$countrieslist}) {
				push @countriescitymenu, {
				'name'	      => $country->{'localized'},
#				'image'		  => $icon,
				'url'         => \&getCityByCountry,
				'type'        => 'link',	
				'passthrough' => [ { 'categorykey' => URI::Escape::uri_escape_utf8($country->{'systemEnglish'}),
									  'codeRef'     => 'getCityByCountry' }	],
				};
			};
			
			@countriesrankmenu = undef;
			my $icon = Plugins::RadioNet::Plugin->_pluginDataFor('icon');
			foreach my $country (@{$countrieslist}) {
				push @countriesrankmenu, {
				'name'	      => $country->{'localized'},
#				'image'		  => $icon,
				'url'         => \&getCountryStations,
				'type'        => 'link',	
				'passthrough' => [ { 'categorykey' => URI::Escape::uri_escape_utf8($country->{'systemEnglish'}),
									  'codeRef'     => 'getCountryStations' }	],
				};
			};
			
		},
		sub { # Page fetch error 
			my $http = shift;
			my $error  = $http->error;			
			$log->error(" Failed to get countries page from Radio.net - fetch error: $error");
		}
	)->get($sourceurl);	
}

sub makeGenreMenu {
	
	$apilocaledomain = Plugins::RadioNet::Settings::getlocaledomain();
	my $sourceurl = "https://$apilocaledomain/info/v2/search/getgenres?apiKey=$apikey";
	Slim::Networking::SimpleAsyncHTTP->new(
		sub { 						# Success - page fetched.
			my $http = shift;
			
			my $genreslist = eval { from_json($http->content) };
	
			if ($@) {
				$log->error("Error parsing JSON data $@");
				return;
			}
			
# Make up lookup hash of system name to localise name so that short list Genres can be built.

			my %localName = map { $_->{'systemEnglish'} => $_->{'localized'} } @{$genreslist};
			@genresmenu = undef;
		
			my $icon = Plugins::RadioNet::Plugin->_pluginDataFor('icon');

			foreach my $genrename (@shortlistgenres) {
				push @genresmenu, {
				'name'	      => $localName{$genrename},
#				'image'		  => $icon,
				'url'         => \&getGenreStations,
				'type'        => 'link',	
				'passthrough' => [ {'categorykey' => URI::Escape::uri_escape_utf8($genrename),
									'codeRef'     => 'getByGenres'}	],
				};
			};

# Make up the full genres sub menu 
			my @genreSubMenu;
			foreach my $genre (@{$genreslist}) {
				push @genreSubMenu, {
				'name'	      => $genre->{'localized'},
#				'image'		  => $icon,
				'url'         => \&getGenreStations,
				'type'        => 'link',	
				'passthrough' => [ {'categorykey' => URI::Escape::uri_escape_utf8($genre->{'systemEnglish'}),
									'codeRef'     => 'getByGenres'}	],
				};
			}	

# Combine submenu in with short menu.
			push @genresmenu, {
				'name'	      => 'All Genres',
#				'image'		  => $icon,
				'items'		  => \@genreSubMenu
			};
		},
		sub { # Page fetch error 
			my $http = shift;
			my $error  = $http->error;			
			$log->error(" Failed to get genres list from Radio.net - fetch error: $error");
		}
	)->get($sourceurl);	
}


sub makeTopicMenu {

	$apilocaledomain = Plugins::RadioNet::Settings::getlocaledomain();
	my $sourceurl = "https://$apilocaledomain/info/v2/search/gettopics?apiKey=$apikey";
	Slim::Networking::SimpleAsyncHTTP->new(
		sub { 						# Success - page fetched.
			my $http = shift;
			my $topicslist = eval { from_json($http->content) };
	
			if ($@) {
				$log->error("Error parsing JSON data $@");
				return;
			}
			
# Make up lookup hash of system name to localise name so that short list Topics can be built.
			my %localName = map { $_->{'systemEnglish'} => $_->{'localized'} } @{$topicslist};
			@topicsmenu = undef;

			my $icon = Plugins::RadioNet::Plugin->_pluginDataFor('icon');

			foreach my $topicname (@shortlisttopics) {
				push @topicsmenu, {
				'name'	      => $localName{$topicname},
#				'image'		  => $icon,
				'url'         => \&getTopicStations,
				'type'        => 'link',	
				'passthrough' => [ {'categorykey' => URI::Escape::uri_escape_utf8($topicname),
									'codeRef'     => 'getByTopics'}	],
				};
			};

# Make up the full topics sub menu 
			my @topicSubMenu;
			foreach my $topic (@{$topicslist}) {
				push @topicSubMenu, {
				'name'	      => $topic->{'localized'},
#				'image'		  => $icon,
				'url'         => \&getTopicStations,
				'type'        => 'link',	
				'passthrough' => [ {'categorykey' => URI::Escape::uri_escape_utf8($topic->{'systemEnglish'}),
									'codeRef'     => 'getByTopics'}	],
				};
			}	

# Combine submenu in with short menu.
			push @topicsmenu, {
				'name'	      => 'All Topics',
#				'image'		  => $icon,
				'items'		  => \@topicSubMenu
			};
		},
		sub { # Page fetch error 
			my $http = shift;
			my $error  = $http->error;			
			$log->error(" Failed to get genres list from Radio.net - fetch error: $error");
		}
	)->get($sourceurl);	
}

	
sub handleFeed {
	my ($client, $callback, $params, $args) = @_;
	
	my $icon = Plugins::RadioNet::Plugin->_pluginDataFor('icon');

# Make sure globals are up to fdate in case A settings changes.	
	$apilocaledomain =  Plugins::RadioNet::Settings::getlocaledomain();
	$topMenuLimit       = $prefs->get('radionettoplimit');
	$categoryMenuLimit  = $prefs->get('radionetcategorylimit');
	
	my $menu = [
			{
				name        => 'Search',
				type        => 'search',
				url         => \&getSearch,
#				image       => $icon,
				passthrough => [ { 'apikey' => $apikey,	} ],
			},	
			{
				name        => 'Local stations',
				type        => 'link',
				url         => \&getNearYou,
#				image       => $icon,
				passthrough => [ { 'apikey' => $apikey,	} ],
			},	
			{
				name        => 'Top Stations',
				type        => 'link',
				url         => \&getTopStations,
#				image       => $icon,
				passthrough => [ { 'apikey' => $apikey,	} ],
			},
			{
				name        => 'Genre',
#				image       => $icon,
				items		=> \@genresmenu
			},	
				
			{
				name        => 'Country - City',
#				image       => $icon,
				items		=> \@countriescitymenu
			},	

			{
				name        => 'Country Top stations',
#				image       => $icon,
				items		=> \@countriesrankmenu
			},	

			{
				name        => 'Topic',
#				image       => $icon,
				items		=> \@topicsmenu
			},	
				
			{
				name        => 'Editors Picks',
				type        => 'link',
				url         => \&getEditorsPicks,
#				image       => $icon,
				passthrough => [ { 'apikey' => $apikey,	} ],
			},	
		];
		
	$callback->( { items => $menu } );
};

sub commonFetchParse {

	my ( $client, $callback, $args, $passthrough,$sourceUrl, $parseRoutine ) = @_;

	if (  my $cachemenu = getCachedMenu($sourceUrl) )  {
		fixupCodeRefs($cachemenu);
		$callback->( { items => $cachemenu } );
		return;
	}

	Slim::Networking::SimpleAsyncHTTP->new(
		sub {
			my $http = shift;
			my $menu = $parseRoutine->($http->content);

			cacheMenu($sourceUrl, $menu, CACHEONEHOUR);			
			fixupCodeRefs($menu);
			$callback->( { items => $menu } );
		},

		# Called when no response was received or an error occurred.
		sub {
			$log->warn("error: $_[1]");
			$callback->( [ { name => $_[1], type => 'text' } ] );
		}
	)->get($sourceUrl);

	return;
}

# Search results are not cached - maybe it shoudl be.

sub getSearch {
	my ( $client, $callback, $args, $passthrough ) = @_;

	my $searchstr = URI::Escape::uri_escape_utf8($args->{'search'});

	commonFetchParse($client, $callback, $args, $passthrough,
					"https://$apilocaledomain/info/v2/search/stations?query=$searchstr&apiKey=$apikey&sizeperpage=$categoryMenuLimit",
					\&parseSearchStationsReply);

};

sub getNearYou {
	my ( $client, $callback, $args, $passthrough ) = @_;
	
	commonFetchParse($client, $callback, $args, $passthrough,
					"https://prod.radio-api.net/stations/local?count=100",  # Max count is 100 - any higher only one station returned
					\&parseStreamsReply);
};


sub getByTopics {
	my ( $client, $callback, $args, $passthrough ) = @_;
	
	commonFetchParse($client, $callback, $args, $passthrough,
					"https://$apilocaledomain/info/v2/search/gettopics?apiKey=$apikey",
					\&parseTopicsListReply);
};


sub getByGenres {
	my ( $client, $callback, $args, $passthrough ) = @_;
	
	commonFetchParse($client, $callback, $args, $passthrough,
					"https://$apilocaledomain/info/v2/search/getgenres?apiKey=$apikey",
					\&parseGenresListReply);
};

sub getByCountry {
	my ( $client, $callback, $args, $passthrough ) = @_;

	commonFetchParse($client, $callback, $args, $passthrough,
					"https://$apilocaledomain/info/v2/search/getcountries?apiKey=$apikey",
					\&parseCountriesListReply);

} ;

sub getCityByCountry {
	my ( $client, $callback, $args, $passthrough ) = @_;
	
	my $countrykey = $passthrough->{'categorykey'};

	commonFetchParse($client, $callback, $args, $passthrough,
					"https://$apilocaledomain/info/v2/search/getcities?apiKey=$apikey&country=$countrykey",
					\&parseCitiesListReply);
} ;


sub getTopStations {
	my ( $client, $callback, $args, $passthrough ) = @_;

	commonFetchParse($client, $callback, $args, $passthrough,
					"https://$apilocaledomain/info/v2/search/topstations?sizeperpage=$topMenuLimit&apiKey=$apikey",
					\&parseGetStationsReply);
	return;
};

sub getEditorsPicks {
	my ( $client, $callback, $args, $passthrough ) = @_;

	commonFetchParse($client, $callback, $args, $passthrough,
					"https://$apilocaledomain/info/v2/search/editorstips?apiKey=$apikey",
					\&parseEditorsReply);
	return;
};

sub getStationById {

	my ( $client, $callback, $args, $passthrough ) = @_;

	my $stationid = $passthrough->{'stationid'};	
	commonFetchParse($client, $callback, $args, $passthrough,
					"https://$apilocaledomain/info/v2/search/station?apiKey=$apikey&station=$stationid",
					\&parseStationIdReply);
	return;
};

sub getTopicStations {
	
	my ($client, $callback, $args, $passthrough) = @_;
	
	my $topickey = $passthrough->{'categorykey'};
	commonFetchParse($client, $callback, $args, $passthrough,
					"https://$apilocaledomain/info/v2/search/stationsbytopic?apiKey=$apikey&topic=$topickey&sizeperpage=$categoryMenuLimit",
					\&parseGetStationsReply);
	return;
}

sub getGenreStations {
	
	my ($client, $callback, $args, $passthrough) = @_;
	
	my $genrekey = $passthrough->{'categorykey'};
	commonFetchParse($client, $callback, $args, $passthrough,
					"https://$apilocaledomain/info/v2/search/stationsbygenre?apiKey=$apikey&genre=$genrekey&sizeperpage=$categoryMenuLimit",
					\&parseGetStationsReply);
	return;
}

sub getCountryStations {
	
	my ($client, $callback, $args, $passthrough) = @_;
	
	my $countrykey = $passthrough->{'categorykey'};
	commonFetchParse($client, $callback, $args, $passthrough,
					"https://$apilocaledomain/info/v2/search/stationsbycountry?apiKey=$apikey&country=$countrykey&sizeperpage=$categoryMenuLimit&sorttype=rank
",
					\&parseGetStationsReply);
	return;
}


sub getCityStations {
	
	my ($client, $callback, $args, $passthrough) = @_;
	
	my $citykey = $passthrough->{'categorykey'};
	commonFetchParse($client, $callback, $args, $passthrough,
					"https://$apilocaledomain/info/v2/search/stationsbycity?apiKey=$apikey&city=$citykey&sizeperpage=$categoryMenuLimit",
					\&parseGetStationsReply);
	return;
}

sub parseGetStationsReply {
	my $jsoncontent = shift;
	return parseGetMatchesStationsReply($jsoncontent, 'getStationById');
}

sub parseSearchStationsReply {
	my $jsoncontent = shift;
	return parseGetMatchesStationsReply($jsoncontent, 'getStationById');
}

sub parseGetMatchesStationsReply {
	
	my $jsoncontent = shift;
	my $routineName = shift;

	my 	$jsondata = eval { from_json($jsoncontent) };
	
	if ($@) {
		$log->error("Error parsing JSON data $@");
		return;
	}
	
	my @menu;
	my $stations   = $jsondata->{'categories'}[0]->{'matches'};
	
	foreach my $station (@{$stations}) {
		my $stationtype = $station->{'stationType'};
		my $stationname = $station->{'name'}->{'value'};

		next unless ( defined ($stationname) && 
					(($stationtype eq 'RADIO_STATION') || ($stationtype eq 'PODCAST')) );
		
		my $stationlogo = getstationlogo($station);
		my $stationid   = $station->{'id'};
		my $stationdesc = makestationdesc($station);
		
		push @menu, {
					'name'	      => $stationname . $stationdesc,
					'url'         => '',
					'image'		  => $stationlogo,
					'description' => $stationdesc,
					'type'        => 'link',	
					'passthrough' => [
									{
										'stationid' 	=> $stationid,
										'stationlogo'	=> $stationlogo,
										'codeRef' 		=> $routineName
									}
								],
				};
	}

	$log->debug(" Menu ". Dumper(@menu));

# All done 
	if (scalar @menu == 0) {
		push @menu , {
			'image'		  => undef ,
			'name'	      => 'No programs found',
			'type'        => 'text',	
		} ;
	}

	$log->debug("Dump of $routineName menu ". Dumper(\@menu));
	# return xmlbrowser hash
	return \@menu;
}

#  Details of just a single station in reply - with mulitple URLs
# The station cpuld eb a podcast


sub parseStationIdReply {
	
	my $jsoncontent = shift;
	my 	$station = eval { from_json($jsoncontent) };
	
	if ($@) {
		$log->error("Error parsing JSON data $@");
		return;
	}

	my @menu;
	
	my $stationtype = $station->{'stationType'};
	my $stationlogo = getstationlogo ($station);
	my $streamUrls  = $station->{'streamUrls'};
	my $podcastUrls = $station->{'podcastUrls'};

# Radio statuion streamURLs are playable. For podcast they are feeds.
	if ($stationtype eq 'radio_station') {
		my $stationname = $station->{'name'} . makestationdesc($station);

		foreach my $streamurl (@{$streamUrls}) {

			next unless ($streamurl->{'type'} eq 'STREAM');
		
			my $streamdesc = sprintf("%s [%s %dkbps (%s)]", 
								$station->{'description'},
								$streamurl->{'streamContentFormat'}, 
								$streamurl->{'bitRate'}, 
								$streamurl->{'contentType'});
		
			push @menu, {
						'name'	      => $stationname,
						'url'         => $streamurl->{'streamUrl'},
						'image'		  => $stationlogo,
						'description' => $streamdesc,
						'type'        => 'audio',	
						'on_select'   => 'play',
					};
	
		}
	}
	
	if ($stationtype eq 'podcast') {

		foreach my $podcast (@{$podcastUrls}) {
			
			my $podcastname = sprintf("%s - %s %s",
									$station->{'name'},
									$podcast->{'title'},
									makestationdesc($station));
		
			my $podcastdesc = sprintf("%s [%s (%s)]", 
								$podcast->{'description'},
								$podcast->{'streamContentFormat'}, 
								$podcast->{'contentType'});
								
			push @menu, {
						'name'	      => $podcastname,
						'url'         => $podcast->{'streamUrl'},
						'image'		  => $stationlogo,
						'description' => $podcastdesc,
						'type'        => 'audio',	
						'on_select'   => 'play',
					};
	
		}
	}

# All done 
	if (scalar @menu == 0) {
		push @menu , {
			'image'		  => undef ,
			'name'	      => 'No programs found',
			'type'        => 'text',	
		} ;
	}

	$log->debug("Dump of menu ". Dumper(\@menu));
	# return xmlbrowser hash
	return \@menu;
}

#
#  The categories can be Gnere, Country, City 
#

sub parseCategoryListReply {

	my $jsoncontent    = shift;
	my $getRoutineName = shift; 
	
	my $categorieslist = eval { from_json($jsoncontent) };

	if ($@) {
		$log->error("Error parsing JSON data $@");
		return;
	}
	
	my @menu;

	foreach my $category (@{$categorieslist}) {
		push @menu, {
				'name'	      => $category->{'localized'},
				'url'         => '',
				'type'        => 'link',	
				'passthrough' => [	{ 'categorykey' => URI::Escape::uri_escape_utf8($category->{'systemEnglish'}),
									  'codeRef'     => $getRoutineName} 
								 ],
		};
	}

# All done 
	if (scalar @menu == 0) {
		push @menu , {
			'image'		  => undef ,
			'name'	      => "No entries found for $getRoutineName",
			'type'        => 'text',	
		} ;
	}

	$log->debug("Dump of categories menu ". Dumper(\@menu));

	# return xmlbrowser hash
	return \@menu;
	
}

sub parseCountriesListReply {
	my $jsoncontent = shift;
	parseCategoryListReply ( $jsoncontent, 'getCountryStations');
}	

sub parseCitiesListReply {
	my $jsoncontent = shift;
	parseCategoryListReply ( $jsoncontent, 'getCityStations');
}	

sub parseGenresListReply {
	my $jsoncontent = shift;
	parseCategoryListReply ( $jsoncontent, 'getGenreStations');
}

sub parseTopicsListReply {
	my $jsoncontent = shift;
	parseCategoryListReply ( $jsoncontent, 'getTopicStations');
}



# This reply has multiple stations - there could be multiple URLS but only first used - FIXUP

sub parseStreamsReply {
	
	my $jsoncontent = shift;
	my $jsondata = eval { from_json($jsoncontent) };
	
	if ($@) {
		$log->error("Error parsing JSON data $@");
		return;
	}
	
	my @menu;
	my $stations   = $jsondata->{'playables'};
	
	foreach my $station (@{$stations}) {

		my $stationname = $station->{'name'};
		next unless defined ($stationname);

		my $stationtype = $station->{'type'};
		my $stationurl  = $station->{'streams'}[0]->{'url'};
		my $stationdesc = makestationdesc($station);
		
		push @menu, {
					'name'	      => $stationname . $stationdesc,
					'image'       => getstationlogo($station),
					'url'         => $stationurl ,
					'description' => $stationdesc,
					'on_select'   => 'play',
					'type'        => 'audio',	
		};
	}

# All done 
	if (scalar @menu == 0) {
		push @menu , {
			'image'		  => undef ,
			'name'	      => 'No programs found',
			'type'        => 'text',	
		} ;
	}

	$log->debug("Dump of menu ". Dumper(\@menu));
	# return xmlbrowser hash
	return \@menu;
}

sub parseEditorsReply {
	
	my $jsoncontent = shift;
	my $stations = eval { from_json($jsoncontent) };
	
	if ($@) {
		$log->error("Error parsing JSON data $@");
		return;
	}
	
	my @menu;
	
	foreach my $station (@{$stations}) {

		next unless (($station->{'playable'} eq 'PLAYABLE') && ($station->{'stationType'} eq 'radio_station'));
		
		my $stationname = $station->{'name'};
		my $stationurl  = $station->{'streamUrls'}[0]->{'streamUrl'};
		my $stationdesc = makestationdesc($station);

		next unless defined ($stationname);
		
		push @menu, {
					'name'	      => $stationname . $stationdesc,
					'image'       => getstationlogo($station),
					'url'         => $stationurl ,
					'description' => $stationdesc,
					'on_select'   => 'play',
					'type'        => 'audio',	
		};
	}

# All done 
	if (scalar @menu == 0) {
		push @menu , {
			'image'		  => undef ,
			'name'	      => 'No programs found',
			'type'        => 'text',	
		} ;
	}

	$log->debug("Dump of menu ". Dumper(\@menu));
	# return xmlbrowser hash
	return \@menu;
}

sub makestationdesc {
	my $station = shift;
	my $stationdesc;
	
# Check which form of statiopn record - matched ones have a HASH with 'value' whereas others have just a string. 	
	
	if (ref($station->{'name'}) eq 'HASH' ) {
		$stationdesc = ' ('. $station->{'city'}->{'value'} .', '. $station->{'country'}->{'value'} ;
		
		if (defined ($station->{'genres'}[0]->{'value'})) {
			my $genrelist;
			foreach my $entry (@{$station->{'genres'}}) {
				$genrelist .= $entry->{'value'} .',';
			}
			chop $genrelist ; # remove last comma;
			$stationdesc .= '/'.$genrelist;
		};
		
		$stationdesc .= ')' ;
	} else {
		$stationdesc = ' ('. $station->{'city'} .', '. $station->{'country'} ;
		$stationdesc .= ' / '. join(', ',@{$station->{'genres'}}) if (defined ($station->{'genres'}));
		$stationdesc .= ')' ;
	}
	
	return $stationdesc;
}


sub getstationlogo {
	my $station = shift;
	my $stationlogo =  $station->{'logo300x300'} ?  $station->{'logo300x300'} 
					 : $station->{'logo100x100'} ?  $station->{'logo100x100'} 
					 : $station->{'logo630x630'} ?  $station->{'logo630x630'} 
					 : $station->{'logo175x175'} ?  $station->{'logo175x175'} 
					 : Plugins::RadioNet::Plugin->_pluginDataFor('icon') ;

	return $stationlogo;
}

sub getDisplayName { 'PLUGIN_RADIONET' }

sub playerMenu { shift->can('nonSNApps') && $prefs->get('is_app') ? undef : 'RADIO' }

1;
