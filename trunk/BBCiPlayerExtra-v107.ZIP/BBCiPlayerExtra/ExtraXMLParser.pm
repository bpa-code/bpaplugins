package Plugins::BBCiPlayerExtra::ExtraXMLParser;

use strict;

use Slim::Utils::Log;

use XML::Simple;
use Date::Parse;

use Data::Dumper;

my $log = logger('plugin.bbciplayer.extra');

# split option string into options and filters
# valid options are:
# filter:<name>=<regexp> - filter to only include where <name> matches <regexp> 
# byday                  - include by day menus
# bykey                  - include menus grouped by brand/serial/title
# nocache                - don't cache parsed result [cacheing is per url so may need to turn off]
# reversedays            - list days in reverse order (use with byday)
# reverse                - list entries in reverse order (in list or by key display)

sub _getopts {
	my $class  = shift;
	my $optstr = shift;
	my $opts   = shift;
	my $filters= shift;

	for my $opt (split /\&/, $optstr) {
		if    ($opt =~ /filter:(.*)=(.*)/) { $filters->{lc($1)} = $2 }
		elsif ($opt =~ /(.*)=(.*)/       ) { $opts->{lc($1)}    = $2 } 
		else                               { $opts->{lc($opt)}  =  1 }
	}
}

sub parse {
	my $class  = shift;
	my $http   = shift;
	my $optstr = shift;

	my $params = $http->params('params');
	my $url    = $params->{'url'};
	my $opts   = {};
	my $filters= {};
	my @menu;

	$class->_getopts($optstr, $opts, $filters);

	my $xml = eval {
		XMLin( 
			$http->contentRef,
			ForceArray => ["entry"], 
			KeyAttr => []
		)
	};

	if ($@) {
		$log->error("$@");
		return;
	}

	for my $entry (@{$xml->{'entry'}}) {
		my $itemtitle;
		my $itemalturl;
		my $itemurl;
		my $itemicon;
		for my $link (@{$entry->{'link'}}) {
			if ($link->{'rel'} eq 'alternate'  ) {
				$itemtitle  = $link->{'title'};
				$itemicon   = $link->{'media:content'}->{'media:thumbnail'}->{'url'};
			};

			if ($link->{'rel'} eq 'self'  ) {
				$itemurl = $link->{'href'};
				$itemurl =~ s/http:\/\/feeds\.bbc\.co\.uk\/iplayer\/episode\//http:\/\/www\.bbc\.co\.uk\/iplayer\/playlist\//;
			};

		};
		push @menu, {
				'name'	      => $itemtitle,
				'url'         => $itemurl,
				'icon'        => $itemicon,
				'type'        => 'playlist',
				'on_select'   => 'play',
				'parser'      => 'Plugins::BBCiPlayerExtra::ExtraPlayableParser',

		};
	 }
	if ($opts->{'bytitle'} ) {
		my @sorted = sort { $a->{'name'} cmp $b->{'name'}  } @menu;
		@menu = @sorted;    
	}	  
	# return xmlbrowser hash
	return {
		'name'    => $params->{'feedTitle'},
		'items'   => \@menu,
		'type'    => 'opml',
		'nocache' => $opts->{'nocache'},
	};
}

1;
