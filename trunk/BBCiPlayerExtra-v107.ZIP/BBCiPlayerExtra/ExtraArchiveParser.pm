package Plugins::BBCiPlayerExtra::ExtraArchiveParser;

use strict;

use Slim::Utils::Log;

use XML::Simple;
use Date::Parse;

use Data::Dumper;

my $log = logger('plugin.bbciplayer.extra');

# split option string into options and filters
# valid options are:
# bytitle                - sort into menu by Year
# byyear                 - sort into menu by Title

sub _getopts {
	my $class  = shift;
	my $optstr = shift;
	my $opts   = shift;
	my $filters= shift;

	for my $opt (split /\&/, $optstr) {
		if    ($opt =~ /filter:(.*)=(.*)/) { $filters->{lc($1)} = $2 }
		elsif ($opt =~ /(.*)=(.*)/       ) { $opts->{lc($1)}    = $2 } 
		else                               { $opts->{lc($opt)}  =  1 }
	}
}

sub parse {
	my $class  = shift;
	my $http   = shift;
	my $optstr = shift;

	my $params = $http->params('params');
	my $url    = $params->{'url'};
	my $opts   = {};
	my $filters= {};

	my %datemenus = ();
	my %atozmenu = ();
	my @submenu;
	my @menu;
	my @morepages;
       
	$class->_getopts($optstr, $opts, $filters);

	my $xml = eval {
		XMLin( 
			$http->contentRef,
			ForceArray => ["episode"], 
			SuppressEmpty => '',
			KeyAttr => []
		)
	};

	if ($@) {
		$log->error("$@");
		return;
	}
	my $programmes = $xml ->{'episode'};
  	foreach my $entry (@{$programmes}) {
	    my $display_title;
	    my $program = $entry->{'programme'};
	    $log->debug("Start Time=" . $program->{'first_broadcast_date'} . "Pid ". $entry->{'programme'}->{'pid'} .
                                                          "  Title ". $entry->{'programme'}->{'display_titles'}->{'title'} . 
                                                          "  SubTitle ". $entry->{'programme'}->{'display_titles'}->{'subtitle'} . 
                                                       " Synopsis: ". $entry->{'programme'}->{'short_synopsis'} .
							" Audio format: " . ((defined($entry->{'programme'}->{'media'})) ? $entry->{'programme'}->{'media'}->{'format'}   : "*********No Format ******" ) );
	    my $title;
	    ($title = $entry->{'programme'}->{'display_titles'}->{'title'}) =~ s/^The //;
   
#	    ($title = $program->{'title'}) =~ s/^The //;
	    $title = $title . ', The'  if ($title ne $program->{'title'}) ;
	    my $firstletter = uc( substr $title , 0, 1);
	    my $broadcast = str2time($program->{'first_broadcast_date'});
	    my ($min, $hour, $mday, $mon, $year) = (localtime($broadcast))[1,2,3,4,5,6];
	    $year = substr($program->{'first_broadcast_date'}, 0, 4);
	    my $date = sprintf("%04d-%02d-%02d",$year,$mon,$mday);
	    
	    if ($program->{'display_titles'} -> {'subtitle'} ne "") {
		    $display_title = $program->{'display_titles'} -> {'title'} . ' ' . $program->{'display_titles'} -> {'subtitle'};
	    } else {
		    $display_title = $entry->{'programme'}->{'programme'}->{'title'} . ' '. $program->{'display_titles'} -> {'title'} ;
	    }
	    if ($opts->{'byyear'} ) {
			    push @${$datemenus{$year}} , {
#					'name'	      => $program->{'title'},
					'name'	      => $display_title,
#					'url'         => 'http://www.bbc.co.uk/iplayer/playlist/' . $program->{'pid'} ,
					'url'         => 'http://www.bbc.co.uk/programmes/'. $program->{'pid'} . '/playlist.json' ,					
					'date'        => $date,
					'type'        => 'playlist',
					'on_select'   => 'play',
					'parser'      => 'Plugins::BBCiPlayerExtra::ExtraPlayableParser',
			} ;
		} elsif ($opts->{'bytitle'} ) {
			    push @${$atozmenu{$firstletter}} , {
#					'name'	      => $program->{'title'},
					'name'	      => $display_title,
#					'url'         => 'http://www.bbc.co.uk/iplayer/playlist/' . $program->{'pid'} ,
					'url'         => 'http://www.bbc.co.uk/programmes/'. $program->{'pid'} . '/playlist.json' ,					
					'type'        => 'playlist',
					'on_select'   => 'play',
					'parser'      => 'Plugins::BBCiPlayerExtra::ExtraPlayableParser',
			} ;
		} else {
			   push @submenu , {
#					'name'	      => $program->{'title'},
					'name'	      => $display_title,
#					'url'         => 'http://www.bbc.co.uk/iplayer/playlist/' . $program->{'pid'} ,
					'url'         => 'http://www.bbc.co.uk/programmes/'. $program->{'pid'} . '/playlist.json' ,					
					'type'        => 'playlist',
					'on_select'   => 'play',
					'parser'      => 'Plugins::BBCiPlayerExtra::ExtraPlayableParser',
			} ;
		};
  

	 }
	if (($xml->{'page'} == 1) && $xml->{'total'} > scalar@{$programmes} ) {
		my $pageno = 2;
		my $epsperpage = scalar@{$programmes};
		my $lasteps = $epsperpage;
		do { 
			push @morepages , {
					'name'	      => "Page $pageno - " . $params->{'feedTitle'},
					'url'         => "$url?page=$pageno",
					'parser'      => 'Plugins::BBCiPlayerExtra::ExtraArchiveParser',
			} ;
			$pageno  = $pageno + 1;
			$lasteps = $lasteps + $epsperpage;
		} while (  $xml->{'total'}  > $lasteps ) 
	
	}
	if ($opts->{'byyear'} ) {
		my @keys = sort { $a cmp $b } (keys %datemenus);
		foreach my $key (@keys) {
			my @sorted = sort { $a->{'date'} cmp $b->{'date'}  } @{ ${$datemenus{$key}}};
			push (@sorted,@morepages);
			push @menu, {
				'name'  => $key ,
				'items' => \@sorted,
				'type'  => 'opml',
			};
		}
	} elsif ($opts->{'bytitle'} ) {
		my @keys = sort { $a cmp $b } (keys %atozmenu);
		foreach my $key (@keys) {
			my @sorted = sort { $a->{'name'} cmp $b->{'name'}  } @{ ${$atozmenu{$key}}};
			push (@sorted,@morepages);
			push @menu, {
				'name'  => $key ,
				'items' => \@sorted,
				'type'  => 'opml',
			};
		}
	} else {
			my @sorted = sort { $a->{'name'} cmp $b->{'name'}  } @submenu ;
			push (@sorted,@morepages);
			return {
				'name'    => $params->{'feedTitle'},
				'items'   => \@sorted,
				'type'    => 'opml',
				'nocache' => $opts->{'nocache'},
			};
	}
	

	# return xmlbrowser hash
	return {
		'name'    => $params->{'feedTitle'},
		'items'   => \@menu,
		'type'    => 'opml',
		'nocache' => $opts->{'nocache'},
	};
}

1;
