package Plugins::BBCiPlayerExtra::Plugin;

# Plugin to add menu to BBCiPlayer 
#
# Released under GPLv2

use strict;

use base qw(Slim::Plugin::OPMLBased);


use File::Spec::Functions qw(:ALL);
use Plugins::BBCiPlayerExtra::Metadata;
use Plugins::BBCiPlayerExtra::Settings;
use Slim::Utils::Prefs;

my $prefs = preferences('plugin.bbciplayerextra');


my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.bbciplayer.extra',
	'defaultLevel' => 'WARN',
	'description'  => getDisplayName(),
});


sub initPlugin {
	my $class = shift;

	my $file = catdir( $class->_pluginDataFor('basedir'), 'default.opml' );

	$class->SUPER::initPlugin(
		feed   => Slim::Utils::Misc::fileURLFromPath($file),
		tag    => 'bbciplayerextra',
		menu   => 'radios',
		weight => 1,
	);

	Plugins::BBCiPlayerExtra::Settings->new;

	if ($prefs->get('shownownext')) {
	  Plugins::BBCiPlayerExtra::Metadata->init();
	}

}

sub getDisplayName { 'PLUGIN_BBCIPLAYEREXTRA' }

1;
