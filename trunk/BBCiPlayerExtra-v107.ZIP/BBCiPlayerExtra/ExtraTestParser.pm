package Plugins::BBCiPlayerExtra::ExtraTestParser;

use strict;

use Slim::Utils::Log;

use XML::Simple;
use JSON::XS::VersionOneAndTwo;
use Date::Parse;

use Data::Dumper;

my $log = logger('plugin.bbciplayer.extra');

# split option string into options and filters
# valid options are:
# filter:<name>=<regexp> - filter to only include where <name> matches <regexp> 
# byday                  - include by day menus
# bykey                  - include menus grouped by brand/serial/title
# nocache                - don't cache parsed result [cacheing is per url so may need to turn off]
# reversedays            - list days in reverse order (use with byday)
# reverse                - list entries in reverse order (in list or by key display)

sub _getopts {
	my $class  = shift;
	my $optstr = shift;
	my $opts   = shift;
	my $filters= shift;

	for my $opt (split /\&/, $optstr) {
		if    ($opt =~ /filter:(.*)=(.*)/) { $filters->{lc($1)} = $2 }
		elsif ($opt =~ /(.*)=(.*)/       ) { $opts->{lc($1)}    = $2 } 
		else                               { $opts->{lc($opt)}  =  1 }
	}
}

sub parse {
	my $class  = shift;
	my $http   = shift;
	my $optstr = shift;

	my $params = $http->params('params');
	my $url    = $params->{'url'};
	my $opts   = {};
	my $filters= {};
	my @menu;

	$class->_getopts($optstr, $opts, $filters);
	
	if ($opts->{'xml'} ) {

		my $xml = eval {
			XMLin( 
				$http->contentRef,
#				ForceArray => ["entry"], 
				KeyAttr => []
			)
		};

		if ($@) {
			$log->error("$@");
			return;
		}
		$log->error("Dump XML of URL \n", Dumper($xml));
		return;
	}
	
	if ($opts->{'json'} ) {
		my $json = eval { from_json( ${$http->contentRef} ) };

		if ($@) {
			$log->error("$@");
			return;
		}
		$log->error("Dump JSON of URL \n", Dumper($json));
		return;
	}
		
	
}

1;
