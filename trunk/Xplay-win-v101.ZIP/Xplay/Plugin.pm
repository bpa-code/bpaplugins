#
# A plugin to enable streams to be played by external application such as mplayer, ffmpeg, vlc
#

use strict;

package Plugins::Xplay::Plugin;

use base qw(Slim::Plugin::OPMLBased);

use Slim::Utils::Log;
use Slim::Utils::Prefs;

use Plugins::Xplay::Settings;

use Plugins::Xplay::XPLAY;


# create log categogy before loading other modules
my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.xplay',
	'defaultLevel' => 'ERROR',
#	'defaultLevel' => 'INFO',
	'description'  => getDisplayName(),
});


use Slim::Utils::Misc;
my $prefs       = preferences('plugin.xplay');



################################
### Plugin Interface ###########
################################


sub initPlugin
{
	my $class = shift;

	$log->info("Initialising " . $class->_pluginDataFor('version'));
	Plugins::Xplay::Settings->new($class);
	Plugins::Xplay::Settings->init();


#	Slim::Control::Request::subscribe( \&pauseCallback, [['pause']] );

	return 1;
}

sub pauseCallback {
	my $request = shift;
	my $client  = $request->client;

	my $stream  = Slim::Player::Playlist::song($client)->path;
	my $playmode= Slim::Player::Source::playmode($client);
	my $mode    = Slim::Buttons::Common::mode($client);

	$log->debug("cli Pause - playmode=$playmode  stream=$stream ");

	if ($stream =~ /^xplay:/ ) {
#	if ($playmode eq 'pause' && $stream =~ /^xplay:/ ) {
		if ($prefs->get('pausestop')) {
			$log->debug("Issuing stop");
			$client->execute([ 'stop' ]);
		}
	}

}


sub shutdownPlugin
{
#	Slim::Control::Request::unsubscribe(\&pauseCallback);
 	return;
}

sub getDisplayName()
{
	return('PLUGIN_XPLAY')
}

1;

# Local Variables:
# tab-width:4
# indent-tabs-mode:t
# End:
