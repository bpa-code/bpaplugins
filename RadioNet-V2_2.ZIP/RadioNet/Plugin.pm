package Plugins::RadioNet::Plugin;

# Plugin to get station from Radio,net
#
# Released under GPLv2

use strict;

use base qw(Slim::Plugin::OPMLBased);

use File::Spec::Functions qw(:ALL);
use File::Slurp qw(read_file);
use MyText::Balanced;
use JSON::XS::VersionOneAndTwo;
use Digest::MD5 qw(md5_hex);
use URI::Escape;

use Slim::Utils::Log;
use Slim::Utils::Cache;
use Slim::Utils::Prefs;

use Plugins::RadioNet::Settings;

use Data::Dumper;


my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.radionet',
	'defaultLevel' => 'ERROR',
	'description'  => getDisplayName(),
});

my $prefs = preferences('plugin.radionet');


use constant WEBPAGE_JSON_ANCHOR => 'window.__CONTEXT_PROVIDER__ = ';
use constant WEBPAGE_JSON_ANCHOR_2 => 'id="__NEXT_DATA__" type="application/json">';

# Initialise some global variables to make sure they have default values.

my $localedomain      = 'https://www.radio,net';
my $localemessages;   # hash of message according to local

# short lists are in SystemEnglish (i.e. domain independent key) and not localised form.


my $genresMenu;
my $countriesMenu;
my $topicsMenu;
my $editorMenu;
my $topTenStations;
my $topTopics;

my $pluginName = 'radionetV2';


use constant CACHEONEHOUR    =>  3600; 
use constant CACHETHREEHOURS => 10800; 
my $cache = Slim::Utils::Cache->new();
$cache->clear();


my @radionetdomains  = ('https://www.radio.net', 'https://www.radio.pt', 'https://br.radio.net', # 0,1,2
				 'https://www.radio.it', 'https://www.radio.se', 'https://www.radio.fr',         # 3,4,5
				 'https://www.radio.es', 'https://mx.radio.net', 'https://co.radio.net',         # 6,7,8
				 'https://www.radio.de', 'https://www.radio.at', 'https://www.radio.pl',         # 9, 10,11 
				 'https://www.radio.dk',                                                         # 12  
				 'https://uk.radio.net', 'https://ie.radio.net',                                 # 13,14       
				 'https://au.radio.net', 'https://nz.radio.net',                                 # 15,16 
				 'https://za.radio.net', 'https://ca.radio.net', 'https://nl.radio.net'          # 17, 18, 19
				 ); 


sub getopts {
	my $url = shift;

	my ($baseurl, $optstr) = split(/\?/, $url);
	my %opts;

	for my $opt (split /\&/, $optstr) {
		if ($opt =~ /(.*)=(.*)/       ) { $opts{lc($1)}    = $2 } 
		else                            { $opts{lc($opt)}  =  1 }
	}
	
	return ($baseurl,\%opts);
}

sub getCachedMenu {
	my $url = shift;

	my $cacheKey = $pluginName . ':' . md5_hex($url);

	if ( my $cachedMenu = $cache->get($cacheKey) ) {
		my $menu = ${$cachedMenu};
		return $menu;
	};
	return;
}

sub cacheMenu {
	my ( $url, $menu, $seconds ) = @_;	

	my $cacheKey = $pluginName . ':' . md5_hex($url);
	$cache->set( $cacheKey, \$menu, $seconds );

	return;
}

# Fixup callable routine table - fixup need because CODE cannot be saved when menu is cached.

my %subItems = (
	'getStationURLs'	 => \&getStationURLs,
	'getPodcastURLs'	 => \&getPodcastURLs,
	'getSearch'  		 => \&getSearch,
	'getPagedLists'   	 => \&getPagedLists,
	);

sub fixupCodeRefs {
	my $menu = shift;

	for my $menuItem (@$menu) {
		my $codeRef = $menuItem->{passthrough}[0]->{'codeRef'};
#		$log->error(" Fixup menu $codeRef for ".$menuItem->{'name'} );

		if ( defined $codeRef ) {
			$log->error("Fixup failed for undefined routine: $codeRef ") unless (exists($subItems{$codeRef}));
			$menuItem->{'url'} = $subItems{$codeRef};
		}
# Fixup submenu if one is present
		fixupCodeRefs($menuItem->{'items'}) if (defined $menuItem->{'items'}) ;
	}
	return;
}
				 
sub extractJSONdata {

	my $webpage     = shift;
	my $splitstring = shift;
	
# Split webpage at boundary with start of JSON data 	
	my ($before, $after) = split ($splitstring,$webpage,2);
	
# Find the balanced closing brace for the JSON data.	
	my 	@result = MyText::Balanced::extract_bracketed( $after, '{"}' );
	
# JSON data is parsed and converted. 
	my 	$jsondata = eval { from_json($result[0]) };
#    $log->error(" JSON extract ". Dumper(\$jsondata));

	if ($@) {
		$log->error("Error parsing JSON data $@");
		return;
	}
	
	return $jsondata;	
}				 

sub getCanonicalDomain {
	my $pagedata = shift;
	my $canonical_domain;

	if (defined($pagedata->{'canonicalDomain'}) ) {
		$canonical_domain = $pagedata->{'canonicalDomain'};	
	} elsif (defined($pagedata->{'DOMAIN'}) ) {
		$canonical_domain = $pagedata->{'DOMAIN'};	
	} else {  # Only do this when web page has probably changed and so need updating
		$log->error(" Canonical Domain is not defined in Radio.net web page - plugin should be updated");
		
		Slim::Utils::Misc::bt();
		$canonical_domain  = $radionetdomains[$prefs->get('radionetlocale')];;
	}

# Just in case https has been left off in a change
	$canonical_domain = 'https://'. $canonical_domain unless ($canonical_domain =~ m/^http(s?):\/\//i ) ;
	$log->debug(" Canonical domain $canonical_domain"); 

	return $canonical_domain;		
}	


sub updateLocale {
	my $sourceurl = 'http://www.radio.net';
	$localedomain = @radionetdomains[$prefs->get('radionetlocale')];
	
	$log->info(" Locale setting $localedomain");
	$sourceurl = $localedomain if (defined($localedomain));

	
	Slim::Networking::SimpleAsyncHTTP->new(
		sub { 						# Success - page fetched.
			my $http = shift;

			my $jsonnextdata = extractJSONdata($http->content, WEBPAGE_JSON_ANCHOR_2);
			my $jsondata     = extractJSONdata($http->content, WEBPAGE_JSON_ANCHOR);
			
			$log->debug("CONTEXT data ". Dumper(\$jsondata));
			$localemessages = $jsondata->{'translation'};
#           $log->info(" Dump of locale message ".Dumper($localemessages));
			
			$cache->clear();

			makeGenreMenu();
			makeCountryMenu();
			makeTopicMenu();
			makeEditorMenu($jsonnextdata->{'props'}->{'pageProps'}->{'data'}->{'editorsPicks'}->{'playables'});
		},
		
		sub { # Page fetch error 
			my $http = shift;
			my $error  = $http->error;			
			$log->error(" Failed to get initial page from Radio.net - error: $error");
		}
	)->get($sourceurl)	
	
}

sub initPlugin {
	my $class = shift;

	Plugins::RadioNet::Settings->new($class);
	Plugins::RadioNet::Settings->init($class);
	
	$class->SUPER::initPlugin(
		feed   => \&handleFeed,
		tag    => 'radionet',
		is_app => $class->can('nonSNApps') && $prefs->get('is_app') ? 1 : undef,
		menu   => 'radios',
		weight => 1,
	);

	Plugins::RadioNet::Settings->new;
	updateLocale();

}

sub makeEditorMenu {
	
	my $editorlist = shift;

	$editorMenu = makePlayablesMenu($editorlist);

	return ;
}

sub makeGenreMenu {

  makeListMenu ($localedomain . '/genre' ,        # Base URL for lists - country, Genres, topics
				'navibar.section.genres.outlink', # Key for transalation of "all" 
				'tags',                           # key to JSON 'data' for full list of items
				'genreShortlist',                 # key to JSON 'data' for short list of items
                \&getGenreStations,              # Function to be fxied up to process item. 
                \$genresMenu);                    # ref to variable to save new menu.

}

sub makeTopicMenu {

  makeListMenu ($localedomain . '/topic' ,        # Base URL for lists - country, Genres, topics
				'navibar.section.moretopics.outlink', # Key for transalation of "all" 
				'tags',                           # key to JSON 'data' for full list of items
				'topicShortlist',                 # key to JSON 'data' for short list of items
                \&getTopicStations,             # Function to be called up to process item.
                \$topicsMenu);                    # ref to variable to save new menu.

}

sub makeCountryMenu {

# Country no longer has a short list - only All - so processing same as a cut down makeListMenu

#  makeListMenu ($localedomain . '/country' ,      # Base URL for lists - country, Genres, topics
#				'page.all_countries.headline',    # Key for translation of "all" 
#				'tags',                           # key to JSON 'data' for full list of items
#				'countryShortlist',               # key to JSON 'data' for short list of items
#               \&getCountryStations,             # Function to be CALLed up to process item.
#              \$countriesMenu);                 # ref to variable to save new menu.

	my $sourceurl    = $localedomain . '/country'  ;
  	my $keyFullList  = 'tags' ;
  	my $getFunction  = \&getCountryStations ;
	my $listMenuref  = \$countriesMenu ;

#
# Find tags in JSON data
#	
	my $menulanguage = ($prefs->get('use_locale')) ? 'name' : 'systemName'  ;  #   systemName key has English menu, name key has locale veriosn of menu, slug key is to be used in URLs
	$log->debug(" Fetching $sourceurl");
	Slim::Networking::SimpleAsyncHTTP->new(
		sub { 						# Success - page fetched.
			my $http = shift;
			my $jsondata = extractJSONdata($http->content,  WEBPAGE_JSON_ANCHOR_2);
			my $itemsFulllist	= $jsondata->{'props'}->{'pageProps'}->{'data'}->{'tags'};

# Make up the full sub menu of all items  (not short list)
			my @subMenu;
			foreach my $item (@{$itemsFulllist}) {
				push @subMenu, {
				'name'	      => $item->{$menulanguage},
				'url'         => $getFunction,
				'type'        => 'link',	
				'passthrough' => [ {'url' => $sourceurl. '/'.$item->{'slug'} }],
				};
			}	

# Sort  if using English language version of a different language menu - as English traslations has different sort order.
			my @sortedSubMenu;
			if ($prefs->get('use_locale') ) {
				@sortedSubMenu = @subMenu ;
			} else { 
				@sortedSubMenu = sort { $a->{'name'} cmp $b->{'name'} } @subMenu;
			}	
		
#			$log->error("Genre Menu ".Dumper(@genresmenu));
			$$listMenuref = \@sortedSubMenu;
		},
		sub { # Page fetch error 
			my $http = shift;
			my $error  = $http->error;			
			$log->error(" Failed to get genres list from Radio.net - fetch error: $error");
			$$listMenuref = undef;
		}
	)->get($sourceurl);	

    return;
}

#
#  makeListMenu ($localedomain . '/genre' ,       # Base URL for lists - country, Genres, topics
#				'navibar.section.genres.outlink', # Key for transalation of "all" 
#				'tags',                           # key to JSON 'data' for full list of items
#				'genreShortlist',                 # key to JSON 'data' for short list of items
#               'getPagedLists'                   # Function to be fixed up to process item.

sub makeListMenu {
	
	my $sourceurl    = shift ;
  	my $keyAll       = shift ;
  	my $keyFullList  = shift ;
  	my $keyShortList = shift ;
  	my $getFunction  = shift ;
	my $listMenuref  = shift ;

#
# Find tags in JSON data
#	
	my $menulanguage = ($prefs->get('use_locale')) ? 'name' : 'systemName'  ;  #   systemName key has English menu, name key has locale veriosn of menu, slug key is to be used in URLs
	my $allmenu      = ($prefs->get('use_locale')) ? $localemessages->{$keyAll}  : 'All' ;

	$log->debug(" Fetching $sourceurl");
	Slim::Networking::SimpleAsyncHTTP->new(
		sub { 						# Success - page fetched.
			my $http = shift;
			my $jsondata = extractJSONdata($http->content,  WEBPAGE_JSON_ANCHOR);
			my $itemsShortlist  = $jsondata->{'data'}->{$keyShortList};
			
			$jsondata = extractJSONdata($http->content,  WEBPAGE_JSON_ANCHOR_2);
			my $itemsFulllist	= $jsondata->{'props'}->{'pageProps'}->{'data'}->{'tags'};

			my @menu ;
			foreach my $item (@$itemsShortlist) {
				push @menu, {
				'name'	      => $item->{$menulanguage},
				'url'         => $getFunction,
				'type'        => 'link',	
				'passthrough' => [ {'url' => $sourceurl. '/'.$item->{'slug'} } ],
				};
			};
# Sort as depending on locale/English language, menu has different sort order.
			my @sortedMenu;
			if ($prefs->get('use_locale') ) {
				@sortedMenu = @menu ;
			} else { 
				@sortedMenu = sort { $a->{'name'} cmp $b->{'name'} } @menu;
			}	

# Make up the full sub menu of all items  (not short list)
			my @subMenu;
			foreach my $item (@{$itemsFulllist}) {
				push @subMenu, {
				'name'	      => $item->{$menulanguage},
				'url'         => $getFunction,
				'type'        => 'link',	
				'passthrough' => [ {'url' => $sourceurl. '/'.$item->{'slug'} }],
				};
			}	

# Sort  if using English language version of a different language menu - as English traslations has different sort order.
			my @sortedSubMenu;
			if ($prefs->get('use_locale') ) {
				@sortedSubMenu = @subMenu ;
			} else { 
				@sortedSubMenu = sort { $a->{'name'} cmp $b->{'name'} } @subMenu;
			}	
# Combine full submenu in with short menu using the menu item for "all" 
			push @sortedMenu, {
				'name'	      => $allmenu, #    'All',
				'items'		  => \@sortedSubMenu
			};
			
#			$log->error("Genre Menu ".Dumper(@genresmenu));
			$$listMenuref = \@sortedMenu;
		},
		sub { # Page fetch error 
			my $http = shift;
			my $error  = $http->error;			
			$log->error(" Failed to get genres list from Radio.net - fetch error: $error");
			$$listMenuref = undef;
		}
	)->get($sourceurl);	
	
	return ;
}

my @englishmenutext = ('Search','Local Stations','Top Stations', 'Genre', 'Countries', 'Topics', "Editor's tips");

my $similarStationMenuText;

sub handleFeed {
	my ($client, $callback, $params, $args) = @_;
	
	my $icon = Plugins::RadioNet::Plugin->_pluginDataFor('icon');
	
	my @localemenutext  = (	$localemessages->{'header.search.placeholder'} , 
							$localemessages->{'navibar.section.local.menu'},
							$localemessages->{'breadcrumbs.topstations'},
							$localemessages->{'breadcrumbs.genres'},
							$localemessages->{'breadcrumbs.countries'},
							$localemessages->{'breadcrumbs.topics'},
							$localemessages->{'module.tab_carousel.tab.editors_tips'} );

# Special case for Similar Stations which can appear in all station playable menu.

    $similarStationMenuText = ($prefs->get('use_locale')) ?  $localemessages->{'station.titles.similar.stations'} : 'Similar Stations' ;

							
	my $menutext = ($prefs->get('use_locale')) ?  \@localemenutext : \@englishmenutext ;							
	my $menu = [
			{
				name        => $menutext->[0], # name  => 'Search',
				type        => 'search',
				url         => \&getSearch,
				passthrough => [ { 'pageno' => 1} ],
			},	
			{
				name        => $menutext->[1],# name => 'Local stations',
				type        => 'link',
				url         => \&getNearYou,
			},	
			{
				name        => $menutext->[2],#	name => 'Top Stations',
				type        => 'link',
				url         => \&getTopStations,
			},
			{
				name        => $menutext->[3],# name => 'Genre',
				items		=> $genresMenu
			},	
				
			{
				name        => $menutext->[5],#	name => 'Topic',
				items		=> $topicsMenu
			},	

			{
				name        => $menutext->[4],#	name => 'Countries',
				items		=> $countriesMenu
			},	

			{
				name        => $menutext->[6],#	name => 'Editors Tips',
				items       => $editorMenu,
			},
				
		];
		
	$callback->( { items => $menu } );
};

sub commonFetchParse {

	my ( $client, $callback, $args, $passthrough,$sourceUrl, $parseRoutine ) = @_;
	
	if (  my $cachemenu = getCachedMenu($sourceUrl) )  {
		fixupCodeRefs($cachemenu);
		$callback->( { items => $cachemenu } );
		return;
	}
	my $starttime  = Time::HiRes::time() ;
	Slim::Networking::SimpleAsyncHTTP->new(
		sub {
			my $http = shift;
			
			my $fetchedtime = Time::HiRes::time() - $starttime ;
			my $menu = $parseRoutine->($http->content,$sourceUrl);
			my $parsedtime = Time::HiRes::time() - $starttime ;
			
			$log->info(sprintf("Fetch delay %15.6f  Parse delay %15.6f for url %s ",$fetchedtime,$parsedtime, $sourceUrl)); 

			cacheMenu($sourceUrl, $menu, CACHEONEHOUR);			
			fixupCodeRefs($menu);
			$callback->( { items => $menu } );
		},

		# Called when no response was received or an error occurred.
		sub {
			$log->warn("error: $_[1]");
			$callback->( [ { name => $_[1], type => 'text' } ] );
		}
	)->get($sourceUrl);

	return;
}

# Search results are not cached - maybe it shoudl be.

sub getSearch {

	my ( $client, $callback, $args, $passthrough ) = @_;

	my $searchstr;
	my $pageno =1;
	my $searchUrl;
	
	if (defined($args->{'search'})) {
	    $searchstr = URI::Escape::uri_escape_utf8($args->{'search'});
	    $searchUrl = "$localedomain/search?q=$searchstr&p=$pageno"
	} 
	
	if (defined ($passthrough->{'codeRef'})) {
		$searchUrl= $passthrough->{'url'};
	};  

	commonFetchParse($client, $callback, $args, $passthrough,
					$searchUrl,
					\&parseSearchStationsReply);
};

sub getNearYou {
	my ( $client, $callback, $args, $passthrough ) = @_;
	
	commonFetchParse($client, $callback, $args, $passthrough,
					"https://prod.radio-api.net/stations/local?count=100",  # Max count is 100 - any higher only one station returned
					\&parseStreamsReply);
};

sub getPodcastURLs {
	my ( $client, $callback, $args, $passthrough ) = @_;

	my $podcastid = $passthrough->{'podcastid'};	
	
	commonFetchParse($client, $callback, $args, $passthrough,
					"https://prod.radio-api.net/podcasts/episodes/by-podcast-ids?podcastIds=$podcastid&count=100&offset=0",
					\&parsePodcastsReply);
};

sub getPagedLists {
	my ( $client, $callback, $args, $passthrough ) = @_;
	
	commonFetchParse($client, $callback, $args, $passthrough,
					 $passthrough->{'url'},
					\&parseListMenuReply);
};

sub getTopStations {
	my ( $client, $callback, $args, $passthrough ) = @_;

	commonFetchParse($client, $callback, $args, $passthrough,
					$localedomain.'/top-stations',
					\&parseGetTopStationsReply);
	return;
};

sub getStationURLs {

	my ( $client, $callback, $args, $passthrough ) = @_;
	my $stationUrl = $passthrough->{'stationurl'};	

	commonFetchParse($client, $callback, $args, $passthrough,
					$stationUrl,
					\&parseStationURLReply);
	return;
};


sub getTopicStations {
	
	my ($client, $callback, $args, $passthrough) = @_;
	
	commonFetchParse($client, $callback, $args, $passthrough,
					 $passthrough->{'url'},
					\&parseListMenuReply);
	return;
}

sub getGenreStations {
	
	my ($client, $callback, $args, $passthrough) = @_;
	
	commonFetchParse($client, $callback, $args, $passthrough,
					 $passthrough->{'url'},
					\&parseListMenuReply);
	return;
}

sub getCountryStations {
	
	my ($client, $callback, $args, $passthrough) = @_;
	
	commonFetchParse($client, $callback, $args, $passthrough,
					 $passthrough->{'url'},
					\&parseListMenuReply);
	return;
}


sub parseGetTopStationsReply {
	
	my $http = shift;
	my $menu;
	
	my $json_all = extractJSONdata($http,  WEBPAGE_JSON_ANCHOR_2);
	my $jsondata = $json_all->{'props'}->{'pageProps'};
	
# check for results

	unless (defined ($jsondata->{'data'}->{'stations'}->{'playables'})) {
		$log->error(" No Playables found in Top stations reply - perhaps plugin needs to be updated.");
		push @$menu , {
			'name'	      => 'No Top stations found',
		} ;
		return $menu;
	};

#	my $canonical_domain  = getCanonicalDomain($jsondata->{'data'});

	$log->info("Dump parsed JSON " . Dumper($jsondata->{'data'}->{'stations'}->{'playables'}));
	
	my $totalcount     = $jsondata->{'data'}->{'stations'}->{'totalCount'};
	my $stationscount  = $jsondata->{'data'}->{'stations'}->{'count'};
	$menu = makePlayablesMenu($jsondata->{'data'}->{'stations'}->{'playables'});

# All done 
	if (scalar @$menu == 0) {
		push @$menu , {
			'image'		  => undef ,
			'name'	      => 'No programs found',
			'type'        => 'text',	
		} ;
	}

	$log->info('Dump of getStationURLs menu '. Dumper($menu));
	# return 
	return $menu;
}

sub parseSearchStationsReply {

	my $http = shift;
	my $url  = shift;
	
	my ($baseurl,$opts) = getopts($url);
	
	my $searchurl = $baseurl . '?q=' . $opts->{'q'};
	
#	$log->error("Dump of opts for $url  $baseurl \n".Dumper(\$opts)); 
	

	my $pageno =1  ;
	
    my $menu;
    my $stationsmatched;
    my $totalpages;
    
    if ($url =~ m/&p=(\d+)/) {
		$pageno = $1;
    };

#  In the web page there is a JSON chunk of data assigned to a variable window.__CONTEXT_PROVIDER__ 

	my $json_all = extractJSONdata($http,  WEBPAGE_JSON_ANCHOR_2);
	my $jsondata = $json_all->{'props'}->{'pageProps'};
	
# check for results
	unless (defined ($jsondata->{'data'}->{'stations'}->{'playables'})) {
		$log->error(" No Playables found in search reply - perhaps plugin needs ot be updated.");
		push @$menu , {
			'name'	      => 'No programs found in search reply',
		} ;
		return $menu;
	};

	my $totalcount     = $jsondata->{'data'}->{'stations'}->{'totalCount'};
	my $stationscount  = scalar (@{$jsondata->{'data'}->{'stations'}->{'playables'}});
	
	my $totalpages = 1;
	if ($totalcount > $stationscount) {
		$totalpages = int(($totalcount + ($stationscount - 1))/ $stationscount); # Round up to get number of pages available
	}
	
	$menu = makePlayablesMenu($jsondata->{'data'}->{'stations'}->{'playables'});

	$log->info(" Menu ". Dumper(@$menu));

#  Having processed all items - if Page 1 of genre then add menus for other pages in same genre.  
#  First find out how many pages.

	if ($pageno == 1) {
		for (my $i = 2; $i <= $totalpages; $i++) { 
			push @$menu, {
				'name'	      => "Page $i of $totalpages",
				'url'         => '',
				'type'        => 'link',	
				'passthrough' => [ { 'url' => $searchurl ."&p=$i", 'pageno' => $i,
									'codeRef'     => 'getSearch'}	],
			};	
		}
	}

# All done 
	if (scalar @$menu == 0) {
		push @$menu , {
			'name'	      => 'No programs found',
		} ;
	}

	$log->debug("Dump of menu ". Dumper($menu));

	# return menu
	return $menu ;

}

#  Get playable URLs for a station Id.  Station type can be either a STATION or PODCAST

sub parseStationURLReply {

	my $http = shift;

	my @menu;
	
#  In the web page there is a JSON chunk of data assigned to a variable window.__CONTEXT_PROVIDER__ 
	my $json_all = extractJSONdata($http,  WEBPAGE_JSON_ANCHOR_2);
	my $jsondata = $json_all->{'props'}->{'pageProps'};
    
    my @datakeys = keys (%{$json_all->{'props'}->{'pageProps'}->{'data'}});
    $log->info(" Keys in props->pageProps->data  ". join(', ', @datakeys));

# Stations URLs are in broadcast-> streams,   (used to be result-> streams)  - this has changed with web site changes.

	unless (defined ($jsondata->{'data'}->{'broadcast'}->{'streams'})) {
		$log->error(' No Streams found in URL reply found - perhaps plugin needs to be updated.');
		push @menu , {
			'name'	      => 'No programs found',
		} ;
		return \@menu;
	};

#	$log->error(" JSON ". Dumper($jsondata));	
	my $station_player   = $jsondata->{'data'}->{'broadcast'};
	my $streams          = $jsondata->{'data'}->{'broadcast'}->{'streams'};

	my $icon   = getstationlogo($station_player);
	my $title  = $station_player->{'name'};
	my $desc   = $station_player->{'shortDescription'};
	my $artist = $station_player->{'country'};
	my $id     = $station_player->{'id'};

# Two types ofprocessing STATION and PODCAST  - podcast have optional many episodes
	if ($station_player->{'type'} eq 'STATION') {
		my $sourceurls = $station_player->{'streams'};
		$log->info("STATION sourceurls $title ". Dumper(\$sourceurls));

# Note each URL seen to make list of unique URLs as there may be repeats in streamUrls
		my %seen;
		
		foreach my $stream (@{$sourceurls}) {
			if (!exists($seen{$stream->{'url'}})) {
				
				my $format = ($stream->{'url'} =~m/^https:\/\//) ? 'secure ' : undef;
				$format =  ($format . $stream->{'contentFormat'}) if (defined ($stream->{'contentFormat'}) ); 
				$format = " ($format)" if (defined($format));
				
				$seen{$stream->{'url'}} = 1;
						
				push @menu, { 
					'name'        => $title . $format,
					'image'		  => $icon,
					'type'        => 'audio',
					'url'         => $stream->{'url'},
					'on_select'   => 'play',
					'description' => $desc,
				};
			}
		}
    
        my $similarmenu = makePlayablesMenu($jsondata->{'data'}->{'similarStations'}->{'playables'});
        if (defined ($similarmenu)) {
            push @menu, { 
					'name'        => $similarStationMenuText,
                    'items'       => $similarmenu
				};
        }

#		$log->error(" Dump of menu ". Dumper(\@menu));		
#  Return with Radio station data - make the URLs into a playlist
		return \@menu;
		
	}

#  For podcast the streamUrls has the podcast feed.  Most time works wioth LMS Podcast player.

	if ($station_player->{'type'} eq 'PODCAST') {
		$log->error(" Podcast player ". Dumper($station_player));			
	}

#  Not STATION or PODCAST playable type - so return undef.
	
	return undef;

	
}

# This reply has multiple stations - there could be multiple URLS but only first used - FIXUP

sub parsePodcastsReply {
	
	my $jsoncontent = shift;
	my $jsondata = eval { from_json($jsoncontent) };
	
	if ($@) {
		$log->error("Error parsing JSON data $@");
		return;
	}

	my @menu;
	
	my $episodes   = $jsondata->{'episodes'};
	my $totalCount = $jsondata->{'totalCount'};
	$log->info(" Total count of podcast episodes: $totalCount");
	
	foreach my $episode (@$episodes) {
		my $title  = $episode->{'title'};
		my $desc   = $episode->{'description'};

		my $format = ($episode->{'url'} =~m/^https:\/\//) ? 'secure ' : undef;
		$format    =  ($format . $episode->{'contentFormat'}) if (defined ($episode->{'contentFormat'}) ); 
		$format    = " ($format)" if (defined($format));
		
		my $icon   =   $episode->{'parentLogo300x300'} ?  $episode->{'parentLogo300x300'} 
					 : $episode->{'parentLogo100x100'} ?  $episode->{'parentLogo100x100'} 
					 : $episode->{'parentLogo630x630'} ?  $episode->{'parentLogo630x630'} 
					 : $episode->{'parentLogo175x175'} ?  $episode->{'parentLogo175x175'} 
					 : Plugins::RadioNet::Plugin->_pluginDataFor('icon') ;
		push @menu, { 
				'name'        => $title . $format,
				'image'		  => $icon,
				'icon'		  => $icon,
				'type'        => 'audio',
				'url'         => $episode->{'url'},
				'on_select'   => 'play',
				'description' => $desc,
		};
	}
	return \@menu;
}

sub parseListMenuReply {
	my $http = shift;
	my $url  = shift;
	
	my ($baseurl,$opts) = getopts($url);
	
	my $pageno =1  ;
	
    my $menu;
    my $stationsmatched;
    my $totalpages;
    
    if ($url =~ m/&|\?p=(\d+)/) {
		$pageno = $1;
    };

#  In the web page there is a JSON chunk of data assigned to a variable window.__CONTEXT_PROVIDER__ 
	my $json_all = extractJSONdata($http,  WEBPAGE_JSON_ANCHOR_2);
	
	my $jsondata = $json_all->{'props'}->{'pageProps'};
	
# check for results

	unless (defined ($jsondata->{'data'}->{'stations'}->{'playables'})) {
		$log->error(" No Playables found in paged list reply - perhaps plugin needs to be updated.");
		push @$menu , {
			'name'	      => 'No programs found',
		} ;
		return $menu;
	};

	my $totalcount     = $jsondata->{'data'}->{'stations'}->{'totalCount'};
	my $stationscount  = scalar (@{$jsondata->{'data'}->{'stations'}->{'playables'}});
	
	my $totalpages = 1;
	if ($totalcount > $stationscount) {
		$totalpages = int(($totalcount + ($stationscount - 1))/ $stationscount); # Round up to get number of pages available
	}
	
	$menu = makePlayablesMenu($jsondata->{'data'}->{'stations'}->{'playables'});
	$log->info(" Menu ". Dumper(@$menu));

#  Having processed all items - if Page 1 of genre then add menus for other pages in same genre.  
#  First find out how many pages.

	if ($pageno == 1) {
		for (my $i = 2; $i <= $totalpages; $i++) { 
			push @$menu, {
				'name'	      => "Page $i of $totalpages",
				'url'         => '',
				'type'        => 'link',	
				'passthrough' => [ { 'url' => $baseurl ."?p=$i", 'pageno' => $i,
									'codeRef'     => 'getPagedLists'}	],
			};	
		}
	}

# All done 
	if (scalar @$menu == 0) {
		push @$menu , {
			'name'	      => 'No Genres programs found',
		} ;
	}

	$log->debug("Dump of menu ". Dumper($menu));

	# return menu
	return $menu ;

}

sub makePlayablesMenu {

	my $stations = shift;

	my @menu;
	
	foreach my $station (@{$stations}) {
		
		my $stationname = $station->{'name'};
		next unless defined ($stationname);

		my $stationtype = $station->{'type'};
		my $stationdesc = makestationdesc($station);
		my $stationlogo = getstationlogo($station);		
		

#  If stations 'playable' is TRUE then it has streams of valid URLs
#  otherwise just a stationID which will be used later to get playable URL
		
		if (defined($station->{'playable'}) && $station->{'playable'} ) {
			my $stationurl = $station->{'streams'}[0]->{'url'};
			push @menu, {
					'name'	      => $stationname . $stationdesc,
					'image'       => $stationlogo,
					'icon'        => $stationlogo,
					'url'         => $stationurl ,
					'description' => $stationdesc,
					'on_select'   => 'play',
					'type'        => 'audio',	
			};

		} else {
			if ($stationtype eq 'STATION' ) {
				push @menu, {
					'name'	      => $stationname . $stationdesc,
					'image'       => $stationlogo,
					'icon'        => $stationlogo,
					'url'         => '' ,
					'type'        => 'link',	
					'passthrough' => [
									{	'stationurl'  => "$localedomain/s/$station->{'id'}" ,
										'stationlogo' => $stationlogo,
										'codeRef' 	  => 'getStationURLs'}
									],
				};

			} else { 		# otherwise assume it is PODCAST
				push @menu, {
					'name'	      => "$stationname (podcast) $stationdesc",
					'image'       => $stationlogo,
					'icon'        => $stationlogo,
					'url'         => '' ,
					'type'        => 'link',	
					'passthrough' => [
									{	'podcastid' 	=> $station->{'id'},
										'stationlogo'	=> $stationlogo,
										'codeRef' 		=> 'getPodcastURLs'}
									],
					};
			};
				
		}
	}

# All done 
	if (scalar @menu == 0) {
		push @menu , {
			'image'		  => undef ,
			'name'	      => 'No programs found',
			'type'        => 'text',	
		} ;
	}

	$log->debug("Dump of menu ". Dumper(\@menu));
	return \@menu;
}

# This reply has multiple stations - there could be multiple URLS but only first used - FIXUP

sub parseStreamsReply {
	
	my $jsoncontent = shift;
	my $jsondata = eval { from_json($jsoncontent) };
	
	if ($@) {
		$log->error("Error parsing JSON data $@");
		return;
	}

	my $stations = $jsondata->{'playables'};
	my $menu     = makePlayablesMenu($stations);
	
	return $menu;
}


sub makestationdesc {
	my $station     = shift;
	my $stationdesc = ' (';
	
# Check which form of station record - matched ones have a HASH with 'value' whereas others have just a string. 	
	
	if (ref($station->{'name'}) eq 'HASH' ) {
		$stationdesc .=  $station->{'city'}->{'value'} . ', ' if defined($station->{'city'}->{'value'}); 
		$stationdesc .=  $station->{'country'}->{'value'} ;
		
		if (defined ($station->{'genres'}[0]->{'value'})) {
			my $genrelist;
			foreach my $entry (@{$station->{'genres'}}) {
				$genrelist .= $entry->{'value'} .',';
			}
			chop $genrelist ; # remove last comma;
			$stationdesc .= '/'.$genrelist;
		};
		
	} else {
		$stationdesc .=  $station->{'city'} . ', ' if defined($station->{'city'}) ;
		$stationdesc .=  $station->{'country'} ;
		$stationdesc .= ' / '. join(', ',@{$station->{'genres'}}) if (defined ($station->{'genres'}));
	}
	
	$stationdesc .= ')' ;

	return $stationdesc;
}


sub getstationlogo {
	my $station = shift;
	my $stationlogo =  $station->{'logo300x300'} ?  $station->{'logo300x300'} 
					 : $station->{'logo100x100'} ?  $station->{'logo100x100'} 
					 : $station->{'logo630x630'} ?  $station->{'logo630x630'} 
					 : $station->{'logo175x175'} ?  $station->{'logo175x175'} 
					 : Plugins::RadioNet::Plugin->_pluginDataFor('icon') ;

	return $stationlogo;
}

sub getDisplayName { 'PLUGIN_RADIONET' }

sub playerMenu { shift->can('nonSNApps') && $prefs->get('is_app') ? undef : 'RADIO' }

1;
