package Plugins::RadioNet::Plugin;

# Plugin to get station from Radio,net
#
# Released under GPLv2

use strict;

use base qw(Slim::Plugin::OPMLBased);


use File::Spec::Functions qw(:ALL);
use Plugins::RadioNet::Settings;
use Slim::Utils::Prefs;

my $prefs = preferences('plugin.radionet');

my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.radionet',
	'defaultLevel' => 'ERROR',
	'description'  => getDisplayName(),
});

my @opmlfiles = ('menu-en.opml', 'menu-pt.opml', 'menu-pt-br.opml', 
				 'menu-it.opml', 'menu-se.opml', 'menu-fr.opml', 
				 'menu-es.opml', 'menu-es-mx.opml', 'menu-es-co.opml', 
				 'menu-de.opml', 'menu-de-at.opml', 'menu-pl.opml', 
				 'menu-dk.opml'); 

sub initPlugin {
	my $class = shift;

	Plugins::RadioNet::Settings->new($class);
	Plugins::RadioNet::Settings->init($class);

	my $opmlfile =  $opmlfiles[$prefs->get('radionetlocale')];
	
	$log->info(" Locale ". $prefs->get('radionetlocale') .  " file  $opmlfile");

	my $file = catdir( $class->_pluginDataFor('basedir'), $opmlfile );

	$class->SUPER::initPlugin(
		feed   => Slim::Utils::Misc::fileURLFromPath($file),
		tag    => 'radionet',
		is_app => $class->can('nonSNApps') && $prefs->get('is_app') ? 1 : undef,
		menu   => 'radios',
		weight => 1,
	);

	Plugins::RadioNet::Settings->new;

}

sub getDisplayName { 'PLUGIN_RADIONET' }

sub playerMenu { shift->can('nonSNApps') && $prefs->get('is_app') ? undef : 'RADIO' }

1;
