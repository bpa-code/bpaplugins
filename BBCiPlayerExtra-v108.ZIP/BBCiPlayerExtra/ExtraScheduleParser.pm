package Plugins::BBCiPlayerExtra::ExtraScheduleParser;

use strict;

use Slim::Utils::Log;

use XML::Simple;
use Date::Parse;

use Data::Dumper;

my $log = logger('plugin.bbciplayer.extra');

# split option string into options and filters
# valid options are:
# filter:<name>=<regexp> - filter to only include where <name> matches <regexp> 
# byday                  - include by day menus
# bykey                  - include menus grouped by brand/serial/title
# nocache                - don't cache parsed result [cacheing is per url so may need to turn off]
# reversedays            - list days in reverse order (use with byday)
# reverse                - list entries in reverse order (in list or by key display)

sub _getopts {
	my $class  = shift;
	my $optstr = shift;
	my $opts   = shift;
	my $filters= shift;

	for my $opt (split /\&/, $optstr) {
		if    ($opt =~ /filter:(.*)=(.*)/) { $filters->{lc($1)} = $2 }
		elsif ($opt =~ /(.*)=(.*)/       ) { $opts->{lc($1)}    = $2 } 
		else                               { $opts->{lc($opt)}  =  1 }
	}
}

sub parse {
    my $class  = shift;
    my $http   = shift;
	my $optstr = shift;

    my $params = $http->params('params');
    my $url    = $params->{'url'};
	my $opts   = {};
	my $filters= {};


   my @menu;
	$class->_getopts($optstr, $opts, $filters);

	my $xml = eval {
		XMLin( 
			$http->contentRef,
			ForceArray => ["broadcast"], 
			KeyAttr => []
		)
	};

	if ($@) {
		$log->error("$@");
		return;
	}

	my $broadcast = $xml->{'day'}->{'broadcasts'}->{'broadcast'};

	for my $entry (@{$broadcast}) {
		$log->debug("Start Time=".$entry->{'start'} . "Pid ". $entry->{'programme'}->{'pid'} .
                                                          "  Title ". $entry->{'programme'}->{'display_titles'}->{'title'} . 
                                                       " Synopsis: ". $entry->{'programme'}->{'short_synopsis'} .
							" Audio format: " . ((defined($entry->{'programme'}->{'media'})) ? $entry->{'programme'}->{'media'}->{'format'}   : "*********No Format ******" )  
                                        );
		my $start = str2time($entry->{'start'});
		my ($min, $hour, $day, $wday) = (localtime($start))[1,2,3,6];

		if (defined($entry->{'programme'}->{'media'})) {
			push @menu, {
					'name'	      => sprintf("%02d:%02d %s",$hour,$min,$entry->{'programme'}->{'display_titles'}->{'title'}),
#					'url'         => 'http://www.bbc.co.uk/iplayer/playlist/' . $entry->{'programme'}->{'pid'} ,
					'url'         => 'http://www.bbc.co.uk/programmes/'. $entry->{'programme'}->{'pid'} . '/playlist.json' ,
					'type'        => 'playlist',
					'on_select'   => 'play',
					'parser'      => 'Plugins::BBCiPlayerExtra::ExtraPlayableParser',
					'description' =>  $entry->{'programme'}->{'short_synopsis'},
			}
		} else {
			push @menu, {
					'name'	      => sprintf("%02d:%02d %s",$hour,$min,$entry->{'programme'}->{'display_titles'}->{'title'}),
					'description' =>  $entry->{'programme'}->{'short_synopsis'},
			}

		};

	}

	if ($opts->{'topmenu'} ) {
		my $rooturl = $url;
		$rooturl  =~ s/\/today\.xml/\//;
		my $stationname = $params->{'feedTitle'};

		my @weekdays = qw(Sun Mon Tue Wed Thu Fri Sat);
		my @subnextmenu;
		my $now        = time();
		for (my $i=0 ; $i < 7 ; $i++) {
			my ($day, $month, $year, $wday) = (localtime($now + ($i* 60 * 60 * 24 )))[3,4,5,6];
			push @subnextmenu, {
					'name'	      => sprintf('%s %s %02d / %02d', $stationname,   $weekdays[$wday],  $day, $month+1),
					'url'         => sprintf('%s%04d/%02d/%02d.xml', $rooturl, $year+1900, $month+1, $day) ,
					'type'        => 'playist',
					'parser'      => 'Plugins::BBCiPlayerExtra::ExtraScheduleParser',
			}			
		}
		my @sublastmenu;
		for (my $i=0 ; $i < 7 ; $i++) {
			my ($day, $month, $year, $wday) = (localtime($now - ($i* 60 * 60 * 24 )))[3,4,5,6];
			push @sublastmenu, {
					'name'	      => sprintf('%s %s %02d / %02d', $stationname,   $weekdays[$wday],  $day, $month+1),
					'url'         => sprintf('%s%04d/%02d/%02d.xml', $rooturl, $year+1900, $month+1, $day) ,
					'type'        => 'playist',
					'parser'      => 'Plugins::BBCiPlayerExtra::ExtraScheduleParser',
			}			
		}
		push @menu, {
			'name'	      => $stationname . ' Yesterday',
			'url'         =>  $rooturl . 'yesterday.xml' ,
			'type'        => 'playist',
			'parser'      => 'Plugins::BBCiPlayerExtra::ExtraScheduleParser',
			} ;
		push @menu, {
			'name'	      => $stationname . ' Tomorrow',
			'url'         => $rooturl . 'tomorrow.xml' ,
			'type'        => 'playist',
			'parser'      => 'Plugins::BBCiPlayerExtra::ExtraScheduleParser',
			} ;	

		push @menu, {
			'name'  => $stationname . ' Next week ',
			'items' => \@subnextmenu,
			'type'  => 'opml',
		};
		push @menu, {
			'name'  => $stationname . ' Last week ',
			'items' => \@sublastmenu,
			'type'  => 'opml',
		};
	
	}

	# return xmlbrowser hash
	return {
		'name'    => $params->{'feedTitle'},
		'items'   => \@menu,
		'type'    => 'opml',
		'nocache' => $opts->{'nocache'},
	};
}

1;
