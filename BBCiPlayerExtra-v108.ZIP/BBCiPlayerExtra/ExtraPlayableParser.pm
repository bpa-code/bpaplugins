package Plugins::BBCiPlayerExtra::ExtraPlayableParser;

use strict;

use XML::Simple;
use JSON::XS::VersionOneAndTwo;
use HTML::Entities;

use Slim::Utils::Log;
use Slim::Utils::Prefs;

use URI::Escape qw(uri_escape_utf8 uri_unescape);

use Data::Dumper;

use constant TTL_EXPIRE => 10;

my $log = logger('plugin.bbciplayer.extra');

my $prefs = preferences('plugin.bbciplayer');

sub parse {
    my $class  = shift;
    my $http   = shift;
    my $params = $http->params('params');
    my $url    = $params->{'url'};


#
# If got an MTIS URL then finally got all the required info - mainly duration and PID
#
#
#    if ($url =~ m/http:\/\/www\.bbc\.co\.uk\/mediaselector\/4\/mtis\/stream/) {

    if ($url =~ m/http:\/\/open\.live\.bbc\.co\.uk\/mediaselector\/5\/select\/version\/2\.0\/vpid\//) {
	$log->info("Extra Playable mtis URL  =". $url);
	$log->debug("Extra Playable mtis URL  =". ${$http->contentRef});

	my $client = $params->{'client'};
        my $item   = $params->{'item'};

	my $title  = $item->{'streamtitle'} || $item->{'name'} || $item->{'title'} || $params->{'feedTitle'};
	my $icon   = $item->{'icon'};
	my $desc   = $item->{'description'};
	my $dur    = $item->{'dur'};
	my $artist = $item->{'artist'};

	$icon =~ s/150_84/178_100/;
	$icon =~ s/640_360/178_100/;
	my $aac = 0;

	my @playerFormats = exists &Slim::Player::CapabilitiesHelper::supportedFormats 
		? Slim::Player::CapabilitiesHelper::supportedFormats($client) 
		: $client->formats;

	for my $format (@playerFormats) {
		if (Slim::Player::TranscodingHelper::checkBin("aac-$format-*-*")) {
			$aac = 1;
			last;
		}
	}

	my $stream  = "iplayer://aod?ms=$url&dur=$dur&icon=$icon&title=" . uri_escape_utf8($title) . "&desc=" . uri_escape_utf8($desc);

	return {
		'type'  => 'opml',
		'items' => [ {
			'name' => $title,
			'artist' => $artist,
			'url'  => $stream,
			'type' => 'audio',
			'icon' => $icon,
			'description' => $desc,
		} ],
		'cachetime' => 0,
		'replaceparent' => 1,
	};
    }

#
#  Process the XML Playlist details to get duration and PID needed for MTIS url - 
#

    if ($url =~ m/http:\/\/www\.bbc\.co\.uk\/iplayer\/playlist\//) {

	$log->error("Extra Playable playlist URL  =". $url );
	
	my $xml = eval {
		XMLin( 
			$http->contentRef,
			ForceArray => ["item"], 
			KeyAttr => ["rel"]
		)
	};
	if ($@) {
		$log->error("$@");
		return;
	};

	my $playlistitem;

	foreach my $item  (@{$xml->{'item'}}) {
		if ($item->{'kind'} eq 'radioProgramme'  ) {
			$playlistitem = $item;
			last;
		};
	}

	my $title =  $playlistitem->{'title'};
	my $icon  =  $xml->{'link'}->{'holding'}->{'href'};
	
	my $desc  =  $xml->{'summary'};
#	BBC sometimes uses wide char quotes - change to ASCII single quote as BBCiPlayer plugin doesn't support wide chars.
	$desc =~ s/\x{2019}/'/g;
	$desc =~ s/\x{2018}/'/g;

	my $dur   =  $playlistitem->{'duration'};
	my $pid   =  $playlistitem->{'identifier'};

	$params->{'item'}->{'streamtitle'} = $title;
	$params->{'item'}->{'name'}        = $title;
	$params->{'item'}->{'streamtitle'} = $title;
	$params->{'item'}->{'feedTitle'}   = $title;
	$params->{'item'}->{'dur'}         = $dur;
	$params->{'item'}->{'description'} = $desc;
	$params->{'item'}->{'artist'}      = $playlistitem->{'service'}->{'content'};
	if (! defined($params->{'item'}->{'icon'})) {
#		$params->{'item'}->{'icon'} = 'http://node1.bbcimg.co.uk/iplayer/images/episode/' . $playlistitem->{'group'} . '_178_100.jpg' ;
		$params->{'item'}->{'icon'} = $xml->{'link'}->{'holding'}->{'href'};
	}

	return {
		'type'    => 'redirect',
		'url'     => 'http://open.live.bbc.co.uk/mediaselector/5/select/version/2.0/vpid/'. $pid .'/mediaset/pc' ,
#		'url'     => 'http://www.bbc.co.uk/mediaselector/4/mtis/stream/'. $pid ,
	};

   }
   
#
#  Process a JSON Playlist details to get duration and PID needed for MTIS url - 
#

    if ($url =~ m/playlist.json/) {

	$log->error("Extra Playable playlist URL  =". $url );
	my $json = eval { from_json( ${$http->contentRef} ) };	
	if ($@) {
		$log->error("$@");
		return;
	};
	$log->debug("Dump JSON of URL \n", Dumper($json));

	my $playlistitem = $json->{'defaultAvailableVersion'}->{'smpConfig'};
	if ($playlistitem->{'items'}[0]->{'kind'} ne 'radioProgramme'  ) {
		$log->error("playlistitem not a radioprogramme \n", Dumper($playlistitem));
	};

	my $title =  $playlistitem->{'title'};
	my $icon  =  $playlistitem->{'holdingImageURL'};
	$icon =~ s/\$recipe/640x360/;
	
	my $desc  =  $playlistitem->{'summary'};
#	BBC sometimes uses wide char quotes - change to ASCII single quote as BBCiPlayer plugin doesn't support wide chars.
	$desc =~ s/\x{2019}/'/g;
	$desc =~ s/\x{2018}/'/g;

	my $dur   =  $playlistitem->{'items'}[0]->{'duration'};
	my $pid   =  $playlistitem->{'items'}[0]->{'vpid'};

	$params->{'item'}->{'streamtitle'} = $title;
	$params->{'item'}->{'name'}        = $title;
	$params->{'item'}->{'streamtitle'} = $title;
	$params->{'item'}->{'feedTitle'}   = $title;
	$params->{'item'}->{'dur'}         = $dur;
	$params->{'item'}->{'description'} = $desc;
	$params->{'item'}->{'artist'}      = $playlistitem->{'service'}->{'content'};
	$params->{'item'}->{'icon'} = $icon;

	return {
		'type'    => 'redirect',
		'url'     => 'http://open.live.bbc.co.uk/mediaselector/5/select/version/2.0/vpid/'. $pid .'/mediaset/pc' ,
#		'url'     => 'http://www.bbc.co.uk/mediaselector/4/mtis/stream/'. $pid ,
	};
   }   
}


# Local Variables:
# tab-width:4
# indent-tabs-mode:t
# End:

1;
