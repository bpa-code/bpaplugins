package Plugins::Live365::Plugin;


# Copyright (C) 2022 baltontwo@eircom.net
#
# This file is part of LMS Live365 Plugin.
#
# Live365 Plugin is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# LMS_Live365_Plugin is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with LMS Live365 Plugin.  If not, see <http://www.gnu.org/licenses/>.

use strict;

use base qw(Slim::Plugin::OPMLBased);

use JSON::XS::VersionOneAndTwo;
use Digest::MD5 qw(md5_hex);
use URI::Escape;
use MyText::Balanced;

use Slim::Utils::Log;
use Slim::Utils::Cache;
use Slim::Utils::Prefs;

use Plugins::Live365::Settings;

use constant WEBPAGE_JSON_ANCHOR => 'id="__NEXT_DATA__" type="application/json">';
use constant LIVE365URL    => 'http://www.live365.com';
use constant LIVE365APIURL => 'http://api.live365.com';

use Data::Dumper;

my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.live365',
	'defaultLevel' => 'ERROR',
	'description'  => getDisplayName(),
});

my $prefs      = preferences('plugin.live365');
my $pluginName = 'Live365';

use constant CACHEONEHOUR   =>  3600; 
use constant CACHE15MINS    =>   900;    

my $cache = Slim::Utils::Cache->new();
$cache->clear();

sub getCachedMenu {
	my $url = shift;

	my $cacheKey = $pluginName . ':' . md5_hex($url);

	if ( my $cachedMenu = $cache->get($cacheKey) ) {
		my $menu = ${$cachedMenu};
		return $menu;
	};
	return;
}

sub cacheMenu {
	my ( $url, $menu, $seconds ) = @_;	

	my $cacheKey = $pluginName . ':' . md5_hex($url);
	$cache->set( $cacheKey, \$menu, $seconds );

	return;
}

# Fixup callable routine table - fixup need because CODE cannot be saved when menu is cached.

my %subItems = (
	'getGenres' 	    => \&getGenres,
    'getGenresResults'  => \&getGenresResults,    
	);


sub fixupCodeRefs {
	my $menu = shift;

	for my $menuItem (@$menu) {
		my $codeRef = $menuItem->{passthrough}[0]->{'codeRef'};
#		$log->info(" Fixup menu $codeRef for ".$menuItem->{'name'} );

		if ( defined $codeRef ) {
			$log->error("Fixup failed for undefined routine: $codeRef ") unless (exists($subItems{$codeRef}));
			$menuItem->{'url'} = $subItems{$codeRef};
		}
# Fixup submenu if one is present
		fixupCodeRefs($menuItem->{'items'}) if (defined $menuItem->{'items'}) ;
	}
	return;
}
				 
sub initPlugin {
	my $class = shift;

# live365results is the number of pages with 20 entries per page so 8 is 160.
	$prefs->init({ is_app => 0 , live365results => 8, defaulturl => 1 });

	Plugins::Live365::Settings->new($class);
	Plugins::Live365::Settings->init($class);

	$class->SUPER::initPlugin(
		feed   => \&handleFeed,
		tag    => 'live365',
		is_app => $class->can('nonSNApps') && $prefs->get('is_app') ? 1 : undef,
		menu   => 'radios',
		weight => 1,
	);

	Plugins::Live365::Settings->new;
    createMenus();
}
				 
sub extractJSONdata {

	my $webpage     = shift;
	my $splitstring = shift;
	
# Split webpage at boundary with start of JSON data 	
	my ($before, $after) = split ($splitstring,$webpage,2);
	
# Find the balanced closing brace for the JSON data.	
	my 	@result = MyText::Balanced::extract_bracketed( $after, '{"}' );
	
# JSON data is parsed and converted. 
	my 	$jsondata = eval { from_json($result[0]) };
#    $log->error(" JSON extract ". Dumper(\$jsondata));

	if ($@) {
		$log->error("Error parsing JSON data $@");
		return;
	}
	
	return $jsondata;	
}				 


my $topStationsMenu;
my $featuredMenu;
my $buildId;

sub createMenus {

	Slim::Networking::SimpleAsyncHTTP->new(
		sub { 						# Success - page fetched.
			my $http = shift;

			my $jsondata     = extractJSONdata($http->content, WEBPAGE_JSON_ANCHOR);
			$log->debug("NEXT_ID data ". Dumper(\$jsondata));
			$buildId = $jsondata->{'buildId'};
			
			$cache->clear();

			$topStationsMenu = makeTopStationsMenu($jsondata->{'props'}->{'pageProps'}->{'topStations'} );
			$featuredMenu    = makeFeaturedMenu   ($jsondata->{'props'}->{'pageProps'}->{'featuredStations'});
		},
		
		sub { # Page fetch error 
			my $http = shift;
			my $error  = $http->error;			
			$log->error(" Failed to get initial page from Live365.com - error: $error");
		},
        {
           cache => 1,
           expires => CACHE15MINS,
        }
	)->get(LIVE365URL)	
}


sub handleFeed {
	my ($client, $callback, $params, $args) = @_;
    
#    $log->error(" Callback is ".Slim::Utils::PerlRunTime::realNameForCodeRef($callback)");

# Need to re-fetch BuildId as it can change but not frequently so value is cached for 15 mins 

	Slim::Networking::SimpleAsyncHTTP->new(
		sub { 						# Success - page fetched.
			my $http = shift;

			my $jsondata     = extractJSONdata($http->content, WEBPAGE_JSON_ANCHOR);
			$log->debug("NEXT_ID data ". Dumper(\$jsondata));
			$buildId = $jsondata->{'buildId'};
			
            my $menu = [
                {
                    name        => 'Search',
                    type        => 'search',
                    url         => \&getSearch,
                    passthrough => [ { 'pageno' => 1, 'searchtype' => 'general'} ],
                },	
                {
                    name        => 'Top Stations',
                    type        => 'link',
                    items       => $topStationsMenu,
                },	
                {
                    name        => 'Featured',
                    type        => 'link',
                    items       => $featuredMenu,
                },	
                {
                    name        => 'Genres',
                    type        => 'link',
                    url         => \&getGenres,
                },	
            ];
            $callback->( { items => $menu } );    
 		},
		
		sub { # Page fetch error 
			my $http = shift;
			my $error  = $http->error;			
			$log->error(" Failed to get initial page from Live365.com - error: $error");
		},
        {
           cache => 1,
           expires => CACHE15MINS,
        }
	)->get(LIVE365URL)	

	
}

sub makeTopStationsMenu {
    
    my $topstations = shift;
    my @menu;
    
    foreach my $topstation  (@$topstations) {
        push @menu, {
				'name'        => $topstation->{'name'},
				'image'		  => $topstation->{'logo'},
				'icon'		  => $topstation->{'logo'},
				'type'        => 'audio',
				'url'		  => $topstation->{'streamUrl'}->{'default'},
				'on_select'   => 'play',
				'description' => $topstation->{'description'},        
                }
    }
    return \@menu;
}

sub makeFeaturedMenu {
    my $featured    = shift;
    my @menu;
    
    foreach my $feature  (@$featured) {
        push @menu, {
				'name'        => $feature->{'name'},
				'image'		  => $feature->{'logo'},
				'icon'		  => $feature->{'logo'},
				'type'        => 'audio',
				'url'		  => $feature->{'streamUrl'},
				'on_select'   => 'play',
				'description' => $feature->{'description'},        
                }
    }
    return \@menu;
}

sub commonFetchParse {
	my ( $client, $callback, $args, $passthrough,$sourceUrl, $parseRoutine ) = @_;
	
	if (  my $cachemenu = getCachedMenu($sourceUrl) )  {
		fixupCodeRefs($cachemenu);
		$callback->( { items => $cachemenu } );
		return;
	}
    
    $log->debug(" Fetching url $sourceUrl");
	my $starttime  = Time::HiRes::time() ;
	Slim::Networking::SimpleAsyncHTTP->new(
		sub {
			my $http = shift;
			
			my $fetchedtime = Time::HiRes::time() - $starttime ;
			my $menu = $parseRoutine->($http->content,$sourceUrl);
			my $parsedtime = Time::HiRes::time() - $starttime ;
			
			$log->info(sprintf("Fetch delay %15.6f  Parse delay %15.6f for url %s ",$fetchedtime,$parsedtime, $sourceUrl)); 

			cacheMenu($sourceUrl, $menu, CACHEONEHOUR);			
			fixupCodeRefs($menu);
			$callback->( { items => $menu } );
		},

		# Called when no response was received or an error occurred.
		sub {
			$log->warn("Error on url \"$sourceUrl\" : $_[1] ");
			$callback->( [ { name => $_[1], type => 'text' } ] );
		}
	)->get($sourceUrl);

	return;
}

sub getGenres {
	my ( $client, $callback, $args, $passthrough ) = @_;
	
	my $genresUrl = 'https://api.live365.com/genres';

	commonFetchParse($client, $callback, $args, $passthrough,
					$genresUrl,
					\&parseTopGenresReply);
};

sub getGenresResults {
	my ( $client, $callback, $args, $passthrough ) = @_;
    
    $log->debug(" passthrough ".Dumper(\$passthrough));
	
	my $subgenresUrl = $passthrough->{'url'};

	commonFetchParse($client, $callback, $args, $passthrough,
					$subgenresUrl,
					\&parseGenresResultsReply);
}

# Search results are not cached - maybe it shoudl be.

sub getSearch {
	my ( $client, $callback, $args, $passthrough ) = @_;

	my $searchUrl;

# Example 
# https://live365.com/_next/data/n9L2JMs69gvuJxCm1bEnR/listen/search.json?query=baroque
# https://live365.com/_next/data/n9L2JMs69gvuJxCm1bEnR/listen/search.json?query=acid+jazz
# https://live365.com/listen/search?query=rock&page=3

# Search reslts are paged but cumulative Page 1 has 20 hits, page 2 has 40 hits 
# Currently Live365 returns 20 hits per page.

    
    my $maxpage = $prefs->get('live365results'); 

#  Search key is defined on first search - subsequent pages of search results may be different

	if (defined($args->{'search'})) {
	    my $searchstr = URI::Escape::uri_escape_utf8($args->{'search'});
		$searchUrl = "https://live365.com/_next/data/$buildId/listen/search.json?query=$searchstr&page=$maxpage";
	} 
	commonFetchParse($client, $callback, $args, $passthrough,
					$searchUrl,
					\&parseSearchReply);
};

# Genres Name are not the same as used in the URLs.  Terminology used in JS is name -> slug.  
# Roughly all words in Genre descriptions are separated by hypens for URL but there are spacial cases.
# No mapping provided in page returned - so hack after looking for special cases.

# There are excpetion which are 'talk' stations.

my %talkstations = (
    'talk'          => 'talk-radio', 
    'comedy'        => 'comedy-radio', 
    'community'     => 'community-radio', 
    'educational'   => 'educational-radio', 
    'news'          => 'news-radio',
    'old-time-radio' => 'old-time-radio', 
    'politics'      => 'politics-radio', 
    'spoken-word'   => 'spoken-word-radio', 
    'sports'        => 'sports-radio' 
    );

sub mangleGenres {
 
    my $genre = shift;
    
    $genre = lc ($genre);
    my $origgenre = $genre;
    
    $genre =~ s/ \.\.\. /---/g;    # changes " ... " to hyphens
    $genre =~ s/ 'n' /-n'-/g;      # changes " 'n' " to hyphens
    $genre =~ s/r&b/rnb/g;         # changes "R&B" to "rnb"
    $genre =~ s/'s/s/g;            # changes "'s" top "s" as in 90's to 90s
    $genre =~ s/ /-/g;             # changes spaces to hyphens
    $genre =~ s/\//-/g;            # Change slash to hyphen

# Exception for 'talk' stations which are not 'music'
    if (exists($talkstations{$genre})) {
       $genre = $talkstations{$genre};
    } else {
       $genre = $genre . '-music-radio' ;
    }

# Example URL for "Blues"
# https://live365.com/_next/data/n9L2JMs69gvuJxCm1bEnR/listen/blues-music-radio.json?category=blues-music-radio
    
    return "https://live365.com/_next/data/$buildId/listen/$genre.json?category=$genre";
}

sub parseTopGenresReply {
	my $http = shift;
	my $url  = shift;
	
	my 	$jsondata = eval { from_json($http) };
	if ($@) {
		$log->error("Error parsing JSON data $@");
		return;
	}

#	$log->error("Genres JSON \n".Dumper(\$jsondata));
	
	my $topgenres = $jsondata;
	my @menu;
	foreach my $topgenre (@{$topgenres}) {
        
        my $topId      = $topgenre->{'id'};  
        my $topName    = $topgenre->{'name'};
        my $topIcon    = $topgenre->{'image'};
        my $topUrlName = mangleGenres($topName); 
        
        my $subgenres  = $topgenre->{'sub-genres'};
        
        my @submenu;
        
        push @submenu,  {
                'name'	      => 'All',
                'url'         => '', 
                'type'        => 'link',	
                'passthrough' => [ {'url' => $topUrlName ,
                                    'codeRef'     => 'getGenresResults'} ],
               } ;

        foreach my $subgenre (@{$subgenres}) {
            my $subId      = $subgenre->{'id'};  
            my $subName    = $subgenre->{'name'};
            my $subUrlName = mangleGenres($subName); 
            
            push @submenu, {
                    'name'	      => $subName,
                    'url'         => '', 
                    'type'        => 'link',
                    'passthrough' => [ {'url' => $subUrlName ,
                                        'codeRef'     => 'getGenresResults'} ],
                }
        }
        
		push @menu, {
			'name'	      => $topName,
            'icon'        => $topIcon,
            'image'       => $topIcon,
			'items'       => \@submenu,
#			'passthrough' => [ {'param' => $topgenre->{'param'}, 
#								'codeRef'     => 'getGenres'} ],
		};
	};
	$log->debug("Genres MENU \n".Dumper(\@menu));
	my @sortedMenu = sort { $a->{'name'} cmp $b->{'name'} } @menu;
	return \@sortedMenu;	
}

sub makeURLsSubmenu {
    
    
    my $stationDetails  = shift;
    my @submenu;
    
    my %formatorder = ('default' => 4, 'icyHigh' => 3, 'icyLow' => 2, 'hls' => 1);
    
       	foreach my $urlKey (keys %{$stationDetails->{'streamUrl'}}) {
            
          my $sortkey = defined($formatorder{$urlKey}) ? %formatorder{$urlKey}  : 0;

          push @submenu, {
				'name'        => sprintf("%s (%s)",$stationDetails->{'name'}, $urlKey),
				'image'		  => $stationDetails->{'logo'},
				'icon'		  => $stationDetails->{'logo'},
				'type'        => 'audio',
				'url'		  => $stationDetails->{'streamUrl'}->{$urlKey},
				'on_select'   => 'play',
				'description' => $stationDetails->{'description'},       
                'sortkey'     => $sortkey,
                }
        }
   	my @sortedMenu = sort { $b->{'sortkey'} <=> $a->{'sortkey'} } @submenu;
    return \@sortedMenu;
}

sub parseGenresResultsReply {
  	my $http = shift;
	my $url  = shift;
    
	my 	$jsondata = eval { from_json($http) };
	if ($@) {
		$log->error("Error parsing JSON data $@");
		return;
	}

#	$log->info("Genres JSON \n".Dumper(\$jsondata));
	
	my $results = $jsondata->{'pageProps'}->{'allStations'};
	my @menu;
	foreach my $result (@{$results}) {
        my $submenu = makeURLsSubmenu($result);
        $log->debug("submenu \n". Dumper($submenu));
        
        push @menu, {
				'name'        => $result->{'name'},
				'image'		  => $result->{'logo'},
				'icon'		  => $result->{'logo'},
				'type'        => 'audio',
				'url'		  => $result->{'streamUrl'}->{'default'},
				'on_select'   => 'play',
				'description' => $result->{'description'},        
                }
	}
    
	if (scalar @menu == 0) {
		push @menu , {
			'image'		  => undef ,
			'name'	      => 'No matches found',
			'type'        => 'text',	
		} ;
	}	

    return \@menu;
}

sub getHitStreamUrl {
    
    my $stream_urls = shift;
    
    foreach my $stream (@{$stream_urls}) {
       return $stream->{'high_quality'} if (defined($stream->{'high_quality'})); 
       return $stream->{'low_quality'}  if (defined($stream->{'low_quality'})); 
    }
    return ;
}


sub parseSearchReply {
	my $http = shift;
	my $url  = shift;
	
	my 	$jsondata = eval { from_json($http) };
	if ($@) {
		$log->error("Error parsing JSON data $@");
		return;
	}

	$log->debug("JSON \n".Dumper(\$jsondata));
    
    my $searchresult = $jsondata->{'pageProps'}->{'searchResult'};
    my $hits = $searchresult->{'hits'};
	
	my @menu; 
	foreach my $hit (@$hits) {
        push @menu, {
				'name'        => $hit->{'station-name'},
				'image'		  => $hit->{'logo'},
				'icon'		  => $hit->{'logo'},
				'type'        => 'audio',
				'url'		  => getHitStreamUrl($hit->{'stream_urls'}),
				'on_select'   => 'play',
				'description' => $hit->{'description'},        
                }

	}
    
	if (scalar @menu == 0) {
		push @menu , {
			'image'		  => undef ,
			'name'	      => 'No matches found',
			'type'        => 'text',	
		} ;
	}	
	return \@menu;
}

sub getDisplayName { 'PLUGIN_LIVE365' }

sub playerMenu { shift->can('nonSNApps') && $prefs->get('is_app') ? undef : 'RADIO' }

1;
