package Plugins::RadioNet::Plugin;

# Plugin to get station from Radio,net
#
# Released under GPLv2

use strict;

use base qw(Slim::Plugin::OPMLBased);

use MyText::Balanced;
use JSON::XS::VersionOneAndTwo;

use Digest::MD5 qw(md5_hex);
use URI::Escape;

use Slim::Utils::Log;
use Slim::Utils::Cache;
use Slim::Utils::Prefs;

use Plugins::RadioNet::Settings;

use Data::Dumper;

my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.radionet',
	'defaultLevel' => 'ERROR',
	'description'  => getDisplayName(),
});

my $prefs = preferences('plugin.radionet');

# Initialise some global variables to make sure they have default values.

my $localedomain      = 'https://www.radio.net';
my $localemessages;   # hash of message according to local

my $apidomain      = 'https://prod.radio-api.net';

# short lists are in SystemEnglish (i.e. domain independent key) and not localised form.

my $genresMenu;
my $countriesMenu;
my $topicsMenu;
my $podcastMenu;
my $editorMenu;
my $topTenStations;
my $topTopics;

my $pluginName = 'radionetV3';

use constant CACHEONEHOUR    =>  3600; 
use constant CACHETHREEHOURS => 10800; 
my $cache = Slim::Utils::Cache->new();
$cache->clear();


my @radionetdomains  = ('https://www.radio.net', 'https://www.radio.pt', 'https://br.radio.net', # 0,1,2
				 'https://www.radio.it', 'https://www.radio.se', 'https://www.radio.fr',         # 3,4,5
				 'https://www.radio.es', 'https://mx.radio.net', 'https://co.radio.net',         # 6,7,8
				 'https://www.radio.de', 'https://www.radio.at', 'https://www.radio.pl',         # 9, 10,11 
				 'https://www.radio.dk',                                                         # 12  
				 'https://uk.radio.net', 'https://ie.radio.net',                                 # 13,14       
				 'https://au.radio.net', 'https://nz.radio.net',                                 # 15,16 
				 'https://za.radio.net', 'https://ca.radio.net', 'https://nl.radio.net'          # 17, 18, 19
				 ); 


sub getopts {
	my $url = shift;

	my ($baseurl, $optstr) = split(/\?/, $url);
	my %opts;

	for my $opt (split /\&/, $optstr) {
		if ($opt =~ /(.*)=(.*)/       ) { $opts{lc($1)}    = $2 } 
		else                            { $opts{lc($opt)}  =  1 }
	}
	
	return ($baseurl,\%opts);
}

sub getCachedMenu {
	my $url = shift;

	my $cacheKey = $pluginName . ':' . md5_hex($url);

	if ( my $cachedMenu = $cache->get($cacheKey) ) {
		my $menu = ${$cachedMenu};
		return $menu;
	};
	return;
}

sub cacheMenu {
	my ( $url, $menu, $seconds ) = @_;	

	my $cacheKey = $pluginName . ':' . md5_hex($url);
	$cache->set( $cacheKey, \$menu, $seconds );

	return;
}

# Fixup callable routine table - fixup need because CODE cannot be saved when menu is cached.

my %subItems = (
	'getStationURLs'	 => \&getStationURLs,
	'getSearch'  		 => \&getSearch,
	'getPagedLists'   	 => \&getPagedLists,
	);

sub fixupCodeRefs {
	my $menu = shift;

	for my $menuItem (@$menu) {
		my $codeRef = $menuItem->{passthrough}[0]->{'codeRef'};
#		$log->error(" Fixup menu $codeRef for ".$menuItem->{'name'} );

		if ( defined $codeRef ) {
			$log->error("Fixup failed for undefined routine: $codeRef ") unless (exists($subItems{$codeRef}));
			$menuItem->{'url'} = $subItems{$codeRef};
		}
# Fixup submenu if one is present
		fixupCodeRefs($menuItem->{'items'}) if (defined $menuItem->{'items'}) ;
	}
	return;
}


sub updateLocale {
	my $sourceurl = 'https://www.radio.net';
	$localedomain = @radionetdomains[$prefs->get('radionetlocale')];
	
	$log->info(" Locale setting $localedomain");
	$sourceurl = $localedomain if (defined($localedomain));

	$cache->clear();
    makeGenreMenu();
	makeCountryMenu();
	makeTopicMenu();

}

sub initPlugin {
	my $class = shift;

	Plugins::RadioNet::Settings->new($class);
	Plugins::RadioNet::Settings->init($class);
	$log->info(" Init Plugin");

	$class->SUPER::initPlugin(
		feed   => \&handleFeed,
		tag    => 'radionet',
		is_app => $class->can('nonSNApps') && $prefs->get('is_app') ? 1 : undef,
		menu   => 'radios',
		weight => 1,
	);

	Plugins::RadioNet::Settings->new;
	updateLocale();

}

sub makeGenreMenu {
    makeNewListMenu ($localedomain . '/genre' ,    # Base URL for lists - country, Genres, topics
                \&getGenreStations,                # Function to be fxied up to process item. 
                \$genresMenu,                      # ref to variable to save new menu.
                'genres');                         # category tagType

}

sub makeTopicMenu {

  makeNewListMenu ($localedomain . '/topic',         # Base URL for lists - country, Genres, topics
                \&getTopicStations,              # Function to be called up to process item.
                \$topicsMenu,                    # ref to variable to save new menu.
              'topics');                         # category tagType

}

sub makeCountryMenu {

  makeNewListMenu ($localedomain . '/country' ,      # Base URL for lists - country, Genres, topics
              \&getCountryStations,             # Function to be CALLed up to process item.
              \$countriesMenu,                  # ref to variable to save new menu.
              'countries');                     # category tagType

    return;
}

sub make_rscid () {

    my $rscid = '1'. join '', map { ('a'..'z', 0..9)[rand(36)] } 1 .. 4;
    return $rscid;
}

sub makeNewListMenu {
	
	my $sourceurl    = shift ;
  	my $getFunction  = shift ;
	my $listMenuref  = shift ;
    my $tagType      = shift ;
    
    my $maxentries = 200;
    

	my %headers = (
		'RSC'   => 1,
	);
    my $rscid = make_rscid () ; 
    my $rscsourceurl = "$sourceurl?_rsc=$rscid" ;
#
# Find tags in JSON data
#	
	my $menulanguage = ($prefs->get('use_locale')) ? 'name' : 'systemName'  ;  #   systemName key has English menu, name key has locale veriosn of menu, slug key is to be used in URLs
	my $allmenu      = 'All' ;
    my @menu;

	$log->info(" Fetching List $sourceurl");
	Slim::Networking::SimpleAsyncHTTP->new(
		sub { 						# Success - page fetched.
			my $http = shift;
            my $jsondata = parseListWebPage($http->content);

            foreach my $item (@$jsondata) {
# URl to get entries in a genre      https://prod.radio-api.net/stations/by-tag?tagType=genres&systemName=turkish-pop&count=20&offset=0            
                
                    my $tagurl = "https://prod.radio-api.net/stations/by-tag?tagType=$tagType&systemName=$item->{'slug'}&count=$maxentries&offset=0";
                    push @menu, {
                    'name'	      => $item->{'systemName'} . ' ('.$item->{'count'}.')',
                    'url'         => $getFunction,
                    'type'        => 'link',	
                    'passthrough' => [ {'url' => $tagurl } ],
                    };
            };
			$$listMenuref = \@menu;
		},
		sub { # Page fetch error 
			my $http = shift;
			my $error  = $http->error;			
			$log->error(" Failed to get genres list from Radio.net - fetch error: $error");
			$$listMenuref = undef;
		}
	)->get($rscsourceurl, %headers);	
	
	return ;
}


my @englishmenutext = ('Search','Local Stations','Top Stations', 'Genre', 'Countries', 'Topics', "Editor's tips", 'Podcasts');

my $similarStationMenuText;

sub handleFeed {
	my ($client, $callback, $params, $args) = @_;
	my $icon = Plugins::RadioNet::Plugin->_pluginDataFor('icon');
	
#	my @localemenutext  = (	$localemessages->{'common'}->{'header.search.placeholder'} , 
#							$localemessages->{'common'}->{'navibar.section.local.menu'},
#							$localemessages->{'common'}->{'navibar.section.top.menu'},
#							$localemessages->{'common'}->{'navibar.section.genres.menu'},
#							$localemessages->{'home-page'}->{'module.taglist.country.title'},
#							$localemessages->{'common'}->{'navibar.section.moretopics.alt_menu'},
#							$localemessages->{'home-page'}->{'module.tab_carousel.tab.editors_tips'},
#                           $localemessages->{'common'}->{'navibar.section.podcasts.menu'} , 
#                             );   
							
                            
#	my $menutext = ($prefs->get('use_locale')) ?  \@localemenutext : \@englishmenutext ;							
	my $menutext = \@englishmenutext ;							

	my $menu = [
			{
				name        => $menutext->[0], # name  => 'Search',
				type        => 'search',
				url         => \&getSearch,
				passthrough => [ { 'pageno' => 1} ],
			},	
			{
				name        => $menutext->[1],# name => 'Local stations',
				type        => 'link',
				url         => \&getNearYou,
			},	
			{
				name        => $menutext->[3],# name => 'Genre',
				items		=> $genresMenu
			},	
				
			{
				name        => $menutext->[5],#	name => 'Topic',
				items		=> $topicsMenu
			},	

			{
				name        => $menutext->[4],#	name => 'Countries',
				items		=> $countriesMenu
			},	
		];
	$callback->( { items => $menu } );
};

sub commonFetchParse {

	my ( $client, $callback, $args, $passthrough,$sourceUrl, $parseRoutine ) = @_;
	
	if (  my $cachemenu = getCachedMenu($sourceUrl) )  {
		fixupCodeRefs($cachemenu);
		$callback->( { items => $cachemenu } );
		return;
	}
	my $starttime  = Time::HiRes::time() ;
    $log->debug("Source url $sourceUrl");
    
	Slim::Networking::SimpleAsyncHTTP->new(
		sub {
			my $http = shift;
			
			my $fetchedtime = Time::HiRes::time() - $starttime ;
			my $menu = $parseRoutine->($http->content,$sourceUrl);
			my $parsedtime = Time::HiRes::time() - $starttime ;
			
			$log->info(sprintf("Fetch delay %15.6f  Parse delay %15.6f for url %s ",$fetchedtime,$parsedtime, $sourceUrl)); 

			cacheMenu($sourceUrl, $menu, CACHEONEHOUR);			
			fixupCodeRefs($menu);
			$callback->( { items => $menu } );
		},

		# Called when no response was received or an error occurred.
		sub {
			$log->warn("error: $_[1]");
			$callback->( [ { name => $_[1], type => 'text' } ] );
		}, { 'cache'   => 0 }
	)->get($sourceUrl);

	return;
}

# Search results are not cached - maybe it shoudl be.

sub getSearch {

	my ( $client, $callback, $args, $passthrough ) = @_;

	my $searchstr;
	my $offset =0;
    my $searchcount = 200;
	my $searchUrl;
	
	if (defined($args->{'search'})) {
	    $searchstr = URI::Escape::uri_escape_utf8($args->{'search'});
	    $searchUrl = "$apidomain/stations/search?query=$searchstr&count=$searchcount&offset=$offset"
	} 
	
	if (defined ($passthrough->{'codeRef'})) {
		$searchUrl= $passthrough->{'url'};
	};  

	commonFetchParse($client, $callback, $args, $passthrough,
					$searchUrl,
					\&parseSearchStationsReply);
};

sub getNearYou {
	my ( $client, $callback, $args, $passthrough ) = @_;
	
	commonFetchParse($client, $callback, $args, $passthrough,
					"$apidomain/stations/local?count=100",  # Max count is 100 - any higher only one station returned
					\&parseStreamsReply);
};

sub getPagedLists {
	my ( $client, $callback, $args, $passthrough ) = @_;
	
	commonFetchParse($client, $callback, $args, $passthrough,
					 $passthrough->{'url'},
					\&parseListMenuReply);
};

sub getStationURLs {

	my ( $client, $callback, $args, $passthrough ) = @_;
	my $stationUrl = $passthrough->{'stationurl'};	

	commonFetchParse($client, $callback, $args, $passthrough,
					$stationUrl,
					\&parseStationURLReply);
	return;
};


sub getTopicStations {
	
	my ($client, $callback, $args, $passthrough) = @_;
	
	commonFetchParse($client, $callback, $args, $passthrough,
					 $passthrough->{'url'},
					\&parseListMenuReply);
	return;
}

sub getGenreStations {
	my ($client, $callback, $args, $passthrough) = @_;
	
	commonFetchParse($client, $callback, $args, $passthrough,
					 $passthrough->{'url'},
					\&parseListMenuReply);
	return;
}

sub getCountryStations {
	
	my ($client, $callback, $args, $passthrough) = @_;
	
	commonFetchParse($client, $callback, $args, $passthrough,
					 $passthrough->{'url'},
					\&parseListMenuReply);
	return;
}

#
#  Generic parse a Radio Net web page and find fragment of JSON useful for locale messages, Genres List, by Genre content, Country list and by Country contents , Topics list and by topic contents
#
sub parseListWebPage {
    
    my $htmlpage = shift;
    my $keywords = shift;

    
# The use of RSC means "html" page returns is made up lines of data - 

    my @pagelines = split ('\n',$htmlpage);
#    $log->error(" List http respoinse ". Dumper(@pagelines));    

# each line has a hexnumber then colon and then type - only the  '[["$"' type is of interest 

    foreach my $rscline (@pagelines)  {
        
# Check only the  '1a:[["$"'  type of line  
        if ($rscline =~ m/^[0-9a-z]+:\[\["\$"/ ) {

# The list is JSON data with "tags" as a label.

                my $i = index($rscline, '"tags"');  
                next if ($i < 0);

                my $j = index (substr($rscline,$i),'[');        
                my $t = substr($rscline, ($i+$j) );
                my @results  = MyText::Balanced::extract_bracketed( $t, '[]' );

# Tidy up any single quote such as R'n'B type escaped sequences                
                (my $jsondata  = $results[0] ) =~ s/\'/'/g;
                my $parsedjson = eval { from_json($jsondata) };
                if ( $@  ) {
                    $log->error( "Error parsing tags json data " . $@ );
                };
                $log->info(" List json ". Dumper($parsedjson));
                return $parsedjson;
        }
    }
    return undef;
}

#
#  Generic parse a Radio Net web page and find fragment of JSON useful for locale messages, Genres List, by Genre content, Country list and by Country contents , Topics list and by topic contents
#

sub parseWebPage {
    
    my $htmlpage = shift;
    my $keywords = shift;
    my ($begin, $after, $middle, $tail);
    my $count = 1;
    
    my @fragments;
    
    my @pagelines = split ('\n',$htmlpage);
#    $log->error(" parse web page \n\n". Dumper(@pagelines). "\n\n");    
    $log->error(" parse web page ". $#pagelines);    


# RSC page can be split into lines each with starting hex number followed by a colon - javascrirpt bodies will njto hgave this. 

    foreach my $rscline (@pagelines) {

# the element list JSON data can appear in two ways - clean JSON or escaped JSON - check if present in either form
       next unless ( index($rscline, '"itemListElement":') > 0  || (index($rscline, '\\"itemListElement\\":') > 0));

# If the line has escaped JSON - rmeove the escaped characters       
       if (index($rscline, '\\"itemListElement\\":') > 0) {
            $rscline =~ s/\\( (?:[arnt'"\\]) )/"qq|\\$1|"/geex;   # Replace many escaped chars such as  \t \n \" \'
            $rscline =~ s/\\u0026/&/g;                           # REplace a few more Javascript escape sequences 
            $rscline =~ s/\\u003e/>/g;
            $rscline =~ s/\\u003c/</g;         
        }

# Check there is the key item list JSON tag
       next unless (index($rscline,'"@type":"ItemList","numberOfItems"') > 0);

#  Try split at top of JSON data
       my $i            = index ($rscline, '{"@context":"https://schema.org"');
       return undef if ($i < 0 ) ;

       my @results   = MyText::Balanced::extract_bracketed( substr($rscline, $i), '{}' );
      (my $jsondata  = $results[0] ) =~ s/\'/'/g;
       my $parsedjson = eval { from_json($jsondata) };
       if ( $@  ) {
           $log->error( "Error parsing tags json data " . $@ );
       };
       $log->error(" First JSON ". Dumper($parsedjson));
       return $parsedjson;
    }

# Return undef if no matches found in the page.    
    return undef;
}

sub parseSearchStationsReply {

	my $http = shift;
	my $url  = shift;
	
	my ($baseurl,$opts) = getopts($url);
	
	my $searchurl = $baseurl . '?query=' . $opts->{'query'};
#	$log->error("Dump of opts for $url  $baseurl \n".Dumper(\$opts)); 

	my $offset =0  ;
    my $menu;
    my $stationsmatched;
    my $totalcount;
    my $stationsperpage = 100;

#  Response is a JSON

	my $jsondata = eval { from_json($http) };
    if ( $@  ) {
         $log->error("\n\n----- error parsing ASeach reply json data " . $@ );
         return;
    }

	my $totalcount = $jsondata->{'totalCount'};
	$log->info(" Total count of station found: $totalcount");
    
# check for results
	unless (defined ($jsondata->{'playables'})) {
		$log->error(" No Playables found in search reply - perhaps plugin needs ot be updated.");
		push @$menu , {
			'name'	      => 'No programs found in search reply',
		} ;
		return $menu;
	};

	my $stationscount  = scalar (@{$jsondata->{'playables'}});
	
    my $totalpages = 1;
	if ($totalcount > $stationscount) {
		$totalpages = int(($totalcount + ($stationsperpage - 1))/ $stationsperpage); # Round up to get number of pages available
	};
	
	$menu = makePlayablesMenu($jsondata->{'playables'});

	$log->debug(" Menu ". Dumper(@$menu));

#  Having processed all items - if Page 1 of genre then add menus for other pages in same genre.  
#  First find out how many pages.

	if ($offset == 0) {        # Page 1 has offset 0
        my $offset = $stationsperpage;
		for (my $i = 2; $i <= $totalpages; $i++) { 
			push @$menu, {
				'name'	      => "Page $i of $totalpages",
				'url'         => '',
				'type'        => 'link',	
				'passthrough' => [ { 'url' => $searchurl ."&count=$stationsperpage&offset=$offset", 'pageno' => $i,
									'codeRef'     => 'getSearch'}	],
			};	
            $offset += $stationsperpage;
		}
	}

# All done 
	if (scalar @$menu == 0) {
		push @$menu , {
			'name'	      => 'No programs found',
		} ;
	}

	$log->debug("Dump of menu ". Dumper($menu));

	# return menu
	return $menu ;

}

#  Get playable URLs for a station Id.  Station type can be either a STATION or PODCAST

sub parseStationURLReply {

	my $http = shift;

	my @menu;
	
	my 	$jsondata = eval { from_json($http) };
#    $log->error(" JSON extract ". Dumper(\$jsondata));
	if ($@) {
		$log->error("Error parsing JSON data $@");
		return;
	}    
# Stations URLs are in broadcast-> streams,   (used to be result-> streams)  - this has changed with web site changes.

	unless (defined ($jsondata->[0]->{'streams'})) {
		$log->error(' No Streams found in URL reply found - perhaps plugin needs to be updated.');
		push @menu , {
			'name'	      => 'No programs found',
		} ;
		return \@menu;
	};

	my $icon   = getstationlogo($jsondata->[0]);
	my $title  = $jsondata->[0]->{'name'};
	my $desc   = $jsondata->[0]->{'description'};
	my $artist = $jsondata->[0]->{'country'};
	my $id     = $jsondata->[0]->{'id'};

# Two types ofprocessing STATION and PODCAST  - podcast have optional many episodes
	if ($jsondata->[0]->{'type'} eq 'STATION') {
		my $sourceurls = $jsondata->[0]->{'streams'};
		$log->info("STATION sourceurls $title ". Dumper(\$sourceurls));

# Note each URL seen to make list of unique URLs as there may be repeats in streamUrls
		my %seen;
		
		foreach my $stream (@{$sourceurls}) {
			if (!exists($seen{$stream->{'url'}})) {
				
				my $format = ($stream->{'url'} =~m/^https:\/\//) ? 'secure ' : undef;
				$format =  ($format . $stream->{'contentFormat'}) if (defined ($stream->{'contentFormat'}) ); 
				$format = " ($format)" if (defined($format));
				
				$seen{$stream->{'url'}} = 1;
						
				push @menu, { 
					'name'        => $title . $format,
					'image'		  => $icon,
					'type'        => 'audio',
					'url'         => $stream->{'url'},
					'on_select'   => 'play',
					'description' => $desc,
				};
			}
		}

        $log->info(" Dump menu ".Dumper(\@menu));
		return \@menu;
		
	}

#  For podcast the streamUrls has the podcast feed.  Most time works wioth LMS Podcast player.
	if ($jsondata->[0]->{'type'} eq 'PODCAST') {
		$log->error(" Podcast player ". Dumper($jsondata));			
	}

#  Not STATION or PODCAST playable type - so return undef.
	return undef;
}


sub parseListMenuReply {
	my $http = shift;
	my $url  = shift;
	
	my ($baseurl,$opts) = getopts($url);
    my $menu;

    my $parsedjson = eval { from_json($http) };
    if ( $@  ) {
        $log->error( "Error parsing tags json data " . $@ );
    };
    $log->info(" List menu JSON ". Dumper($parsedjson));
    
   	my $totalCount     = int ($parsedjson->{'totalCount'});
    
	unless (defined ($parsedjson->{'playables'})) {
		$log->error(" Playables is not defined ");
		push @$menu , {
			'name'	      => 'No programs found',
		} ;
		return $menu;
	};    

    $menu = makePlayablesMenu($parsedjson->{'playables'});
#	$log->debug(" Menu ". Dumper(@$menu));

# All done 
	if (scalar @$menu == 0) {
		push @$menu , {
			'name'	      => 'No Genres programs found',
		} ;
	}

   return $menu;
}

sub makePlayablesMenu {

	my $stations   = shift;
	my @menu;

	foreach my $station (@{$stations}) {
		
		my $stationname = $station->{'name'};
		next unless defined ($stationname);

		my $stationtype = $station->{'type'};
		my $stationdesc = makestationdesc($station);
		my $stationlogo = getstationlogo($station);		

#  If stations 'playable' is TRUE then it has streams of valid URLs
#  otherwise just a stationID which will be used later to get playable URL

#      $log->error(" Name=$stationname TYpe=$stationtype Desc=$stationdesc  ValidStreams=>>".$station->{'hasValidStreams'}."<<");
       if ( $station->{'hasValidStreams'}) { 
            my $stationurl = $station->{'streams'}[0]->{'url'};
            push @menu, {
				'name'	      => $stationname . $stationdesc,
				'image'       => $stationlogo,
				'icon'        => $stationlogo,
				'url'         => $stationurl ,
				'description' => $stationdesc,
				'on_select'   => 'play',
				'type'        => 'audio',	
            };
        }
    }

# All done 
	if (scalar @menu == 0) {
		push @menu , {
			'image'		  => undef ,
			'name'	      => 'No programs found',
			'type'        => 'text',	
		} ;
	}

	$log->info("Dump of menu ". Dumper(\@menu));
	return \@menu;
}

sub makeStationsMenu {
	my $stations = shift;

	my @menu;
	
	foreach my $station (@{$stations}) {
		
		my $stationname = $station->{'name'};
		next unless defined ($stationname);

		my $stationtype = $station->{'type'};
		my $stationdesc = makestationdesc($station);
		my $stationlogo = getstationlogo($station);		
		

#  If stations 'playable' is TRUE then it has streams of valid URLs
#  otherwise just a stationID which will be used later to get playable URL
		
		if ($stationtype eq 'STATION' ) {
			push @menu, {
				'name'	      => $stationname . $stationdesc,
				'image'       => $stationlogo,
				'icon'        => $stationlogo,
				'url'         => '' ,
				'type'        => 'link',	
				'passthrough' => [
								{	'stationurl'  => 'https://prod.radio-api.net/stations/details?stationIds='. $station->{'id'} ,                
									'stationlogo' => $stationlogo,
									'codeRef' 	  => 'getStationURLs'}
								],
			};
		} else { 		# otherwise assume it is PODCAST
				push @menu, {
					'name'	      => "$stationname (podcast) $stationdesc",
					'image'       => $stationlogo,
					'icon'        => $stationlogo,
					'url'         => '' ,
					'type'        => 'link',	
					'passthrough' => [
									{	'podcastid' 	=> $station->{'id'},
										'stationlogo'	=> $stationlogo,
										'codeRef' 		=> 'getPodcastURLs'}
									],
					};
		};
	}

# All done 
	if (scalar @menu == 0) {
		push @menu , {
			'image'		  => undef ,
			'name'	      => 'No programs found',
			'type'        => 'text',	
		} ;
	}

	$log->debug("Dump of menu ". Dumper(\@menu));
	return \@menu;    
    
}


# This reply has multiple stations - there could be multiple URLS but only first used - FIXUP
# Unusual this reply is in JSOn so have to add source type to help parsing routines
sub parseStreamsReply {
	
	my $jsoncontent = shift;
	my $jsondata = eval { from_json($jsoncontent) };
	
	if ($@) {
		$log->error("Error parsing JSON data $@");
		return;
	}

	my $menu     = makePlayablesMenu($jsondata->{'playables'},'localstations');
	
	return $menu;
}


sub makestationdesc {
	my $station     = shift;
	my $stationdesc = ' (';
	
# Check which form of station record - matched ones have a HASH with 'value' whereas others have just a string. 	
	
	if (ref($station->{'name'}) eq 'HASH' ) {
		$stationdesc .=  $station->{'city'}->{'value'} . ', ' if defined($station->{'city'}->{'value'}); 
		$stationdesc .=  $station->{'country'}->{'value'} ;
		
		if (defined ($station->{'genres'}[0]->{'value'})) {
			my $genrelist;
			foreach my $entry (@{$station->{'genres'}}) {
				$genrelist .= $entry->{'value'} .',';
			}
			chop $genrelist ; # remove last comma;
			$stationdesc .= '/'.$genrelist;
		};
		
	} else {
		$stationdesc .=  $station->{'city'} ;
        $stationdesc .=  ', ' if (($stationdesc ne '') && defined ($station->{'country'}));
		$stationdesc .=  $station->{'country'} ;
		$stationdesc .= ' / '. join(', ',@{$station->{'genres'}}) if (defined ($station->{'genres'}));
	}
	
	$stationdesc .= ')' ;

	return $stationdesc;
}


sub getstationlogo {
	my $station = shift;
	my $stationlogo =  $station->{'logo300x300'} ?  $station->{'logo300x300'} 
					 : $station->{'logo100x100'} ?  $station->{'logo100x100'} 
					 : $station->{'logo630x630'} ?  $station->{'logo630x630'} 
					 : $station->{'logo175x175'} ?  $station->{'logo175x175'} 
					 : Plugins::RadioNet::Plugin->_pluginDataFor('icon') ;

	return $stationlogo;
}
    

sub getDisplayName { 'PLUGIN_RADIONET' }

sub playerMenu { shift->can('nonSNApps') && $prefs->get('is_app') ? undef : 'RADIO' }

1;
