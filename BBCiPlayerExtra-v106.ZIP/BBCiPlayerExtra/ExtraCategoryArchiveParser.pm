package Plugins::BBCiPlayerExtra::ExtraCategoryArchiveParser;
use strict;

use Slim::Utils::Log;

use XML::Simple;
use Date::Parse;

use Data::Dumper;

my $log = logger('plugin.bbciplayer.extra');

sub _getopts {
	my $class  = shift;
	my $optstr = shift;
	my $opts   = shift;
	my $filters= shift;

	for my $opt (split /\&/, $optstr) {
		if    ($opt =~ /filter:(.*)=(.*)/) { $filters->{lc($1)} = $2 }
		elsif ($opt =~ /(.*)=(.*)/       ) { $opts->{lc($1)}    = $2 } 
		else                               { $opts->{lc($opt)}  =  1 }
	}
}

sub parse {
	my $class  = shift;
	my $http   = shift;
	my $optstr = shift;

	my $params = $http->params('params');
	my $url    = $params->{'url'};
	my $opts   = {};
	my $filters= {};

	my @menu;
	$class->_getopts($optstr, $opts, $filters);

	my $xml = eval {
		XMLin( 
			$http->contentRef,
			ForceArray =>['programme'], 
			KeyAttr => []
		)
	};

	if ($@) {
		$log->error("$@");
		return;
	}
	
	my $programmes = $xml ->{'programmes'}->{'programme'};
	if (!defined(@{$programmes})) {
		push @menu, {
			'name'	      => 'No programs in this category',
		};

        	return {	
			'name'    => $params->{'feedTitle'},
			'items'   => \@menu,
			'type'    => 'opml',
			'nocache' => $opts->{'nocache'},
		};
	};

	foreach my $entry (@{$programmes}) {
	    my $program      = $entry;
	    my $progtype     = $program->{'type'};
	    my $firstletter  = uc($entry->{'letter'} );
	    $log->debug("Start Time=" . $program->{'first_broadcast_date'} . "Pid ". $entry->{'programme'}->{'pid'} .
                                                          "  Title ". $entry->{'programme'}->{'display_titles'}->{'title'} . 
                                                       " Synopsis: ". $entry->{'programme'}->{'short_synopsis'} .
							" Audio format: " . ((defined($entry->{'programme'}->{'media'})) ? $entry->{'programme'}->{'media'}->{'format'}   : "*********No Format ******" ) );

	    if ( ($program->{'type'} eq 'brand') || ($program->{'type'} eq 'series')) {
		push @menu, {
				'name'	      => $program->{'title'},
				'url'         => 'http://www.bbc.co.uk/programmes/'. $program->{'pid'} . '/episodes/player.xml' ,
				'parser'      => 'Plugins::BBCiPlayerExtra::ExtraArchiveParser',
		};
	    }
	    if ( $program->{'type'} eq 'episode') {
		push @menu, {
				'name'	      => $program->{'title'},
				'url'         => 'http://www.bbc.co.uk/iplayer/playlist/' . $program->{'pid'} ,
				'type'        => 'playlist',
				'on_select'   => 'play',
				'parser'      => 'Plugins::BBCiPlayerExtra::ExtraPlayableParser',
		};
	    }
	 }

	# return xmlbrowser hash
	return {
		'name'    => $params->{'feedTitle'},
		'items'   => \@menu,
		'type'    => 'opml',
		'nocache' => $opts->{'nocache'},
	};
}

1;
