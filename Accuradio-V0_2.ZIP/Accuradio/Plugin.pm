package Plugins::Accuradio::Plugin;


# Copyright (C) 2021 baltontwo@eircom.net
#
# This file is part of LMS_Accuradio_Plugin.
#
# LMS_Accuradio_Plugin is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# LMS_Accuradio_Plugin is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with LMS_Accuradio_Plugin.  If not, see <http://www.gnu.org/licenses/>.

use strict;

use base qw(Slim::Plugin::OPMLBased);

use JSON::XS::VersionOneAndTwo;
use Digest::MD5 qw(md5_hex);
use URI::Escape;

use Slim::Utils::Log;
use Slim::Utils::Cache;
use Slim::Utils::Prefs;

use Plugins::Accuradio::Settings;
use Plugins::Accuradio::ProtocolHandler;

use Data::Dumper;

my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.accuradio',
	'defaultLevel' => 'ERROR',
	'description'  => getDisplayName(),
});

my $prefs      = preferences('plugin.accuradio');
my $pluginName = 'Accuradio';

use constant CACHEONEHOUR    =>  3600; 

my $cache = Slim::Utils::Cache->new();
$cache->clear();

sub _pluginDataFor {
	my $class = shift;
	my $key   = shift;

	my $pluginData = Slim::Utils::PluginManager->dataForPlugin($class);

	if ($pluginData && ref($pluginData) && $pluginData->{$key}) {
		return $pluginData->{$key};
	}

	return undef;
}

sub getCachedMenu {
	my $url = shift;

	my $cacheKey = $pluginName . ':' . md5_hex($url);

	if ( my $cachedMenu = $cache->get($cacheKey) ) {
		my $menu = ${$cachedMenu};
		return $menu;
	};
	return;
}

sub cacheMenu {
	my ( $url, $menu, $seconds ) = @_;	

	my $cacheKey = $pluginName . ':' . md5_hex($url);
	$cache->set( $cacheKey, \$menu, $seconds );

	return;
}

# Fixup callable routine table - fixup need because CODE cannot be saved when menu is cached.

my %subItems = (
	'getCollections' 	=> \&getCollections,
	);

sub fixupCodeRefs {
	my $menu = shift;

	for my $menuItem (@$menu) {
		my $codeRef = $menuItem->{passthrough}[0]->{'codeRef'};
#		$log->error(" Fixup menu $codeRef for ".$menuItem->{'name'} );

		if ( defined $codeRef ) {
			$log->error("Fixup failed for undefined routine: $codeRef ") unless (exists($subItems{$codeRef}));
			$menuItem->{'url'} = $subItems{$codeRef};
		}
# Fixup submenu if one is present
		fixupCodeRefs($menuItem->{'items'}) if (defined $menuItem->{'items'}) ;
	}
	return;
}
				 
sub initPlugin {
	my $class = shift;

	Plugins::Accuradio::Settings->new($class);
	Plugins::Accuradio::Settings->init($class);

	$class->SUPER::initPlugin(
		feed   => \&handleFeed,
		tag    => 'accuradio',
		is_app => $class->can('nonSNApps') && $prefs->get('is_app') ? 1 : undef,
		menu   => 'radios',
		weight => 1,
	);

	Plugins::Accuradio::Settings->new;
}


sub handleFeed {
	my ($client, $callback, $params, $args) = @_;

	my $menu = [
			{
				name        => 'Search',
				type        => 'search',
				url         => \&getSearch,
				passthrough => [ { 'pageno' => 1, 'searchtype' => 'general'} ],
			},	
			{
				name        => 'Search Artist',
				type        => 'search',
				url         => \&getSearch,
				passthrough => [ { 'pageno' => 1, 'searchtype' => 'artist'} ],
			},	
			{
				name        => 'Search Keyword',
				type        => 'search',
				url         => \&getSearch,
				passthrough => [ { 'pageno' => 1, 'searchtype' => 'keyword'} ],
			},	
			{
				name        => 'Featured',
				type        => 'link',
				url         => \&getFeatured,
			},	
			{
				name        => 'Genres',
				type        => 'link',
				url         => \&getBrands,
			},	
				
		];
	$callback->( { items => $menu } );
}

sub commonFetchParse {
	my ( $client, $callback, $args, $passthrough,$sourceUrl, $parseRoutine ) = @_;
	
	if (  my $cachemenu = getCachedMenu($sourceUrl) )  {
		fixupCodeRefs($cachemenu);
		$callback->( { items => $cachemenu } );
		return;
	}
	my $starttime  = Time::HiRes::time() ;
	Slim::Networking::SimpleAsyncHTTP->new(
		sub {
			my $http = shift;
			
			my $fetchedtime = Time::HiRes::time() - $starttime ;
			my $menu = $parseRoutine->($http->content,$sourceUrl);
			my $parsedtime = Time::HiRes::time() - $starttime ;
			
			$log->info(sprintf("Fetch delay %15.6f  Parse delay %15.6f for url %s ",$fetchedtime,$parsedtime, $sourceUrl)); 

			cacheMenu($sourceUrl, $menu, CACHEONEHOUR);			
			fixupCodeRefs($menu);
			$callback->( { items => $menu } );
		},

		# Called when no response was received or an error occurred.
		sub {
			$log->warn("Error on url \"$sourceUrl\" : $_[1] ");
			$callback->( [ { name => $_[1], type => 'text' } ] );
		}
	)->get($sourceUrl);

	return;
}

sub getBrands {
	my ( $client, $callback, $args, $passthrough ) = @_;
	
	my $brandsUrl = "https://www.accuradio.com/c/m/json/brands/";

	commonFetchParse($client, $callback, $args, $passthrough,
					$brandsUrl,
					\&parseBrandsReply);
};

sub getFeatured {
	my ( $client, $callback, $args, $passthrough ) = @_;
	
	my $featuredUrl = "https://www.accuradio.com/c/m/json/featured/";

	commonFetchParse($client, $callback, $args, $passthrough,
					$featuredUrl,
					\&parseFeaturedReply);
}

sub getCollections {
	my ( $client, $callback, $args, $passthrough ) = @_;
	
	my $collectionUrl = 'https://www.accuradio.com/c/m/json/genre/?param='.$passthrough->{'param'};
	$log->debug(" URL $collectionUrl");
	
	commonFetchParse($client, $callback, $args, $passthrough,
					$collectionUrl,
					\&parseCollectionReply);
}

# Search results are not cached - maybe it shoudl be.

sub getSearch {
	my ( $client, $callback, $args, $passthrough ) = @_;

	my $searchUrl;
	my $searchtype = $passthrough->{'searchtype'} ;

# general https://www.accuradio.com/c/m/json/channel_search/?k={QUERY}&w=true
# artist "https://www.accuradio.com/c/m/json/channel_search/?k={QUERY}&t=at&specific=artist&w=true
# keyword https://www.accuradio.com/c/m/json/channel_search/?k={QUERY}&specific=keyword&w=true

#  Search key is defined on first search - subsequent pages of search results may be different

	if (defined($args->{'search'})) {
	    my $searchstr = URI::Escape::uri_escape_utf8($args->{'search'});

		$searchUrl = "https://www.accuradio.com/c/m/json/channel_search/?k=$searchstr";

		if    ($searchtype eq 'general')  {
			$searchUrl .= '&w=true' ; # &q=true make response shorter not sure of its exact purpose
		}
		elsif ($searchtype eq 'artist') {
			$searchUrl .= '&t=at&specific=artist&w=true' ;
		}
		elsif ($searchtype eq 'keyword') {
			$searchUrl .= '&specific=keyword&w=true';
		} else {
			$log->error(" Unknown search type: \"$searchtype \"  assume general search"); 
			$searchUrl .= '&q=true&w=true' ;
		}
	} 
	commonFetchParse($client, $callback, $args, $passthrough,
					$searchUrl,
					\&parseSearchReply);
};

sub parseBrandsReply {
	my $http = shift;
	my $url  = shift;
	
	my 	$jsondata = eval { from_json($http) };
	if ($@) {
		$log->error("Error parsing JSON data $@");
		return;
	}

	$log->debug("Brands JSON \n".Dumper(\$jsondata));
	
	my $brands = $jsondata->{'brands'};
	my @menu;
	foreach my $brand (@$brands) {
		push @menu, {
			'name'	      => $brand->{'name'},
			'url'         => '', 
			'type'        => 'link',	
			'passthrough' => [ {'param' => $brand->{'param'}, 
								'codeRef'     => 'getCollections'} ],
		};
	};
	my @sortedMenu = sort { $a->{'name'} cmp $b->{'name'} } @menu;
	return \@sortedMenu;	
}

sub parseFeaturedReply {
	my $http = shift;
	my $url  = shift;
	
	my 	$jsondata = eval { from_json($http) };
	if ($@) {
		$log->error("Error parsing JSON data $@");
		return;
	}

	$log->debug("Featured JSON \n".Dumper(\$jsondata));
	
	my $features = $jsondata->{'collections'};
	my @menu;
	foreach my $feature (@$features) {
		my $channels = $feature->{'channels'};
		
		my @submenu;
		
		foreach my $channel (@$channels) {
			my $oldid  = $channel->{'oldid'};
			my $oid    = $channel->{'_id'}->{'$oid'};
			my $icon   = "https://images.accuradio.com/tiles/default/$oldid.jpg?cb=44";
			my $desc   = $channel->{'description'};

			my $subname = $channel->{'name'};	
			$subname =~s/ /+/g;
		
			push @submenu, { 
				'name'        => $channel->{'name'},
				'image'		  => $icon,
				'icon'		  => $icon,
				'type'        => 'audio',
				'url'		  => "accur://www.accuradio.com/c/m/json/channel/?name=$subname&o=$oid&getando=1&getts=1",
				'on_select'   => 'play',
				'description' => $desc,
			};			
		}

		push @menu, {
			'name'	      => $feature->{'name'},
			'items'	      => \@submenu, 
			'type'        => 'link',	
		};
	};
	
	my @sortedMenu = sort { $a->{'order'} cmp $b->{'order'} } @menu;
	return \@sortedMenu;	
}


sub parseCollectionReply {
	my $http = shift;
	my $url  = shift;
	
	my 	$jsondata = eval { from_json($http) };
	if ($@) {
		$log->error("Error parsing JSON data $@");
		return;
	}

	$log->debug("JSON \n".Dumper(\$jsondata));
	
	my @menu; 
	my $channels = $jsondata->{'channels'};
	foreach my $channel (@$channels) {

		my $name   = $channel->{'name'};	
		my $displayname   = sprintf("%s (%d)", $name,$channel->{'track_count'});
# Change blanks to plus as that is what Accuradio requires in the name field. It may be parrt of creating Blends.
		$name =~s/ /+/g;

		my $oldid  = $channel->{'oldid'};
		my $icon   = "https://images.accuradio.com/tiles/default/$oldid.jpg?cb=44";

		my $oid    = $channel->{'_id'}->{'$oid'};

		my $genres = $channel->{'genres'};	
		my $desc   = $channel->{'description'};
		$desc .= " ($genres)" if defined($genres);

		$log->error("Inactive flag is True for $name ") if ($channel->{'inactive'} );

# The channel return data which is meta - a POST is needed to be able to fetch real $oid 
# The  POST is to https://www.accuradio.com/c/m/json/channel/
# Body has name of channel with bankls replaced by plus-sign and o and rand parameters from channel JSON data.
# example of CURL which fetches the data 
# curl -d "name=Classical+101&o=4e38562d77d9e74636000248&getando=1&getts=1&rand=0.632459941423622" -H "Content-Type: application/x-www-form-urlencoded" -X POST https://www.accuradio.com/c/m/json/channel/
# To pass paramters to accur protocolhandler - the accur:// URL has parmeterd which will be put into BODY of POST
# name=Classical+101&o=4e38562d77d9e74636000248&getando=1&getts=1&rand=0.632459941423622		

		
		push @menu, { 
				'name'        => $displayname,
				'image'		  => $icon,
				'icon'		  => $icon,
				'type'        => 'audio',
				'url'		  => "accur://www.accuradio.com/c/m/json/channel/?name=$name&o=$oid&getando=1&getts=1",
				'on_select'   => 'play',
				'description' => $desc,
		};
	}
	
	my @sortedMenu = sort { $a->{'name'} cmp $b->{'name'} } @menu;
	return \@sortedMenu;	
}

sub parseSearchReply {
	my $http = shift;
	my $url  = shift;
	
	my 	$jsondata = eval { from_json($http) };
	if ($@) {
		$log->error("Error parsing JSON data $@");
		return;
	}

	$log->debug("JSON \n".Dumper(\$jsondata));
	
	my @menu; 
	foreach my $result (@$jsondata) {

		my $name          = $result->{'name'};
		my $displayname   = sprintf("%s (%d)", $name,$result->{'track_count'});
# Change blanks to plus as that is what Accuradio requires in the name field. It may be parrt of creating Blends.
		$name =~s/ /+/g;

		my $oldid     = $result->{'oldid'};
		my $icon   = "https://images.accuradio.com/tiles/default/$oldid.jpg?cb=44";

		my $oid       = $result->{'_id'}->{'$oid'};

		my $genres    = $result->{'genres'};	
		my $desc   = $result->{'description'};
		$desc .= " ($genres)" if defined($genres);
	
		push @menu, { 
				'name'        => $displayname,
				'image'		  => $icon,
				'icon'		  => $icon,
				'type'        => 'audio',
				'url'		  => "accur://www.accuradio.com/c/m/json/channel/?name=$name&o=$oid&getando=1&getts=1",
				'on_select'   => 'play',
				'description' => $desc,
		};
	}
	if (scalar @menu == 0) {
		push @menu , {
			'image'		  => undef ,
			'name'	      => 'No matches found',
			'type'        => 'text',	
		} ;
	}	
	return \@menu;
}

sub getDisplayName { 'PLUGIN_ACCURADIO' }

sub playerMenu { shift->can('nonSNApps') && $prefs->get('is_app') ? undef : 'RADIO' }

1;
