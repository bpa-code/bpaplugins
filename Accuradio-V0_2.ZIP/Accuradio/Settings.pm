package Plugins::Accuradio::Settings;

use strict;
use base qw(Slim::Web::Settings);

use Slim::Utils::Prefs;

my $prefs = preferences('plugin.accuradio');

sub init {
}

sub name { return 'PLUGIN_ACCURADIO'; }

sub page { return 'plugins/Accuradio/settings/basic.html'; }

sub prefs {
	return (preferences('plugin.accuradio'), qw( is_app ));
}

sub beforeRender {
	my $class = shift;
	my $params= shift;

#   Fix - show_app had output from "can" function which was a code reference 
#   which it seems was executed in Template and not just treated as a value.

	$params->{'show_app'} = Slim::Plugin::Base->can('nonSNApps') ? 1 : 0 ;

}


1;
