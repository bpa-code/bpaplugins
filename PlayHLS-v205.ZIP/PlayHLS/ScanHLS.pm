package Plugins::PlayHLS::ScanHLS;

# HLS protocol handler
#
# (c) Triode, 2015, triode1@btinternet.com
#
# Released under GPLv2
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

use strict;

use Slim::Utils::Errno;
use Slim::Utils::Log;
use MyAnyEvent::HTTPhls;
use Plugins::PlayHLS::SegmentUtils;

use URI;
use URI::Split;
use URI::Escape;

use Data::Dumper;

use bytes;

use constant SCAN_HTTP_GET_TIMEOUT        => 30;
use constant PRE_FETCH => 1; # number of chunks to prefetch

my $log = logger('plugin.playhls');
my $useragentstring = Slim::Utils::Misc::userAgentString() ;

my $codecIds = {
	"mp4a.40.1" => "AAC",
	"mp4a.40.2" => "AAC LC",
	"mp4a.40.5" => "AAC SBR",
};

# Rough setting for buffer threshold as otherwise video stream bit rate make start up deklay too long
# Assume a 44.1Khz 2 channel stream is about 128kbps.  It is guesswork.

my %adtsrates = (
		0  =>  256000, # 96000,
		1  =>  256000, # 88200,
		2  =>  186000, # 64000,
		3  =>  128000, # 48000,
		4  =>  128000, # 44100,
		5  =>   93000, # 32000,
 		6  =>   64000, # 24000,
		7  =>   64000, # 22050,
		8  =>   46000, # 16000,
		9  =>   32000, # 12000,
		10  =>  32000, # 11025,
		11  =>  23000, #  8000,
		12  =>  23000, #  7350,
	);

sub FindFormat {
#   The parameters that are passed to FindFormat object.
	
	my ( $url, $track, $args ) = @_;
	
	my $cb     = $args->{'cb'};
	my $pt     = $args->{'pt'};
	my $client = $args->{'client'};

	my $url = shift;
	
	my $songhandler = Slim::Player::ProtocolHandlers->handlerForURL( $url );
	
	$url =~ s/^hlsplays/https/;
	$url =~ s/^hlsplay/http/;
	$url =~ s/\|$//;

	my $song = $args->{song};

# Fix up the protocol handler for "song" to be HLSPLAY as initially HLS playlist is handled by LMS HTTP  
#	$song->handler($songhandler);

	$log->debug("Findformat passed $url handler ".$song->handler());
	$log->info("Findformat passed $url ");
	$log->info("Findformat track url ". $track->url);
	$log->info("Findformat song streamurl ". $song->streamUrl);
	

#
#  Horrible hack to get image (e.g. Station Logo) used in Favorite or IHeart to play the stream.  Save it for metadata.
#	
	my $cache = Slim::Utils::Cache->new();
	my $cover = $cache->get( "remote_image_".$song->streamUrl );
#	$log->info("cover ". Dumper(\$cover));

	$cover =~ s/^\/imageproxy\///;
	$cover =~ s/\/image.png$//;
	my $decoded_cover = uri_unescape($cover);
	
	if ($decoded_cover =~ m/^(http|https):\/\//i ) {
	  $song->pluginData('hls_coverurl',$decoded_cover) 	
	};

	$log->info(" Decoded cover ". Dumper(\$decoded_cover));
	
	
	http_request (	GET => $url,
				headers => { 'User-Agent' => $useragentstring },
				timeout => SCAN_HTTP_GET_TIMEOUT,
				sub {
						my ($body, $hdr) = @_;
							my ($body, $hdr) = @_;
#							Status of 20x means HTTP request completed OK
							if ($hdr->{'Status'} =~ /20[01234]/ ) { 
									gotMediaM3U8HTTP($body, $client, $url, $cb, $track, $pt);
							} elsif ( ($hdr->{'Status'} >= 400) && ($hdr->{'Status'} <= 511)) {
									$log->error("Error getting media playlist: Status=" . $hdr->{'Status'} . " Reason: ". $hdr->{'Reason'}. " URL ".$hdr->{'URL'} );
									return $cb->( undef,'PLUGIN_PLAYHLS_ERROR_SCAN_MEDIA_PLAYLIST' , @{$pt}); 									
							} else {  # Unusual HTTP status - some by AnyEvent::HTTP
									$log->error("Error getting media playlist: Status=" . $hdr->{'Status'} . " Reason: ". $hdr->{'Reason'}. " URL ".$hdr->{'URL'} );
									return $cb->( undef,'PLUGIN_PLAYHLS_ERROR_SCAN_MEDIA_PLAYLIST' , @{$pt}); 									
							}; 	
				});
}

sub  gotMediaM3U8HTTP {
	
	my ($body, $client, $url, $cb, $track, $pt) = @_;
	
	my $is_debug = $log->is_debug;    
	my @lines;
#
#  Clean up the media playlist - various sources have "oddities"
#	
	foreach my $rawline (split /\n/ ,$body) {
        $rawline =~ s/\cM//g;  
        # strip whitespace from beginning and end
        $rawline =~ s/^\s*//; 
        $rawline =~ s/\s*$//; 
		push @lines, $rawline;
	}
	
	$log->info("Dump of HLS media ". Dumper(\@lines));
	my $line1 = shift @lines;
	if ($line1 !~ /^#EXTM3U/) {
		$log->warn("bad m3u file: $url");
		return;
	};

	my $chunknum;
	my %hlsdetails = (	'duration'      		=> 0, 
						'endlist'				=> 0,
						'segmentlength'			=> 0,
						'independent_segments'	=> 0,
						'targetduration'		=> -1,
						'chunks'				=> []
					   );
	
	while ($#lines >= 0) {
		my $line = shift @lines;
		if ($line =~ /^#EXT-X-MEDIA-SEQUENCE:(\d+)/) {
			$is_debug && $log->debug("#EXT-X-MEDIA-SEQUENCE: $1");
			$chunknum = $1;
			next;
		}

		if ($line =~ /^#EXT-X-INDEPENDENT-SEGMENTS/) {
			$is_debug && $log->debug("#EXT-X-INDEPENDENT-SEGMENTS");
			$hlsdetails{'independent_segments'} = 1;
		}
		if ($line =~ /^#EXT-X-ENDLIST/) {
			$is_debug && $log->debug("#EXT-X-ENDLIST");
			$hlsdetails{'endlist'} = 1;
		}
		if ($line =~ /^#EXT-X-TARGETDURATION:(.*?)/) {
			$hlsdetails{'targetduration'} = $1;
		}

		if ($line =~ /^#EXTINF:(.*?),/) {
			$hlsdetails{'duration'}       += $1;
			$hlsdetails{'segmentlength'}  =  $1;

			my $chunkurl = shift @lines;

			if ($chunkurl !~ /^(http:|https:)/) {
				# relative url
				$is_debug && $log->debug("relative url: $chunkurl");
				$chunkurl = URI->new_abs($chunkurl,$url)->canonical->as_string;
				$is_debug && $log->debug("converted to: $chunkurl");
			}
			push @{$hlsdetails{'chunks'}}, { url => $chunkurl, chunknum => $chunknum, len => $hlsdetails{'segmentlength'} };
			$chunknum++;
		}
	}
	
	$log->info("HLS details ". Dumper(\%hlsdetails));

#
#  Get First segment to determine - transport, audio format and streamtype details.
#
	if ( scalar( @{$hlsdetails{'chunks'}}) == 0 ) {
		$log->error("Error return");
# Error - no chunks in list - need for proper error 
		return $cb->( undef, undef, @{ $pt}); 	
	};
	
	$client->pluginData('hls_scandata',  \%hlsdetails);
	my $segmenturl  = $hlsdetails{'chunks'}[0]{'url'};
	
	
	http_request (	GET => $segmenturl,
			headers => { 'User-Agent' => $useragentstring },
			timeout => SCAN_HTTP_GET_TIMEOUT,
			sub {
					my ($body, $hdr) = @_;
						my ($body, $hdr) = @_;
#						Status of 20x means HTTP request completed OK
						if ($hdr->{'Status'} =~ /20[01234]/ ) { 
#							$log->error("Status " . $hdr->{'Status'} . " Segment length ".length($body));
							gotSegmentHTTP($body, $client, $segmenturl, $cb, $track, $pt);
						} elsif ( ($hdr->{'Status'} >= 400) && ($hdr->{'Status'} <= 511)) {
								$log->error("Error getting media playlist: Status=" . $hdr->{'Status'} . " Reason: ". $hdr->{'Reason'}. " URL ".$hdr->{'URL'} );
								return $cb->( undef,'PLUGIN_PLAYHLS_ERROR_SCAN_SEGMENT' , @{$pt}); 									
						} else {  # Unusual HTTP status - some by AnyEvent::HTTP
									$log->error("Error getting media playlist: Status=" . $hdr->{'Status'} . " Reason: ". $hdr->{'Reason'}. " URL ".$hdr->{'URL'} );
									return $cb->( undef,'PLUGIN_PLAYHLS_ERROR_SCAN_SEGMENT' , @{$pt}); 									
						}; 	
				});
	
}

sub  gotSegmentHTTP {
	
	my ($segment, $client, $url, $cb, $track, $pt) = @_;

	my $is_debug = $log->is_debug;    
	my $hls_scandata = $client->pluginData('hls_scandata');
#
# Analyse the segment to determine the transport and format.
#

	my $suffix = Plugins::PlayHLS::SegmentUtils::getSegmentsuffix($url) ;
	$log->info(" Suffix found \"$suffix\" of url $url");
	
	my $hls_transport;
	my $streamtype;
	$log->info(" Track bitrate is undefined" ) if ( !defined($track->bitrate)) ;
	
	if (Plugins::PlayHLS::SegmentUtils::checkMPEG2Segment($segment))      {
		
#
#  MPEG2 segment - assuem AAC anmd ADTS but check MPEG segment for PIDs and stream types
#  HLS supports only 4 audio types AAC in ADTS, MP3, AC-3 and Enhanced AC-3
#  Note sure what are the valid streamtypes yet except AAC/ADTS is 0x0f.
#  MP3 may appear as stream type 4 - haven't found any stream yet with this.
#  Ignore AC-3 & Enahanced AC-3 as not supported by SB players.
#
#  Not sure what to do about metadata in streams - 0x15 looks like some could be ID3 .
#
#	Selected Stream types, nos and descriptions
#
#    4 0x04 ISO/IEC 13818-3 (MPEG-2 halved sample rate audio) in a packetized stream 
#   15 0x0F ISO/IEC 13818-7 ADTS AAC (MPEG-2 lower bit-rate audio) in a packetized stream 
#   21 0x15 Packetized metadata 
#   22 0x16 Sectioned metadata 
#  129 0x81 Dolby Digital (AC-3) up to six channel audio for ATSC and Blu-ray in a packetized stream 
#  132 0x84 Dolby Digital Plus (enhanced AC-3) up to 16 channel audio for Blu-ray in a packetized stream 
#  135 0x87 Dolby Digital Plus (enhanced AC-3) up to 16 channel audio for ATSC in a packetized stream 
#  193 0xC1 Dolby Digital (AC-3) up to six channel audio with AES-128-CBC data encryption in a packetized stream 

		$streamtype   = 'aac' ;
		$hls_transport= 'MPEG2TS-ADTS' ;
		
		my $pespids = Plugins::PlayHLS::HLSmpeg2::ScanMPEG2chunk($segment);

# Create invalid entries to avoid autovivify undef entries
		$hls_scandata->{'mpeg2_audio_pid'}     = -1;
		$hls_scandata->{'mpeg2_metadata_pid'}  = -1;
		$hls_scandata->{'mpeg2_audio_type'}    = -1;
		$hls_scandata->{'mpeg2_video_stream'}  =  0;
		
		foreach my $pid (keys %$pespids) {
			my $streamtype = $pespids->{$pid}{'stream_type'};

			if ($streamtype == 0x0f ) {  				# Check if ADTS AAC
				$log->info("Pid $pid is AAC ADTS ");
				$hls_scandata->{'mpeg2_audio_pid'}  = $pid;
				$hls_scandata->{'mpeg2_audio_type'} = $streamtype;
			} elsif ($streamtype == 0x15 ) {			# Check if metadata
				$log->info("Pid $pid is packetized metadata ");
				$hls_scandata->{'mpeg2_metadata_pid'}  = $pid;
			} else {
				$hls_scandata->{'mpeg2_video_stream'}  = 1 if (	$streamtype == 0x1b )  ; # Check if h264 video stream present
				$log->error(sprintf("Pid %d (%03x) unsupported stream type %d (%02x) ",$pid, $pid, $streamtype, $streamtype));
			}
		}

#  If bitrate is not defined or if bandwidth is both video & audio - then estimate audio bitrate

		if (!defined($track->bitrate) || $hls_scandata->{'mpeg2_video_stream'} ) {
			my $mpegdata       = Plugins::PlayHLS::HLSmpeg2::ParseMPEG2chunk($segment, $hls_scandata->{'mpeg2_audio_pid'}, $hls_scandata->{'mpeg2_metadata_pid'});
			my $streamdetails =  Plugins::PlayHLS::SegmentUtils::getADTSdetails($$mpegdata, 0);

			my $bitspersec = 128000; # Guess a default
			if (defined($adtsrates{$streamdetails->{'Sample_rate'}})) {
				$bitspersec = $adtsrates{$streamdetails->{'Sample_rate'}} ;
			} else {
				$bitspersec = (8 * length($segment) ) / $hls_scandata->{'segmentlength'} ;
			}
			
			$log->info(sprintf("Estimated bps %3d kbps ratio data/segment = %.2f",int($bitspersec/1000), (length($$mpegdata)/length($segment))));
			$track->bitrate($bitspersec);
		}
		
	} elsif (Plugins::PlayHLS::SegmentUtils::checkMPEG4Segment($segment)) {
		$streamtype   = 'aac' ;
		$hls_transport= 'MPEG4' ;
	} elsif (Plugins::PlayHLS::SegmentUtils::checkADTSSegment($segment))  {
		$streamtype = 'aac' ;
		$hls_transport= 'Packed-AAC' ;
#  If bitrate is not defined - then estimate bitrate
		if (!defined($track->bitrate)) {
			my %tagshash;
			my $bytesused = Plugins::PlayHLS::SegmentUtils::getID3frames(\%tagshash,$segment);
			my $bitspersec = 8 * int(length($segment) - $bytesused) / $hls_scandata->{'segmentlength'}  ;
			$log->info(" Estimated bps $bitspersec  chunk len ". $hls_scandata->{'segmentlength'}  . "segment bytes " .(length($segment) - $bytesused) );			
			$track->bitrate($bitspersec);
		}
		
	} elsif (Plugins::PlayHLS::SegmentUtils::checkMP3Segment($segment))  {
		$streamtype = 'mp3' ;
		$hls_transport= 'Packed-MP3' ;
	} else {
		$streamtype = 'unk';
		$hls_transport= 'Unknown' ;
	};

	$log->info("Probe done -  $streamtype  - transport $hls_transport");

	$hls_scandata->{'content'}   = $streamtype;
	$hls_scandata->{'transport'} = $hls_transport;

	$track->content_type( $streamtype );
	$track->update;
	
	# Success, done scanning 	 
	return $cb->( $track, undef, @{$pt} );	
}
