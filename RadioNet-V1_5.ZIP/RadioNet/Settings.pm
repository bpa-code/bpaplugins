package Plugins::RadioNet::Settings;

use strict;
use base qw(Slim::Web::Settings);

use Slim::Utils::Prefs;
use Slim::Utils::Log;


my $prefs = preferences('plugin.radionet');
my $log = logger('plugin.radionet');

sub init {
	$prefs->set('radionetlocale', 0)  unless (defined($prefs->get('radionetlocale')));
	$prefs->set('radionetshowurls', 0)  unless (defined($prefs->get('radionetshowurls')));
}

sub name {
	return 'PLUGIN_RADIONET';
}

sub page {
	return 'plugins/RadioNet/settings/basic.html';
}

sub prefs {
	return (preferences('plugin.radionet'), qw( prefFormat is_app radionetlocale radionetshowurls ));
}

sub beforeRender {
	my $class = shift;
	my $params= shift;

#   Fix - show_app had output from "can" function which was a code reference 
#   which it seems was executed in Template and not just treated as a value.
	$params->{'show_app'} = Slim::Plugin::Base->can('nonSNApps') ? 1 : 0 ;

}

1;
