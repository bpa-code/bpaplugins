#
#
# This program is free software; you can redistribute it and/or 
# modify it under the terms of the GNU General Public License, version 2.
#
#
package Plugins::RadioNet::GenreParser;

use strict;

use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Date::Parse;

use JSON::XS::VersionOneAndTwo;

use Encode qw(encode_utf8);

use MyText::Balanced;

my $log = logger('plugin.radionet');

use Data::Dumper;

sub parse
{
	my $class  = shift;
    my $http   = shift;

    my $params  = $http->params('params');
    my $url     = $params->{'url'};

	my $pageno =1  ;
	
    my @menu;
    my $stationsmatched;
    my $totalpages;
    
    if ($url =~ m/\?p=(\d+)/) {
		$pageno = $1;
    };

#  In the web page there is a JSON chunk of data assigned to a variable window.__CONTEXT_PROVIDER__ 

	my ($before, $after) = split (/\Qwindow.__CONTEXT_PROVIDER__ = \E/,$http->content,2);
	my 	@result = MyText::Balanced::extract_bracketed( $after, '{"}' );
	my 	$jsondata = eval { from_json($result[0]) };

	if ($@) {
		$log->error("Error parsing JSON data $@");
		return;
	}
	$log->debug(" Radio.net data info ". Dumper($jsondata->{'data'}));
	my $canonical_domain = 'https://'. $jsondata->{'data'}->{'DOMAIN'};

#	$log->info("Dump parsed JSON " . Dumper($jsondata->{'data'}->{'stations'}->{'playables'}));
	
	my $totalcount     = $jsondata->{'data'}->{'stations'}->{'totalCount'};
	my $stationscount  = $jsondata->{'data'}->{'stations'}->{'count'};
	
	my $totalpages = 1;
	if ($totalcount > $stationscount) {
		$totalpages = int(($totalcount + ($stationscount - 1))/ $stationscount); # Round up to get number of pages available
	}
	
	my $stations   = $jsondata->{'data'}->{'stations'}->{'playables'};
	
	$log->info("Dump of stations ".Dumper($jsondata->{'data'}->{'stations'}));
	
	foreach my $station (@{$stations}) {
		my $stationtype = $station->{'type'};
		my $stationurl  = ($stationtype eq 'PODCAST') ? "$canonical_domain/p/$station->{'id'}" : "$canonical_domain/s/$station->{'id'}" ;
		my $stationname = $station->{'name'};

#  Find a logo - if none defined fall back on Radio.net logo.
		my $stationlogo =     $station->{'logo300x300'} ?  $station->{'logo300x300'} 
							: $station->{'logo100x100'} ?  $station->{'logo100x100'} 
							: $station->{'logo630x630'} ?  $station->{'logo630x630'} 
							: Plugins::RadioNet::Plugin->_pluginDataFor('icon')
							;

		my $stationdesc = ' ('. $station->{'city'} .', '. $station->{'country'} ;
		$stationdesc .= ' / '. join(', ',@{$station->{'genres'}}) if (defined ($station->{'genres'}));
		$stationdesc .= ')' ;
		next unless defined ($stationname);
		
		push @menu, {
					'name'	      => $stationname . $stationdesc,
					'icon'        => $stationlogo,
					'cover'       => $stationlogo,
					'url'         => $stationurl ,
					'on_select'   => 'play',
					'parser'      => "Plugins::RadioNet::PlayableParser?type=$stationtype",			
					'description' => $stationdesc,
		};
		

		$menu[@menu -1]->{'type'} = 'playlist' if ($stationtype eq 'STATION' );
	}

	$log->info(" Menu ". Dumper(@menu));

#  Having processed all items - if Page 1 of genre then add menus for other pages in same genre.  
#  First find out how many pages.
	if ($pageno == 1) {
		for (my $i = 2; $i <= $totalpages; $i++) { 
			push @menu, {
				'name'	      => "Page $i - " . $params->{'feedTitle'},
				'url'         => "$url?p=$i",
				'icon'		  => $params->{'item'}->{'icon'} ,
				'cover'		  => $params->{'item'}->{'icon'} ,
				'parser'      => "Plugins::RadioNet::GenreParser",
			};	
		}
	}

# All done 
	if (scalar @menu == 0) {
		push @menu , {
			'icon'		  => $params->{'item'}->{'icon'} ,
			'cover'		  => $params->{'item'}->{'icon'} ,
			'name'	      => 'No programs found',
		} ;
	}

	$log->debug("Dump of menu ". Dumper(\@menu));

	# return xmlbrowser hash
	return {
		'type'  => 'opml',
		'title' => $params->{'feedTitle'},
		'items' => \@menu,
	};
}

1;
