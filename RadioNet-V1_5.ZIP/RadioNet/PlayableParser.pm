package Plugins::RadioNet::PlayableParser;

use strict;

use JSON::XS::VersionOneAndTwo;

use Slim::Utils::Log;
use Slim::Utils::Prefs;

use URI::Escape qw(uri_escape_utf8 uri_unescape);

use Data::Dumper;

use MyText::Balanced;

my $log = logger('plugin.radionet');
my $prefs = preferences('plugin.radionet');

sub _getopts {
	my $class  = shift;
	my $optstr = shift;
	my $opts   = shift;

	for my $opt (split /\&/, $optstr) {
		if ($opt =~ /(.*)=(.*)/       ) { $opts->{lc($1)}    = $2 } 
		else                            { $opts->{lc($opt)}  =  1 }
	}
}

sub parse {
    my $class  = shift;
    my $http   = shift;
    my $optstr = shift;

    my $params = $http->params('params');
    my $url    = $params->{'url'};

	my $opts   = {};
	$class->_getopts($optstr, $opts);
	
	my $podcast = ($opts->{'type'} eq 'PODCAST') ? 1 : 0;
	
	$log->info(" parse - $url type=".$opts->{'type'} );

#  In the web page there is a JSON chunk of data assigned to a variable window.__CONTEXT_PROVIDER__ 
	my ($before, $after) = split (/\Qwindow.__CONTEXT_PROVIDER__ = \E/,$http->content,2);
	my 	@result   = MyText::Balanced::extract_bracketed( $after, '{"}' );
	my 	$jsondata = eval { from_json($result[0]) };

	if ($@) {
		$log->error("Error parsing JSON data $@");
		return;
	}
	
	my $station_player   = $jsondata->{'player'};
	my $streams          = $jsondata->{'player'}->{'streams'};
#	my $canonical_domain = $jsondata->{'tenant'}->{'canonicalDomain'};	
	my $canonical_domain = 'https://'. $jsondata->{'data'}->{'DOMAIN'};

	my @submenu = ();

	my $icon	 =    $station_player->{'logo300x300'} ?  $station_player->{'logo300x300'} 
					: $station_player->{'logo100x100'} ?  $station_player->{'logo100x100'} 
					: $station_player->{'logo175x175'} ?  $station_player->{'logo175x175'} 
					: $station_player->{'logo630x630'} ?  $station_player->{'logo630x630'} 
					: Plugins::RadioNet::Plugin->_pluginDataFor('icon') 
					;	
					
	my $title  = $station_player->{'name'};
	my $desc   = $station_player->{'shortDescription'};
	my $artist = $station_player->{'country'};
	my $id     = $station_player->{'id'};

# Two types ofprocessing STATION and PODCAST  - podcast have optional many episodes
	if ($station_player->{'type'} eq 'STATION') {
		my $sourceurls = $station_player->{'streams'};
		$log->info("STATION sourceurls $title ". Dumper(\$sourceurls));

# Check if only one stream URL or only one wanted - return as a single audio stream.
		if ((scalar(@{$sourceurls}) == 1) || $prefs->get('radionetshowurls')) {
			return {
				'type'  => 'opml',
				'items' => [ {
					'name'   => $title,
					'artist' => $artist,
					'url'    => $sourceurls->[0]{'url'},
					'type'   => 'audio',
					'icon'   => $icon,
					'cover'   => $icon,
					'description' => $desc,
				} ],
				'cachetime' => 0,
				'replaceparent' => 1,
			};		
		}

# Multiple URLs offered - so make a playlist

# Note each URL seen to make list of unique URLs as there may be repeats in streamUrls
		my %seen;
		foreach my $stream (@{$sourceurls}) {
			if (!exists($seen{$stream->{'url'}})) {
				$seen{$stream->{'url'}} = 1;
				my $format = ' ('. $stream->{'contentFormat'} . ')';
						
				push @submenu, { 
					'name'        => $title ,   #  . $format,
					'description' => $desc,
					'type'        => 'audio',
					'icon'        => $icon,
					'cover'       => $icon,
					'url'         => $stream->{'url'},
				};
			}
		}
		
#  Return with Radio station data - make the URLs into a playlist
		return {
			'name'        => $title ,
			'artist'      => $artist,
			'icon'        => $icon,
			'cover'       => $icon,
			'type'        => 'playlist',
			'items'       => \@submenu,
			'on_select'   => 'play',
			'description' => $desc,
		};
		
	}

#  For podcast the streamUrls has the podcast feed.  Most time works wioth LMS Podcast player.

	if ($station_player->{'type'} eq 'PODCAST') {
		my $podcast_episodes = $jsondata->{'data'}->{'episodes'};
		my $episodecount = $podcast_episodes->{'totalCount'};

# Check if only one stream URL or only one wanted - return as a single audio stream.
		$log->info(" Podcast player ". Dumper($jsondata->{'player'}));			

		if (($episodecount == 1) || $prefs->get('radionetshowurls')) {
			my $episode = $podcast_episodes->{'episodes'}[0];

			return {
				'type'  => 'opml',
				'items' => [ {
					'name'   => $episode->{'title'},
					'artist' => $episode->{'description'},
					'url'    => $episode->{'url'},
					'type'   => 'audio',
					'icon'   => $icon,
					'cover'  => $icon,
					'description' => $station_player->{'description'},
				} ],
				'cachetime' => 0,
				'replaceparent' => 1,
			};		
		}
		
#
#  Here where there are more than one episode.
#

		foreach my $episode (@{$podcast_episodes->{'episodes'}}) {
			push @submenu, { 
				'name'   => $episode->{'title'} ,  #  . '('.$episode->{'contentFormat'}.')',
				'artist' => $episode->{'description'},
				'url'    => $episode->{'url'},
				'type'   => 'audio',
				'icon'   => $icon,
				'cover'  => $icon,
				'description' => $station_player->{'description'},
			};
		}		


		$log->info("Name $title   Episodecount $episodecount  submenu ".scalar(@submenu) . " icon =$icon"); 
		
		
		if ($episodecount > scalar (@submenu)) {
	
			my $totalpages = int( ( ($episodecount - scalar (@submenu))  + 49) / 50); # 50 Epsiuode per page - round up to get number of pages available
			
			my $offset = scalar (@submenu) ;
			for (my $i = 1; $i <= $totalpages ; $i++) {
				push @submenu, {
					'name'    => "More Episodes - page $i", 
					'icon'    => $icon,
					'cover'   => $icon,
					'url'     => "https://prod.radio-api.net/stations/legacy/$id/episodes?count=50&offset=$offset",
					'parser'  => 'Plugins::RadioNet::MoreEpisodes',
				};
				
				$offset = $offset + 50;
			}
		}

		$log->debug("Submenu dump \n". Dumper(@submenu));	
# Unlike the STATION - the URLs are not a playlist but separately playable
		return {
			'name'        => $title ,
			'artist'      => $artist,
			'icon'        => $icon,
			'cover'       => $icon,
			'type'        => 'opml',
			'items'       => \@submenu,
			'description' => $desc,
		};
	
	}

#  Not STATION or PODCAST playable type - so return undef.
	
	return undef;

}


# Local Variables:
# tab-width:4
# indent-tabs-mode:t
# End:

1;
