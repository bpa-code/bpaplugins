package Plugins::RadioNet::MoreEpisodes;

use strict;

use JSON::XS::VersionOneAndTwo;

use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Data::Dumper;

my $log = logger('plugin.radionet');
my $prefs = preferences('plugin.radionet');

sub parse {
    my $class  = shift;
    my $http   = shift;
	my $params  = $http->params('params');

    my $url          = $params->{'url'};
    my $client       = $params->{'client'};
	my $top_icon     = $params->{'item'}->{'icon'};
	my $menuText     = $params->{'item'}->{'text'};	

	my $jsondata = eval { from_json(${$http->contentRef}) };

	if ($@) {
		$log->error("Error parsing JSON data $@");
			return;
		}

	$log->info("Dump parsed JSON " . Dumper($jsondata));

	my @menu;
	my $episodes = $jsondata->{'episodes'};

# Take each episode and make a menu item

	foreach my $episode (@{$episodes}) {
		push @menu, { 
			'name'   => $episode->{'title'},  # . '('.$episode->{'contentFormat'}.')',
			'artist' => $episode->{'description'},
			'url'    => $episode->{'url'},
			'type'   => 'audio',
			'icon'   => $top_icon,
#			'description' => $station_player->{'description'},
		};
	}		

	return {
		'type'  => 'opml',
		'title' => $params->{'feedTitle'},
		'items' => \@menu,
	};
}


# Local Variables:
# tab-width:4
# indent-tabs-mode:t
# End:

1;
