package Plugins::Live365::Settings;

use strict;
use base qw(Slim::Web::Settings);

use Slim::Utils::Prefs;
use Slim::Utils::Log;

use Data::Dumper;


my $prefs = preferences('plugin.live365');
my $log   = logger('plugin.live365');



sub init {
}

sub name {
	return 'PLUGIN_LIVE365';
}

sub page {
	return 'plugins/Live365/settings/basic.html';
}

sub prefs {
	return (preferences('plugin.live365'), qw( is_app live365results defaulturl ));
}

sub beforeRender {
	my $class = shift;
	my $params= shift;

    my @prefresultsOpts =  ({ result =>    1,  resulttext =>  '20'},
							{ result =>    3,  resulttext =>  '60'},
							{ result =>    5,  resulttext => '100'},
							{ result =>    8,  resulttext => '160'},
							{ result =>    12, resulttext => '240'}, 
							{ result =>    15, resulttext => '300'},
							{ result =>    20, resulttext => '400'},
							{ result =>    25, resulttext => '500'} );

	$params->{'resultsopts'} = \@prefresultsOpts;
    
#   Fix - show_app had output from "can" function which was a code reference 
#   which it seems was executed in Template and not just treated as a value.
	$params->{'show_app'} = Slim::Plugin::Base->can('nonSNApps') ? 1 : 0 ;

}

1;
