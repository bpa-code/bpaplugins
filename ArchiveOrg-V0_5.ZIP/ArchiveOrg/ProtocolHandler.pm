package Plugins::ArchiveOrg::ProtocolHandler;


# Copyright (C) 2021 baltontwo@eircom.net
#
# This file is part of LMS_ArchiveOrg_Plugin.
#
# LMS_ArchiveOrg_Plugin is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# LMS_ArchiveOrg_Plugin is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with LMS_ArchiveOrg_Plugin.  If not, see <http://www.gnu.org/licenses/>.

use strict;
use base qw(Slim::Player::Protocols::HTTPS);


use Data::Dumper;
use JSON::XS::VersionOneAndTwo;

use Slim::Utils::Strings qw(string cstring);
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::Errno;
use Slim::Utils::Cache;

my $log   = logger('plugin.archiveorg');
my $cache = Slim::Utils::Cache->new;
my $prefs = preferences('plugin.archiveorg');

Slim::Player::ProtocolHandlers->registerHandler( 'accur', __PACKAGE__ );

sub new {
	my $class  = shift;
	my $args   = shift;

	my $client = $args->{client};

	my $song      = $args->{song};
	my $streamUrl = $song->streamUrl() || return;

	$log->info(" ArchiveOrg to play URL $streamUrl");

	my $sock = $class->SUPER::new( {
		url     => $streamUrl,
		song    => $args->{song},
		client  => $client,
	} ) || return;

	return $sock;
}

# Avoid scanning - Scanning is done later when a real URL is got from playlist
sub scanUrl {
	my ( $class, $url, $args ) = @_;

	$args->{cb}->( Slim::Schema->objectForUrl( {
		url => $url,
	} ) );
}

sub isRemote { 1 }

sub canSeek { 1 }

sub getFormatForURL { 'mp4' }

sub formatOverride {
	my ($class, $song) = @_;
	return 'mp4';
}

sub audioScrobblerSource {
# R (radio source)
	return 'R';
}

sub getSeekData {
	my ( $class, $client, $song, $newtime ) = @_;

	$log->info( 'Trying to seek ' . $newtime . ' seconds for offset ' . $song->track->audio_offset );

	return { timeOffset => $newtime };
}

sub isRepeatingStream {
	my ( undef, $song ) = @_;

#	$log->error("  repeating URL ".$song->track()->url);
	return $song->track()->url =~ /^accur/;
}


sub explodePlaylist {
	my ( $class, $client, $uri, $cb ) = @_;

	my $song = $client->playingSong();
	
#	$log->error(" ArchiveOrg - explode URI $uri");

		my ($baseurl, $body) = split(/\?/, $uri);
# rand param may be just to fool caching mechanisms - seems to work without it
		$body .= sprintf('&rand=%0.17f',rand(1));
				
		my $archiveorg_url = "https://www.archiveorg.com/c/m/json/channel/";
		my $http = Slim::Networking::SimpleAsyncHTTP->new(
			\&_gotMetaChannelOK,
			\&_gotMetaChannelError,
				{
					client  => $client,
					cache   => 0,
					timeout => 30,
					cb		=> $cb,
					uri     => $uri,
					song	=> $song,
				}
		);
	
		$http->post(
				$archiveorg_url,
				'Content-Type' => 'application/x-www-form-urlencoded',
				'User-Agent'    => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.13; rv:56.0; SlimServer) Gecko/20100101 Firefox/57.0',
				'Host' => 'www.archiveorg.com',
				$body,
		);
	return;
}

sub _gotMetaChannelOK {
	my $http   = shift;
	my $params = $http->params;	
	my $cb 	   = $params->{'cb'};

	my $info = eval { from_json( $http->content ) };
	if ($@) {
		$log->error("Error parsing JSON data $@");
		$cb->([]);
	};

# Create real URL from Meta to get Playlist

	my $oid  		 = $info->{'_id'}->{'$oid'};
	my $ando 		 = $info->{'ando'};
	my $spotschedule = $info->{'spotschedule'};
	
	my $playlist_url = "accur://www.archiveorg.com/playlist/json/$oid/?ando=$ando&fa=null";
	$cb->([$playlist_url]);
	return;
}

sub _gotMetaChannelError {
	my $http   = shift;
	my $params = $http->params;	
	my $cb 	   = $params->{'cb'};
	$cb->([]);
}

sub _gotPlaylistOK {
	my $http   = shift;
	my $params = $http->params;	
	my $playlist_url   = $params->{'playlist'};

	my $song = $params->{'song'};

	my $info = eval { from_json( $http->content ) };
	if ($@) {
		$log->error("Error parsing JSON data $@");
		$params->{errorCb}->()
	};

	my $playlist;
	my $icon = Plugins::ArchiveOrg::Plugin->_pluginDataFor('icon');
	
	foreach my $item (@$info) {
		next if ($item->{'track_artist'} eq 'runspot') ;  # skip all ad spots
		my $item_title    = $item->{'title'};
		my $item_artist   = $item->{'track_artist'};
		my $item_album    = $item->{'album'}->{'title'};
		my $item_duration = $item->{'duration'};
		my $item_url      = $item->{'primary'} . $item->{'fn'}. '.m4a';
		
# https://www.archiveorg.com/static/images/covers300/covers/n-s/various_rocknrollchristmasii.jpg		
		my $item_icon     = 'https://www.archiveorg.com/static/images/covers300'.$item->{'album'}->{'cdcover'} ;
	
		push @$playlist, { 'title'    => $item_title,
						  'artist'   => $item_artist,
						  'album'    => $item_album,
						  'cover'    => $item_icon,
						  'duration' => $item_duration,
						  'url'      => $item_url,
						 };
	}

#	$log->error(" dump of playlist \n".Data::Dump::dump($playlist));
	
	$song->pluginData('playlist',$playlist);
	$song->pluginData('playlist_index',0);
	_streamNextItem ($playlist->[0], $song, $params->{successCb}, $params->{errorCb});

}

sub _streamNextItem {
	my ( $item, $song, $successCb, $errorCb ) = @_;

	my $cache = Slim::Utils::Cache->new;
	
	
	my $nexturl = $item->{'url'};
	$song->streamUrl($nexturl);
	$cache->set( 'archiveorg_meta_'.$nexturl, $item, 86400 );

	Slim::Utils::Scanner::Remote::parseRemoteHeader(
		$song->track, $nexturl, 'mp4',
		sub {
#			$log->error(sprintf(" Sample rate %d  Sample Size %d  Channels %d  Bitrate %d  Duration %d ",  
#								$song->track->samplerate(), $song->track->samplesize(), $song->track->channels(),
#								$song->duration(), $song->bitrate()));
			$successCb->();
		},
		sub {
			my ($self, $error) = @_;
			$log->warn( "could not find mp4 header $error" );
			$errorCb->();
		} );	
}

sub _gotPlaylistError {
	my $http   = shift;
	my $params = $http->params;	
	my $ecb    = $params->{'errorCb'};
	$ecb->([]);
}

# fetch the next archiveorg url and extract a playable stream
sub getNextTrack {
	my ( $class, $song, $successCb, $errorCb ) = @_;

	my $url    = $song->currentTrack()->url;
	
	$log->info("Get next track for Url $url");
	
	my $current_index = $song->pluginData('playlist_index');
	my $playlist      = $song->pluginData('playlist');
	
	if ( defined($playlist) ) {
		$current_index++;
		if ($current_index < scalar(@$playlist) ) {
			$song->pluginData('playlist_index',$current_index);
			_streamNextItem ($playlist->[$current_index], $song, $successCb, $errorCb );
			return;
		} 
#		else {
#				$log->error("At end of current playlist");
#		}
	}

#
# Here is 1st playlist or current is played out. So fetch new copy of playlist.
# 	
	my $playlist_url = $url;
	$playlist_url =~ s/^accur:/https:/; 
	$playlist_url .= sprintf('&rand=%0.17f',rand(1));

	my $http = Slim::Networking::SimpleAsyncHTTP->new(
			\&_gotPlaylistOK,
			\&_gotPlaylistError,
				{
					playlist  => $playlist_url,
					url       => $url,
					cache     => 0,
					timeout   => 30,
					song      => $song,
					successCb => $successCb,
					errorCb   => $errorCb,
				}
		)->get($playlist_url);
}

sub getMetadataFor {
	my ( $class, $client, $full_url ) = @_;

	my $icon = $class->getIcon();
	my $song = $client->playingSong();
	
	my $meta = {
		type  => 'ArchiveOrg',
		title => $full_url,
		icon  => $icon,
		cover => $icon,
	};

	if ( $song) {
		my $cache = Slim::Utils::Cache->new;
		my $item = $cache->get( 'archiveorg_meta_'.$song->streamUrl());
		
		$meta->{'icon'}   = $item->{'cover'} ;
		$meta->{'cover'}  = $item->{'cover'} ;
		$meta->{'title'}  = $item->{'title'};
		$meta->{'artist'} = $item->{'artist'};
		$meta->{'album'}  = $item->{'album'};
	}
	return $meta;
}

sub getIcon {
	my ( $class, $url ) = @_;
	return Plugins::ArchiveOrg::Plugin->_pluginDataFor('icon');
}

1;
