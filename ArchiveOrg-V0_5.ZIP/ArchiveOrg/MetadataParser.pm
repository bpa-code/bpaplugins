package Plugins::ArchiveOrg::MetadataParser;

use strict;
use JSON::XS::VersionOneAndTwo;

use Slim::Utils::Log;
use Slim::Utils::Strings qw(string);

use Data::Dumper;

my $log = logger('plugin.archiveorg');

my %audio_formats = ( 'VBR MP3' => 'MP3', 'Ogg Vorbis' => 'OGGVORBIS', '24bit Flac' => 'FLAC24', 'Flac' => 'FLAC', 'WAVE' =>'WAV', 'WMA' => 'WMA');

sub parse {
	my ($class, $http, $params) = @_;

    my $jsondata = eval { from_json(${$http->contentRef}) };
    if ($@) {
       $log->error("Error parsing JSON data $@");
    };

    my $menu;
    my %menus;

    my $ident = $jsondata->{'metadata'}->{'identifier'};
    my $icon  = "https://archive.org/download/$ident/__ia_thumb.jpg";

    $log->debug("Metadata for $ident ". Dumper($jsondata));

    foreach my $item (@{$jsondata->{'files'}}) {
        if (exists( $audio_formats{$item->{'format'}} )) {

            my $codec = $audio_formats{$item->{'format'}};
            my $name = exists( $item->{'title'} ) ? $item->{'title'} : ($jsondata->{'metadata'}->{'title'} . ' - ' .$item->{'name'} ) ;
             
            if ($item->{'artist'}) {
                $name .= ' ('. $item->{'artist'} .')'                
            } elsif  ($item->{'creator'}) {
                $name .= ' ('. $item->{'creator'} .')'                
            };
            
            if ($item->{'track'}) {
                $name = $item->{'track'} . ' '.$name;
            };
            
            push (@{$menus{$codec}}, {
              name =>  $name,
              url  => "https://archive.org/download/$ident/". $item->{'name'} ,
              icon  => $icon,
              cover => $icon,
              type => 'audio',
 			 'on_select'   => 'play',
             description => exists ($item->{'comment'} ) ? $item->{'comment'} : $jsondata->{'metadata'}->{'description'},

            });
       };
    };
    
    $log->debug(" Dump of menus ".Dumper(%menus));

# Make MP3 menu defauilt - add other formats as submenus to MP3 menu
    my $fullmenu = $menus{'MP3'} ;
    if (exists ($menus{'OGGVORBIS'})) {
        push @$fullmenu, {
                    'name'   => 'Ogg Vorbis',
                    'items'  => $menus{'OGGVORBIS'},
                    icon  => $icon,
                    cover => $icon,
                    'type'   => 'opml',
                    'nocache' => 1,
        }
	};


    if (exists ($menus{'FLAC'})) {
        push @$fullmenu, {
                    'name'   => 'Flac',
                    'items'  => $menus{'FLAC'} ,
                    'type'   => 'opml',
                    icon  => $icon,
                    cover => $icon,
                    'nocache' => 1,
        }
	};

    if (exists ($menus{'FLAC24'})) {
        push @$fullmenu, {
                    'name'   => 'Flac 24 bit',
                    'items'  => $menus{'FLAC24'}, 
                    icon  => $icon,
                    cover => $icon,
                    'type'   => 'opml',
                    'nocache' => 1,
        }
	};

    if (exists ($menus{'WAV'})) {
        push @$fullmenu, {
                    'name'   => 'Wave',
                    'items'  => $menus{'WAV'},
                    icon  => $icon,
                    cover => $icon,
                    
                    
                    'type'   => 'opml',
                    'nocache' => 1,
        }
	};

    $log->debug("Dump fullmenu ". Dumper(\$fullmenu));  

    push @$fullmenu,{ 
              'name'  => string('PLUGIN_ARCHIVEORG_NOAUDIOFOUND'),
              'type'  => 'text'
           } if ( ! defined ($fullmenu ));

	return {
		'name'    => $params->{'feedTitle'},
		'items'   => $fullmenu,
		'type'    => 'opml',
		'nocache' => 1,
	};
}


1;
