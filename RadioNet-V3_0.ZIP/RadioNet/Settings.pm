package Plugins::RadioNet::Settings;

use strict;
use base qw(Slim::Web::Settings);

use Slim::Utils::Prefs;
use Slim::Utils::Log;

use Data::Dumper;


my $prefs = preferences('plugin.radionet');
my $log   = logger('plugin.radionet');

sub init {
	$prefs->set('radionetlocale', 0)  unless (defined($prefs->get('radionetlocale')));
}

sub name {
	return 'PLUGIN_RADIONET';
}

sub page {
	return 'plugins/RadioNet/settings/basic.html';
}

# prefs prefFormat and radionetshowurls - are required legacy for V1.* backward support of existing Favorites. 

sub prefs {
	return (preferences('plugin.radionet'), qw( prefFormat is_app radionetlocale use_locale radionetshowurls));
}

sub beforeRender {
	my $class = shift;
	my $params= shift;

#   Fix - show_app had output from "can" function which was a code reference 
#   which it seems was executed in Template and not just treated as a value.
	$params->{'show_app'} = Slim::Plugin::Base->can('nonSNApps') ? 1 : 0 ;

}

sub handler {
	my ($class, $client, $params) = @_;

	my $oldlocale     = $prefs->get('radionetlocale');
	my $olduselocale  = $prefs->get('use_locale');

	my $ret = $class->SUPER::handler($client, $params);

# If locale and language pref has changed - then regenerate the top level menus.
	if ($params->{'saveSettings'} && 
	   (($params->{'pref_radionetlocale'} != $oldlocale) || 
	    ($params->{'pref_use_locale'}     ne $olduselocale))) {
			$log->info(" changes menus/locale ". $params->{'pref_radionetlocale'} . " and prefs ".$prefs->get('radionetlocale'));
			Plugins::RadioNet::Plugin::updateLocale();
	}
	return $ret;
}


1;
