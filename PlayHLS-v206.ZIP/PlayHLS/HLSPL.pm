package Plugins::PlayHLS::HLSPL;

use strict;
use base qw(Slim::Formats::Playlists::Base);

use URI;
use File::Slurp;


use Slim::Music::Info;
use Slim::Utils::Misc;
use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Data::Dumper;

my $log = logger('plugin.playhls');

my $prefs = preferences('plugin.playhls');

my $codecIds = {
	"mp4a.40.1" => "AAC",
	"mp4a.40.2" => "AAC LC",
	"mp4a.40.5" => "AAC SBR",
};

#  Format of top level m3u8 playlist file.  Only support simple EXT-X-STREAM-INF
#EXTM3U
#EXT-X-STREAM-INF:BANDWIDTH=49000,CODECS="mp4a.40.5"
# URL to used as the playlist that needs to be refreshed every 10sec.
#
#  If the URL contents has EXT-X-TARGETDURATION or EXT-X-MEDIA-SEQUENCE then it is a MEDIA playlist not a MASTER one - so to try to play - pass it on to HLSPLAY
#
#
sub _make_BaseUrl {

	my $plurl  = shift;
	my $baseurl = shift;
	
	if ($baseurl =~ /^http:\/\//) {
	  return $baseurl;
	}
	  
	my $url = URI->new_abs($baseurl,$plurl);
	return $url->canonical->as_string;
}

sub read {
    my ($class, $pl, undef, $url) = @_;
    my @items  = ();
    my @lines;
    my $data = '';

    $log->info("parsing HLS playlist: $url");
	
#  Read the HLS master playlist
    
    while (defined($pl) && (my $entry = <$pl>)) {
		
        chomp($entry);
        $entry =~ s/\cM//g;  

        # strip whitespace from beginning and end
        $entry =~ s/^\s*//; 
        $entry =~ s/\s*$//; 
        push @lines,$entry;
     } ;
        
#
#  According to HLS spec https://tools.ietf.org/html/draft-pantos-hls-rfc8216bis-00
#  This routine is for parsing a Master Playlist.  So no EXTINF.  If there is a EXTINF then it is a media playlist 
#  and this URL should be handled by HLSPLAY directly protocol handler
#
#  First line must be #EXTM3U for both Master playlist and Media Playlist
	my $line = shift @lines;

	if ($line ne '#EXTM3U') {
		$log->error("First line not EXTM3U  >>$line<<");
		return;	
	};

#    $log->info("Dump of lines ". Dumper(\@lines));
	
	$line = shift @lines;
	
	my @playlist;
	my $lineno = 1;
	my $extinf_seen = 0;
	my $ext_targetduration_seen = 0;
        
	while ($#lines >= 0) {
		if ($line =~ /^#EXTINF:(.*),/) {
			$extinf_seen = 1;
		};
	
		if ($line =~ /^#EXT-X-TARGETDURATION:/) {
			$ext_targetduration_seen = 1;
		};
			 
		if ($line =~ /^#EXT-X-STREAM-INF:(.*)/) {
			my $bitrate;
			my $codec;
			foreach my $params (split(/,/, $1)) {
				if ($params =~ /BANDWIDTH=(\d+)/) {
					$bitrate = $1;
					$log->info("bandwidth: $1");
				} elsif ($params =~ /CODECS="(.*)"/) {
					$codec = $codecIds->{$1};
					if ($codec) {
						$log->info("codecs: $1 $codec");
					}
				}
			}
			my $plurl = shift @lines;
			my $hlsUrl = _make_BaseUrl($url,$plurl);

			$hlsUrl =~ s/^https/hlsplays/;
			$hlsUrl =~ s/^http/hlsplay/;
			$hlsUrl =~ s/$/\|/;			
			push @playlist , { 'entry' => $lineno, 'url' => $hlsUrl, 'bitrate' => $bitrate , 'codec' => $codec };
		}	
		$line = shift @lines;
		$lineno++;
	}
	
	if ($#playlist >= 0) {
		my @sortedplaylist =  sort { $b->{'bitrate'} <=> $a->{'bitrate'} or $a->{'entry'} <=> $b->{'entry'} } @playlist;
		$log->info("Dump of sorted playlist ". Dumper(\@sortedplaylist));
    
		my $top_url     = $sortedplaylist[0]{'url'};
		my $top_bitrate = $sortedplaylist[0]{'bitrate'};
#
#  Need to check this - not sure why content type of aacx is used. ?? Forgotten 
#	
		my $title = Slim::Music::Info::title($url);
		if ($class->playlistEntryIsValid($top_url, $url)) {
			push @items, $class->_updateMetaData($top_url, { 'TITLE' => $title, 'BITRATE' => $top_bitrate , 'CT' => 'aacx' }, $url);
		};
		return @items;
	}
	
#  If Media playlist was given instead of master playlist = put the media playlist straigh into playlist

	$log->warn(" Not a Master media playlist - missing #EXT-X-STREAM-INF in url $url");

	if ($extinf_seen ) {
		$log->warn(sprintf(" Attempt to play Media playlist as %s %s persent for url %s", $extinf_seen ? "EXTINF" : "",  $ext_targetduration_seen ? "EXT-X-TARGETDURATION" : "", $url)); 	
		my $title = Slim::Music::Info::title($url);
		my $hlsUrl = $url;
		$hlsUrl =~ s/^https/hlsplays/;
		$hlsUrl =~ s/^http/hlsplay/;
		$hlsUrl =~ s/$/\|/;			
		
		push @items, $class->_updateMetaData($hlsUrl, { 'TITLE' => $title }, $url);
		return @items;
	}
	
 return ;
}

1;

# Local Variables:
# tab-width:4
# indent-tabs-mode:t
# End:
