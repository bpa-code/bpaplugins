package Plugins::Live365::Plugin;


# Copyright (C) 2022 baltontwo@eircom.net
#
# This file is part of LMS Live365 Plugin.
#
# Live365 Plugin is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# LMS_Live365_Plugin is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with LMS Live365 Plugin.  If not, see <http://www.gnu.org/licenses/>.

use strict;
use warnings;

use base qw(Slim::Plugin::OPMLBased);

use JSON::XS::VersionOneAndTwo;
use Digest::MD5 qw(md5_hex);
use URI::Escape;

use Slim::Utils::Log;
use Slim::Utils::Prefs;

use Plugins::Live365::Settings;

use constant LIVE365URL => 'https://live365.com/listen.data';
use constant LIVE365APIURL => 'http://api.live365.com';

use Data::Dumper;

my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.live365',
	'defaultLevel' => 'ERROR',
	'description'  => getDisplayName(),
});

my $prefs      = preferences('plugin.live365');
my $pluginName = 'Live365';

use constant CACHEONEHOUR   =>  3600; 
use constant CACHE15MINS    =>   900;    

my %cacheURLs;

my %deref;	# Global to prevent loop in recursive dereferencing

sub getCachedMenu {
	my $url = shift;

	if (exists( $cacheURLs{$url}))  {
#		$log->error(" cached entry dump ".Dumper($cacheURLs{$url}));

		if ($cacheURLs{$url}{'expiry'} > time()) { # Check for expired entry
			return $cacheURLs{$url}{'menu'} ;
		};

#		$log->error(" Expired now ".time(). " Expiry ". $cacheURLs{$url}{'expiry'}. " URL $url");
		delete ($cacheURLs{$url})
	}
	return;
}

sub cacheMenu {
	my ( $url, $menu, $seconds ) = @_;	

	$cacheURLs{$url} = {'expiry' => time() + $seconds, 
					   'menu'   =>  $menu} ;
	$log->debug(" Cache for $seconds URL $url");

	return;
}

# Fixup callable routine table - fixup need because CODE cannot be saved when menu is cached.

my %subItems = (
	'getGenres' 	    => \&getGenres,
	'getGenresResults'  => \&getGenresResults,    
	'getSearch'         => \&getSearch,    
	'getSearchPage'     => \&getSearchPage,    
	);


sub fixupCodeRefs {
	my $menu = shift;

	for my $menuItem (@$menu) {
		my $codeRef = $menuItem->{passthrough}[0]->{'codeRef'};
#		$log->info(" Fixup menu $codeRef for ".$menuItem->{'name'} );

		if ( defined $codeRef ) {
			$log->error("Fixup failed for undefined routine: $codeRef ") unless (exists($subItems{$codeRef}));
			$menuItem->{'url'} = $subItems{$codeRef};
		}
# Fixup submenu if one is present
		fixupCodeRefs($menuItem->{'items'}) if (defined $menuItem->{'items'}) ;
	}
	return;
}
				 
sub initPlugin {
	my $class = shift;

# live365results is the number of pages with 20 entries per page so 8 is 160.
	$prefs->init({ is_app => 0 , live365results => 8, defaulturl => 1 });

	Plugins::Live365::Settings->new($class);
	Plugins::Live365::Settings->init($class);

	$class->SUPER::initPlugin(
		feed   => \&handleFeed,
		tag    => 'live365',
		is_app => $class->can('nonSNApps') && $prefs->get('is_app') ? 1 : undef,
		menu   => 'radios',
		weight => 1,
	);

	Plugins::Live365::Settings->new;
	createMenus();
}

sub fixuplogo {
    
    my $logo = shift;
    $log->debug(" Logo before $logo");
    return $logo unless ( $logo =~ m/image.live365.com/);
    
    $logo =~ s|image.live365.com|media.live365.com|;
    $logo =~ s|/400/image.webp||;
    $logo =~ s|/1300/image.webp||;
    
    $log->debug(" Logo after $logo");
    
    return $logo;
}


my $topStationsMenu;
my $editorMenu;
my $buildId;

sub createMenus {

	Slim::Networking::SimpleAsyncHTTP->new(
		sub { 						# Success - page fetched.
            my $http = shift;
            my $jsondata = eval { from_json($http->content) };
#           $log->error(" JSON extract ". Dumper(\$jsondata));
            if ($@) {
                $log->error("Error parsing JSON data $@");
                return;
            }
			$log->info("Found data ". Dumper(\$jsondata));

			undef %cacheURLs;

			$jsondata = derefjsonpath($jsondata, '($lang).listen._index');
			createTopLevelMenus($jsondata);
		},
		
		sub { # Page fetch error 
			my $http = shift;
			my $error  = $http->error;			
			$log->error(" Failed to get initial page from Live365.com - error: $error");
		},
        {
           cache => 1,
           expires => CACHE15MINS,
        }
	)->get(LIVE365URL)	
}

sub createTopLevelMenus {
			my $jsondata = shift; 
			$log->debug("Make editor and top station menus");
			$editorMenu      = makeEditorMenu     ($jsondata->{'editorsPick'});
			$topStationsMenu = makeEditorMenu     ($jsondata->{'topStations'});
}


sub handleFeed {
	my ($client, $callback, $params, $args) = @_;
    
#    $log->error(" Callback is ".Slim::Utils::PerlRunTime::realNameForCodeRef($callback)");

# Need to re-fetch BuildId as it can change but not frequently so value is cached for 15 mins 

	Slim::Networking::SimpleAsyncHTTP->new(
		sub { 						# Success - page fetched.
			my $http = shift;
            my 	$jsondata = eval { from_json($http->content) };
#           $log->error(" JSON extract ". Dumper(\$jsondata));
            if ($@) {
                $log->error("Error parsing JSON data $@");
                return;
            }
#			$log->info("Found data ". Dumper(\$jsondata));
			$jsondata = derefjsonpath($jsondata, '($lang).listen._index');
			createTopLevelMenus($jsondata);

            my $menu = [
                {
                    name        => 'Search',
                    type        => 'search',
                    url         => \&getSearch,
                    passthrough => [ { 'pageno' => 1, 'searchtype' => 'general'} ],
                },	
                {
                    name        => 'Top Stations',
                    type        => 'link',
                    items       => $topStationsMenu,
                },	
                {
                    name        => "Editor's pick",
                    type        => 'link',
                    items       => $editorMenu,
                },	
                {
                    name        => 'Genres',
                    type        => 'link',
                    url         => \&getGenres,
                },	
            ];
            $callback->( { items => $menu } );    
 		},
		
		sub { # Page fetch error 
			my $http = shift;
			my $error  = $http->error;			
			$log->error(" Failed to get initial page from Live365.com - error: $error");
		},
        {
           cache => 1,
           expires => CACHE15MINS,
        }
	)->get(LIVE365URL)	

	
}


sub makeEditorMenu {
	my $editorspicks    = shift;
	my @menu;
    
	foreach my $editorspick  (@$editorspicks) {

#	$log->debug("Station: $editorspick->{'name'}");
	my $streamUrl;
	
	if ( exists $editorspick->{'streamUrl'} ){
		if ( ref $editorspick->{'streamUrl'} eq '' ){
			$streamUrl = $editorspick->{'streamUrl'};
		} elsif ( ref $editorspick->{'streamUrl'} eq 'HASH' && exists $editorspick->{'streamUrl'}->{'default'} ){
			$streamUrl = $editorspick->{'streamUrl'}->{'default'};
		} else {
			$log->debug("Could not find stream URL for $editorspick->{'name'}");
		}
	}
	
        push @menu, {
				'name'        => $editorspick->{'name'},
				'image'	      => fixuplogo($editorspick->{'logo'}),
				'icon'	      => fixuplogo($editorspick->{'logo'}),
				'type'        => 'audio',
				'url'	      => $streamUrl,
				'on_select'   => 'play',
				'description' => $editorspick->{'description'},        
                };
    }
    return \@menu;
}

sub commonFetchParse {
	my ( $client, $callback, $args, $passthrough,$sourceUrl, $parseRoutine ) = @_;
	
	if (  my $cachemenu = getCachedMenu($sourceUrl) )  {
		fixupCodeRefs($cachemenu);
		$callback->( { items => $cachemenu } );
		return;
	}
    
	$log->debug(" Fetching url $sourceUrl");
	my $starttime  = Time::HiRes::time() ;
	Slim::Networking::SimpleAsyncHTTP->new(
		sub {
			my $http = shift;
			
			my $fetchedtime = Time::HiRes::time() - $starttime ;
			my $menu = $parseRoutine->($http->content,$sourceUrl);
			my $parsedtime = Time::HiRes::time() - $starttime ;
			
			$log->debug(sprintf("Fetch delay %15.6f  Parse delay %15.6f for url %s ",$fetchedtime,$parsedtime, $sourceUrl)); 

			cacheMenu($sourceUrl, $menu, CACHEONEHOUR);			
			fixupCodeRefs($menu);
			$callback->( { items => $menu } );
		},

		# Called when no response was received or an error occurred.
		sub {
			$log->warn("Error on url \"$sourceUrl\" : $_[1] ");
			$callback->( [ { name => $_[1], type => 'text' } ] );
		}
	)->get($sourceUrl);

	return;
}

sub getSearchPage {
	my ( $client, $callback, $args, $passthrough ) = @_;
	
	my $searchPageUrl = $passthrough->{'url'};
	commonFetchParse($client, $callback, $args, $passthrough,
					$searchPageUrl,
					\&parseSearchReply);
};


sub getGenres {
	my ( $client, $callback, $args, $passthrough ) = @_;
	
	my $genresUrl = 'https://api.live365.com/genres';

	commonFetchParse($client, $callback, $args, $passthrough,
					$genresUrl,
					\&parseTopGenresReply);
};

sub getGenresResults {
	my ( $client, $callback, $args, $passthrough ) = @_;
    
	$log->debug(" passthrough ".Dumper(\$passthrough));
	
	my $subgenresUrl = $passthrough->{'url'};

	commonFetchParse($client, $callback, $args, $passthrough,
					$subgenresUrl,
					\&parseGenresResultsReply);
}


# Search results are not cached - maybe it should be.

sub getSearch {
	my ( $client, $callback, $args, $passthrough ) = @_;

	my $searchUrl;

# Search results are paged but cumulative Page 1 has 20 hits, page 2 has 40 hits 
# Currently Live365 returns 20 hits per page.

#  Search key is defined on first search - subsequent pages should reuse same query string from first page of results

	if (defined($args->{'search'})) {
	    my $searchstr = URI::Escape::uri_escape_utf8($args->{'search'});
	$searchUrl = "https://live365.com/listen/search.data?query=$searchstr";	# path routes/($lang).listen.search
	} 
	commonFetchParse($client, $callback, $args, $passthrough,
					$searchUrl,
					\&parseSearchReply);
};

# Genres Name are not the same as used in the URLs.  Terminology used in JS is name -> slug.  
# Roughly all words in Genre descriptions are separated by hypens for URL but there are special cases.
# No mapping provided in page returned - so hack after looking for special cases.

# There are excpetion which are 'talk' stations.

my %talkstations = (
    'talk'          => 'talk-radio', 
    'comedy'        => 'comedy-radio', 
    'community'     => 'community-radio', 
    'educational'   => 'educational-radio', 
    'news'          => 'news-radio',
    'old-time-radio' => 'old-time-radio', 
    'politics'      => 'politics-radio', 
    'spoken-word'   => 'spoken-word-radio', 
    'sports'        => 'sports-radio' 
    );

sub mangleGenres {
 
    my $genre = shift;
    
    $genre = lc ($genre);
    my $origgenre = $genre;
    
    $genre =~ s/ \.\.\. /---/g;    # changes " ... " to hyphens
    $genre =~ s/ 'n' /-n'-/g;      # changes " 'n' " to hyphens
    $genre =~ s/r&b/rnb/g;         # changes "R&B" to "rnb"
    $genre =~ s/'s/s/g;            # changes "'s" top "s" as in 90's to 90s
    $genre =~ s/ /-/g;             # changes spaces to hyphens
    $genre =~ s/\//-/g;            # Change slash to hyphen

# Exception for 'talk' stations which are not 'music'
    if (exists($talkstations{$genre})) {
       $genre = $talkstations{$genre};
    } else {
       $genre = $genre . '-music-radio' ;
    }

# Example URL for "Blues"
# Old pre june 2024 https://live365.com/_next/data/n9L2JMs69gvuJxCm1bEnR/listen/blues-music-radio.json?category=blues-music-radio
#    return "https://live365.com/_next/data/$buildId/listen/$genre.json?category=$genre";

# Now end June 2024
#    https://live365.com/listen/blues-music-radio?_data=routes%2Flisten.%24category
#    https://live365.com/listen/blues-music-radio?_data=routes/listen.$category
    #return 'https://live365.com/listen/'. $genre . '?_data=routes%2F%28%24lang%29.listen.$category' ;
    return 'https://live365.com/listen/'. $genre . '.data' ;	# path routes/($lang).listen.$category
}

sub parseTopGenresReply {
	my $http = shift;
	my $url  = shift;
	
	my 	$jsondata = eval { from_json($http) };
	if ($@) {
		$log->error("Error parsing JSON data $@");
		return;
	}

	# routes/($lang).listen.$category

#	$log->error("Genres JSON \n".Dumper(\$jsondata));
	
	my $topgenres = $jsondata;
	my @menu;
	foreach my $topgenre (@{$topgenres}) {
        
        my $topId      = $topgenre->{'id'};  
        my $topName    = $topgenre->{'name'};
        my $topIcon    = $topgenre->{'image'};
        my $topUrlName = mangleGenres($topName); 
        
        my $subgenres  = $topgenre->{'sub-genres'};
        
        my @submenu;
        
        push @submenu,  {
                'name'	      => 'All',
                'url'         => '', 
                'type'        => 'link',	
                'passthrough' => [ {'url' => $topUrlName ,
                                    'codeRef'     => 'getGenresResults'} ],
               } ;

        foreach my $subgenre (@{$subgenres}) {
            my $subId      = $subgenre->{'id'};  
            my $subName    = $subgenre->{'name'};
            my $subUrlName = mangleGenres($subName); 
            
            push @submenu, {
                    'name'	      => $subName,
                    'url'         => '', 
                    'type'        => 'link',
                    'passthrough' => [ {'url' => $subUrlName ,
                                        'codeRef'     => 'getGenresResults'} ],
                }
        }
        
		push @menu, {
			'name'	      => $topName,
            'icon'        => $topIcon,
            'image'       => $topIcon,
			'items'       => \@submenu,
#			'passthrough' => [ {'param' => $topgenre->{'param'}, 
#								'codeRef'     => 'getGenres'} ],
		};
	};
	$log->debug("Genres MENU \n".Dumper(\@menu));
	my @sortedMenu = sort { $a->{'name'} cmp $b->{'name'} } @menu;
	return \@sortedMenu;	
}

sub makeURLsSubmenu {
    
    my $stationDetails  = shift;
    my @submenu;
    
    my %formatorder = ('default' => 4, 'icyHigh' => 3, 'icyLow' => 2, 'hls' => 1);
    
       	foreach my $urlKey (keys %{$stationDetails->{'streamUrl'}}) {
            
          my $sortkey = defined($formatorder{$urlKey}) ? $formatorder{$urlKey}  : 0;

          push @submenu, {
				'name'        => sprintf("%s (%s)",$stationDetails->{'name'}, $urlKey),
				'image'		  => fixuplogo($stationDetails->{'logo'}),
				'icon'		  => fixuplogo($stationDetails->{'logo'}),
				'type'        => 'audio',
				'url'		  => $stationDetails->{'streamUrl'}->{$urlKey},
				'on_select'   => 'play',
				'description' => $stationDetails->{'description'},       
                'sortkey'     => $sortkey,
                }
        }
   	my @sortedMenu = sort { $b->{'sortkey'} <=> $a->{'sortkey'} } @submenu;
    return \@sortedMenu;
}

sub parseGenresResultsReply {
  	my $http = shift;
	my $url  = shift;
    
	my 	$jsondata = eval { from_json($http) };
	if ($@) {
		$log->error("Error parsing JSON data $@");
		return;
	}
	
	$jsondata = derefjsonpath($jsondata,'($lang).listen.$category');

#	$log->info("Genres JSON \n".Dumper(\$jsondata));
	
	my $results = $jsondata->{'allStations'};
	my @menu;
	foreach my $result (@{$results}) {
		my $submenu = makeURLsSubmenu($result);
		$log->debug("submenu \n". Dumper($submenu));

		my $streamUrl;

		if ( exists $result->{'streamUrl'} ){
			if ( ref $result->{'streamUrl'} eq '' ){
				$streamUrl = $result->{'streamUrl'};
			} elsif ( ref $result->{'streamUrl'} eq 'HASH' && exists $result->{'streamUrl'}->{'default'} ){
				$streamUrl = $result->{'streamUrl'}->{'default'};
			} else {
				$log->debug("Could not find stream URL for $result->{'name'}");
			}
		}

		push @menu, {
					'name'        => $result->{'name'},
					'image'		  => fixuplogo($result->{'logo'}),
					'icon'		  => fixuplogo($result->{'logo'}),
					'type'        => 'audio',
					'url'		  => $streamUrl,
					'on_select'   => 'play',
					'description' => $result->{'description'},        
			}
	}
    
	if (scalar @menu == 0) {
		push @menu , {
			'image'		  => undef ,
			'name'	      => 'No matches found',
			'type'        => 'text',	
		} ;
	}	

    return \@menu;
}

sub getHitStreamUrl {
    
    my $stream_urls = shift;
    foreach my $stream (@{$stream_urls}) {
       return $stream->{'high_quality'} if (defined($stream->{'high_quality'})); 
       return $stream->{'low_quality'}  if (defined($stream->{'low_quality'})); 
    }
    return ;
}


sub parseSearchReply {
	my $http = shift;
	my $url  = shift;

#	$log->error("HTTP \n".Dumper(\$http));
	
	my 	$jsondata = eval { from_json($http) };
	if ($@) {
		$log->error("Error parsing JSON data $@");
		return;
	}

	$jsondata = derefjsonpath($jsondata, '($lang).listen.search');

	$log->debug("JSON \n".Dumper(\$jsondata));
    
	my $query        = $jsondata->{'query'};
	my $searchresult = $jsondata->{'searchResult'};
	my $hits         = $searchresult->{'hits'};
	my $nbHits       = $searchresult->{'nbHits'};
	my $nbPages      = $searchresult->{'nbPages'};

	$log->info(' Search query "'. $query .'"  Page no '.$jsondata->{'page'}. ' of '. $nbPages);
	
	my @menu; 
#
#  If page 1 then add an "ALL" entry if more than one page
#
    if (( $jsondata->{'page'} == 1) && ($nbPages > 1)) {
        
        my $live365icon = Plugins::Live365::Plugin->_pluginDataFor('icon');
        
        # my $searchPageUrl = "https://live365.com/listen/search?query=$query&page=$nbPages&_data=routes%2F%28%24lang%29.listen.search";
	my $searchPageUrl = "https://live365.com/listen/search.data?query=$query&page=$nbPages"; # path routes/($lang).listen.search
        push @menu, {
                    'name'	      => "All Search results ($nbHits)",
                    'image'		  => $live365icon,
                    'icon'		  => $live365icon,
                    'url'         => '', 
                    'type'        => 'link',
                    'passthrough' => [ {'url' => $searchPageUrl ,
                                        'codeRef'     => 'getSearchPage'} ],
                };
    }

# Show first 20 results

	foreach my $hit (@$hits) {
        push @menu, {
				'name'        => $hit->{'station-name'},
				'image'		  => fixuplogo($hit->{'logo'}),
				'icon'		  => fixuplogo($hit->{'logo'}),
				'type'        => 'audio',
				'url'		  => getHitStreamUrl($hit->{'stream_urls'}),
				'on_select'   => 'play',
				'description' => $hit->{'description'},        
                };
	}

    
	if (scalar @menu == 0) {
		push @menu , {
			'image'		  => undef ,
			'name'	      => 'No matches found',
			'type'        => 'text',	
		} ;
	}	
	return \@menu;
}

sub getDisplayName { 'PLUGIN_LIVE365' }

sub playerMenu { shift->can('nonSNApps') && $prefs->get('is_app') ? undef : 'RADIO' }

sub derefjsonpath {
	my ($jsondata, $path) = @_;
	
	if ( ref $jsondata eq 'ARRAY' ){
		# In this specific format, index 0 is the map of the top-level keys.
		my $derefdata = resolve_node($jsondata, 0);
		# $log->debug("Converted data ". Dumper(\$derefdata));
		if ( $path ){
			if (  exists($derefdata->{'routes/'.$path}) && exists($derefdata->{'routes/'.$path}->{'data'}) ){
				$jsondata = $derefdata->{'routes/'.$path}->{'data'};
				$log->debug("New jsondata ". Dumper(\$jsondata));
			} else {
				$log->error("Error - not found expected field in dereferenced data");
				return;
			}
		} else {
			return $derefdata;
		}
	}
	
	return $jsondata;
}

sub resolve_node {
    my ($data, $index) = @_;

    # Boundary check for safety
    return undef if $index < 0 || $index >= scalar @$data;
    
    if ( $index == 0 ){
	    # fresh data so clear cache
	    %deref = ();
    } else {
	    # Return the cached result if we've already processed this index
	    # to handle circularity safely
	    return $deref{$index} if exists $deref{$index};
    }

    my $val = $data->[$index];

    # Hash (Map of Pointers)
    # This is the "Dereferencing" step. 
    # Example: {"_1": 2} means key is found at index 1, value at index 2.
    if (ref($val) eq 'HASH') {
        my $node = {};
		$deref{$index} = $node; # Cache the reference before recursing
        while (my ($raw_key, $val_ptr) = each %$val) {
            # Extract index from key (e.g., "_1" -> 1)
            my ($key_ptr) = $raw_key =~ /(\d+)/;
            
            # Key is the string at $data[$key_ptr]
            my $actual_key = $data->[$key_ptr];
            
            # Value is the result of resolving the pointer at $val_ptr
            $node->{$actual_key} = resolve_node($data, $val_ptr);
        }
        return $node;
    }

    # Standard Scalar (String/Number/Boolean)
    # If it's a simple value that isn't a reference, return it.
    return $val if !ref($val);

    # Array (List of Pointers)
    # If it's an array, each element is a pointer to another index.
    if (ref($val) eq 'ARRAY') {
        return [ map { resolve_node($data, $_) } @$val ];
    }

    return $val;
}

1;
