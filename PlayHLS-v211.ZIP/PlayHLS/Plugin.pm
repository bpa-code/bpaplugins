#
# A plugin to enable PlayHLS to be played without other applications
#

use strict;

package Plugins::PlayHLS::Plugin;

use base qw(Slim::Plugin::OPMLBased);

use Slim::Utils::Log;
use Slim::Utils::Prefs;

use Plugins::PlayHLS::HLSPLAY;

# create log categogy before loading other modules
my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.playhls',
	'defaultLevel' => 'ERROR',
	'description'  => getDisplayName(),
});

my $prefs = preferences('plugin.playhls');

use Slim::Utils::Misc;


################################
### Plugin Interface ###########
################################


sub initPlugin 
{
	my $class = shift;

	$log->info("Initialising " . $class->_pluginDataFor('version'));
	
	return 1;
}

sub shutdownPlugin 
{
 return;
}

sub getDisplayName() 
{ 
	return('PLUGIN_PLAYHLS')
}

1;

# Local Variables:
# tab-width:4
# indent-tabs-mode:t
# End:
