package Plugins::PlayHLS::HLSmpeg2;

# Utils for HLS MPEG2 protocol handler
#
# (c) 2019, bpa baltontwo@eircom.net
#
# Released under GPLv2
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

use strict;
use bytes;

use Slim::Utils::Log;

use Data::Dumper;
my $log = logger('plugin.playhls');

my %pid_handler = (
	0x0000 => \&pat_handler,
	0x0001 => \&cat_handler,
	0x0002 => \&tsdt_handler,
	0x0010 => \&nit_handler,
	0x0011 => \&sdt_handler,
#	0x1000 => \&pmt_handler,
	0x1fff => \&null_handler,
	);
	
sub pat_handler {

	my $table         = shift;
	my $table_data    = shift;
	my $payload_size  = shift;
	my $payload_start = shift;

	my $pos = 0;

    $log->info(sprintf("     Payloadstart %02x Payload size %5d Data Length %5d Segment %0*v2X", 
                  $payload_start, $payload_size, length($table_data), " ", substr($table_data,0,32)));

		
	$table->{'table_name'} = "PAT";

	$table->{'table_id'} = ord(substr($table_data,$pos, 1));
	$log->info("Bad table id ". $table->{'table_id'} . " should be zero ") if ($table->{'table_id'} != 0);
	$pos += 1;
	
	my ($byte3, $byte4, $byte5, $byte6, $byte7, $byte8, $byte9) = unpack("CCCCCCC", substr($table_data,$pos, 7));
	$pos += 7;
	$table->{'selection_syntax_indicator'} = $byte3 & 0x80;  # Should be 1 for PAT, PMT, CAT 
	$table->{'private'}                    = $byte3 & 0x40;  # Should be 0 for PAT, PMT, CAT 
	$table->{'reserved2'}                  = ($byte3 & 0x30) >> 4;

	$log->info("Section length top bits not zero ") if ($byte3 & 0x0C) ;
	my $section_length = $byte4 | (($byte3 & 0x07) << 8) ;
	
	$table->{'transport_stream_id'} = ($byte5 << 8) | $byte6 ;

	if (($byte7 & 0xC0) != 0xC0) {
        $log->info(" reserved3 is not 11 ");
	};
    $table->{'version_number'}    = ($byte7 & 0x3E) >> 1 ;
	$table->{'current_indicator'} =  $byte7 & 0x01 ;

    $table->{'section_number'}      = $byte8 ; 
    $table->{'last_section_number'} = $byte9 ; 
    
    $log->info(sprintf("    PAT Section length: %03d table id %d Transport stream id %2d section number %3d lastsection number %3d",
          $section_length, $table->{'table_id'}, $table->{'transport_stream_id'}, $table->{'section_number'}, $table->{'last_section_number'} ));
    
    my @programs = ();
    for (my $i = 0; $i < ($section_length -5 -4)/4; $i++) {
		
		$log->info(sprintf("   Section %0*v2X", " ", substr($table_data,$pos,32)));

		my ($program_num, $b1, $b2) = unpack("nCC", substr($table_data,$pos, 4)) ;
		$log->debug(sprintf("pos %3d program num %04X  B1 %02X  B2 %02x ",$pos, $program_num, $b1, $b2 ));
		
		$pos +=4;
		
        if (($b1 & 0xE0) != 0xE0) {
            $log->info(" reserved is not 111 n" );
        };

        my $program_pid = $b2 | (($b1 & 0x1F) << 8) ;

        push @programs, {'program_num' => $program_num, 'program_pid' => $program_pid };
        $log->info(sprintf("     Program Num %3d  Program PID %04X ", $program_num,  $program_pid ));
        $pid_handler{$program_pid} = \&pmt_handler;
		
	}
    $table->{'programs'} = @programs;
    
    $pos += 4;  # Skip CRC32
    
    if ($pos < length($table_data)) {
		$table->{'remainder'} = substr($table_data, $pos);
	} ;
  return \$table;	
}

# PMT - Transport Stream Map Section ( Byte 1 @ offset 0,  byte 10 @ offset 9)
#  Bytes 1       - Table_id
#  Bytes 2 & 3   - section length - bottom 12 bits, top bit section syntax indicator
#  Bytes 4 & 5   - Program Number
#  Byte  6       - Version Number, current next indicator  & reserved
#  Byte  7       - Section Number
#  Byte  8       - Last Section Number
#  Byte  9 & 10 - PCR PID - bottom 13 bits
#  Byte 11 & 12 - Program Info length - bottom 12 bits
#
#  N *  descriptors which "describe" Program "Program Number" 
#    - each descriptor Byte  1 - Tag
#                      Byte  2   8 bit Length, 
#                      Bytes 3 -> followed by "length" bytes of descriptor.
#                      Total length of descriptos is Program_info_length
#
#  N *  streams info (N = number of elementary streams in Program), 
#  Each stream  Byte  1       - Stream id, 
#               Byte  2 & 3   - Elementary pid (bottom 13 bits),
#               bytes 4 & 5   - ES info length (bottom 12 bits)
#               N2 * ES descriptors (total length ES info length)
#                    ES Descriptor Byte  1 Tag
#                    ES Descriptor Byte  2 8 bit Length, 
#                    ES Descriptor Bytes 3 ->  followed by "length" bytes of descriptor.
#

sub pmt_handler {

	my $table         = shift;
	my $table_data    = shift;
	my $payload_size  = shift;
	my $payload_start = shift;
	my $pes_pids	  = shift;

	my $pos = 0;

#	$log->info("PMT handler called ");
#    $log->info(sprintf("Payloadstart %02x Payload size %5d Data Length %5d Segment %0*v2X", $payload_start, $payload_size, length($table_data), " ", substr($table_data,0,32)));
		
	$table->{'table_name'} = "PMT";
	$table->{'table_id'} = ord(substr($table_data,$pos, 1));
	$log->debug("Bad table id ". $table->{'table_id'} . " should not be 2 ") if ($table->{'table_id'} != 2);

	$pos += 1;
	
	my ($byte3, $byte4, $byte5, $byte6, $byte7, $byte8, $byte9, $byte10, $byte11, $byte12, $byte13) = unpack("CCCCCCCCCCC", substr($table_data,$pos, 11));
	$table->{'selection_syntax_indicator'} = $byte3 & 0x80;  # Should be 1 for PAT, PMT, CAT 
	$table->{'private'}                    = $byte3 & 0x40;  # Should be 0 for PAT, PMT, CAT 
	$table->{'reserved2'}                  = ($byte3 & 0x30) >> 4;

	$log->info("     PMT Section length top bits not zero ") if ($byte3 & 0x0C) ;
	my $section_length = $byte4 | (($byte3 & 0x07) << 8) ;
	
	my $table_end = 3 + $section_length - 4 ;  # 3 = table id (1byte)  length (2 bytes) and 4 bytes for CRC32
	$table->{'program_num'}         = ($byte5 << 8) | $byte6 ;

	if (($byte7 & 0xC0) != 0xC0) {
        $log->info(" reserved3 is not 11 ");
	};
    $table->{'version_number'}      = ($byte7 & 0x3E) >> 1 ;
	$table->{'current_indicator'}   =  $byte7 & 0x01 ;

    $table->{'section_length'}      = $section_length ; 
    $table->{'section_number'}      = $byte8 ; 
    $table->{'last_section_number'} = $byte9 ; 

    $table->{'pcr_pid'}     = $byte11 | (($byte10 & 0x1f) << 8) ;
    my $program_info_length = $byte13 | (($byte12 & 0x0f) << 8) ;
    $table->{'program_info_length'} = $program_info_length;

    $log->info(sprintf("    PMT Section length: %03d table id %d PCR pid %04x Program num: %3d Program info length %d ",
          $section_length, $table->{'table_id'}, $table->{'pcr_pid'}, $table->{'program_num'}, $program_info_length)) ;

	$pos += 11;

#   
#  Process the program info descriptors    
#
    my $prog_info_descriptors = substr($table_data,$pos, $program_info_length);
    
    for (my $j = 0; $j < $program_info_length; ) {

		my $tag      = ord(substr($prog_info_descriptors,$j,1));
		my $len_desc = ord(substr($prog_info_descriptors,$j+1,1));
		my $desc     =     substr($prog_info_descriptors,$j+2,$len_desc);
		push @{ $table->{'program_info_descriptors'}}, { $tag => $desc } ;
		$j +=	4 + $len_desc;
	} ;
	
	$pos += $program_info_length;

#
# Process the streams 
# 
	for (my $j = $pos; $j < $table_end ; ) {
		my ($stream_type, $elementary_pid, $es_info_length ) = unpack("Cnn", substr($table_data, $j, 5));
		
		$elementary_pid &= 0x1fff ; # just bottom 13 bits
		$es_info_length &= 0x0fff ; # just bottom 12 bits
		$pos += 5;
		$log->info(sprintf("Pid %04x ( %5d )  ES Info Length %5d pos %3d table end %3d ",
                             $elementary_pid, $elementary_pid, $es_info_length, $pos, $table_end ));
		my $es_info_descriptors = substr($table_data,$j+5, $es_info_length);
		
		my @es_descriptors;
		for (my $k = 0 ; $k < $es_info_length; )  {
			my $tag      = ord(substr($es_info_descriptors,$k,1));
			my $len_desc = ord(substr($es_info_descriptors,$k+1,1));
			my $desc     =     substr($es_info_descriptors,$k+2,$len_desc);
			$log->info(sprintf("ESInfo descr %3d %3d Tag %02x len %02x  Data %0*v2X      Raw %0*v2X", 
                                        $k,$es_info_length ,$tag, $len_desc, " ", $desc, " ",$es_info_descriptors));
		
			push @es_descriptors, { $tag => $desc } ;
			$k += 2 + $len_desc;
		}
		push @{$table->{'streams'}} , { 'elementary_pid' => $elementary_pid,
										'stream_type'    => $stream_type,
										'es_descriptors' => [ @es_descriptors ],
										'es_info_length' => $es_info_length,
									   };
									
		$pes_pids->{ $elementary_pid}{'stream_type'} = $stream_type ;
		$j += 5 + $es_info_length ;
		$log->info(sprintf("End ES loop: j=%d tableend=%d ", $j, $table_end));
		
	}

#
#  Check section length andprogram_info length at end.
#
#  
    $pos += 4;  # Skip CRC32
#    $log->info("Finished packet processing pos $pos and table length  ". length($table_data) );
    
    if ($pos < length($table_data)) {
		$table->{'remainder'} = substr($table_data, $pos);
		$table->{'remainder_length'} = length($table->{'remainder'} );
	} 
  return \$table;	  
  return undef;	
}



sub cat_handler {
  $log->error("cat handler called ");
  return undef;	
}

sub tsdt_handler {
  $log->error("tsdt handler called ");
  return undef;	
}

sub nit_handler {
  $log->error("nit handler called ");
  return undef;	
}

sub sdt_handler {
  $log->info("sdt handler called ");
  return undef;	
}



sub null_handler {
  $log->info("null handler called ");
  
  	my $table         = shift;
	my $table_data    = shift;
	my $payload_size  = shift;
	my $payload_start = shift;
		
	$table->{'table_name'} = "Null";
  
  return undef;	
} 

sub pes_pid_handler {

	my $table         = shift;
	my $table_data    = shift;
	my $payload_size  = shift;
	my $payload_start = shift;
	
	my $pos = 0;
		
	$table->{'table_name'} = "Program PID";
	$table->{'pointer_field'} = 0;
	
	if ($payload_start) {
		$table->{'pointer_field'} = ord(substr($table_data,$pos, 1));
		$log->info(" Non zero pointer field ". $table->{'pointer_field'} ) if ( $table->{'pointer_field'} != 0);
		$pos += 1;
	}


}

# The PCR field is a 42 bit field in the adaptation field of the Transport Stream. 
# The PCR field consists of a 9 bit part that increments at a 27MHz rate 
# and a 33 bit part that increments at a 90kHz rate (when the 27MHz part rolls over)
sub process_pcr {
	
	my $pcr_data = shift ; # Program clock reference, stored as 33 bits base, 6 bits reserved, 9 bits extension.
                           # The value is calculated as base * 300 + extension.
	
	my ( $pcr_byte1, $pcr_byte2, $pcr_byte3, $pcr_byte4, $pcr_byte5, $pcr_byte6) = unpack("CCCCCC",$pcr_data);
	
	my $base =	($pcr_byte1 << (1+ 24)) +  
				($pcr_byte2 << (1+ 16)) +  
				($pcr_byte3 << (1+  8)) +  
				($pcr_byte4 << (1+  0)) +  
				($pcr_byte5 >> 7) ;

	my $ext = (($pcr_byte5 & 0x01) << 8) + $pcr_byte6 ;
	my $pcrtime = $base / 90000.0 + $ext / 27000000.0 ;

	return $pcrtime
}

sub process_adaptation {
	
	my $adaptation = shift;
	my $adapt_data = shift;
	my $additional_length = shift;
	my $pos = 0;
	
	my $flags = ord(substr($adapt_data,$pos,1));

    $adaptation->{'discontinuity'}              = ($flags & 0x80) ;
    $adaptation->{'random_access'}              = ($flags & 0x40) ;
    $adaptation->{'elementary_stream_priority'} = ($flags & 0x20) ; 
    $adaptation->{'pcr'}                        = ($flags & 0x10) ;
    $adaptation->{'opcr'}                       = ($flags & 0x08) ;
    $adaptation->{'splicing_point'}             = ($flags & 0x04) ;
    $adaptation->{'transport_private'}          = ($flags & 0x02) ;
    $adaptation->{'adaptation_field_extension'} = ($flags & 0x01) ;
    
    $pos = 1;
    $additional_length -= 2;   # Processed flags & size 

   if ($adaptation->{'pcr'} ) {
	   $log->info(sprintf("Processing pcr :   Flags %02x  additional length %3d pos %3d ",$flags,$additional_length,$pos));
        if ($additional_length >= 6 ) {
            $additional_length -= 6 ; 
            $pos += 6;
            $adaptation->{'program_clock_reference'} = process_pcr(substr($adapt_data,$pos,6)) ;
         }
    } ;
    
   if ($adaptation->{'opcr'} ) { 
#	   $log->info(sprintf("Processing opcr :  Flags %02x  additional length %3d pos %3d",$flags,$additional_length, $pos));
        if ($additional_length >= 6 ) {
            $additional_length -= 6 ; 
            $pos += 6 ;
            $adaptation->{'original_program_clock_reference'} = process_pcr(substr($adapt_data,$pos,6)) ;
        } ;
   } ;

   if ($adaptation->{'splicing_point'} ) {
        if ($additional_length >= 1) {
            $additional_length -= 1 ;
            $pos += 1 ;
            $adaptation->{'splice_count'}  = ord(substr($adapt_data,$pos,1));
        }
    }
    
    if ($additional_length > 0 ) {
            $adaptation->{'ignored_adaptation_data'} = substr($adapt_data,$pos,$additional_length);
	}
	
}
#
#  Scan just looks for foirst PMT and returns the stream ES data - callgin routine will pick the PID to use
#
sub ScanMPEG2chunk {
	my $segment = shift;
	
	my $segmentsize = length($segment);
	my @tspackets;
	my %pes_pids;

# Sanity check - chunk should be multiple of 188 (TS packet size)
	
	if (($segmentsize % 188) != 0) {
		$log->info(" xxLength of file $segmentsize is not a mulitple of 188 " );
		return undef;
	}
	
	my $curpos    = 0;
	my $packetnum = 0;
	
# Sanity check 	- quick check to see iof synnc bytes are in first 3 packets - PAT, PMT and first PES .
	 if ((substr($segment, $curpos,       1) eq "\x47") && 
	     (substr($segment, $curpos + 188, 1) eq "\x47") &&
	     (substr($segment, $curpos + 376, 1) eq "\x47") )  {
			$log->info("First 3 packets have sync bytes - looks ok ");
	} else {
			$log->info("First 3 packets headers do not have sync bytes - looks wrong ");
			$log->info(sprintf("Packet 1  %0*v2X", " ", substr($segment,$curpos,       32)));
	}
	
SEARCH:	while (($curpos < $segmentsize)  && (!keys (%pes_pids) )) {   # loop while no PES pids found
		
		my %tspacket = ();
		$packetnum += 1;
		
		my $payload_size = 188;
		$log->info(sprintf(   "Packet %02d Pos: %3d  %0*v2X", $packetnum, $curpos," ", substr($segment,$curpos,       32)));
		
		if ( substr($segment, $curpos,1) ne "\x47") {
			$log->info("sYNC BYTE NOT FOUND - ERROR ");
			return undef;
		} ;

		
		my ($head1, $head2, $head3) = unpack("CCC", substr($segment, $curpos+1,3)) ;
		$tspacket{'packet No' }         = $packetnum;
		$tspacket{'transport_error' }   = $head1 & 0x80;
		$tspacket{'payload_unit_start'} = $head1 & 0x40;
		$tspacket{'transport_piority'}  = $head1 & 0x20;
		$tspacket{'pid'}                = $head2 | (($head1 & 0x1F ) << 8);
		$tspacket{'scrambling'}         = (($head3  & 0xC0) >> 6) ;
        $tspacket{'have_adaptation_field'} = $head3 & 0x20;
        $tspacket{'have_payload'}       = $head3 & 0x10 ;
        $tspacket{'continuity_counter'} = $head3 & 0x0F ;

        $tspacket{'adaptation_field_size'} = 0;
        $curpos += 4;
        $payload_size -= 4 ;
         
        if ($tspacket{'have_adaptation_field'} ) {
			my $additional_length = ord(substr($segment,$curpos,1));
			if ( $additional_length == 0 ) {
				$tspacket{'adaptation_field_size'} = 0;
			} else {
				my %adaptation;
				$tspacket{'adaptation_field_size'} = $additional_length ;
				process_adaptation(\%adaptation, substr($segment,$curpos+1,$additional_length-1),$additional_length);
				$tspacket{'adaptation'} = \%adaptation;
			} ;
			$curpos       += $tspacket{'adaptation_field_size'} +1;
			$payload_size -= $tspacket{'adaptation_field_size'} +1 ;
		}
 
        if ( defined($pid_handler{$tspacket{'pid'}})) {
			my %piddata ;
			if ($tspacket{'payload_unit_start'} ) {
				$tspacket{'pointer'}  = ord(substr($segment,$curpos,1));
				$curpos += 1 + $tspacket{'pointer'};
				$payload_size -= 1 + $tspacket{'pointer'} ;
				$log->info(sprintf("*** Non zero Pointer fields %3d ", $tspacket{'pointer'})) if ( $tspacket{'pointer'} );
			}

			$pid_handler{$tspacket{'pid'}} (\%piddata,substr($segment,$curpos,$payload_size), $payload_size, $tspacket{'payload_unit_start'},\%pes_pids) ;
			
			if (exists($piddata{'table_name'})) {
				$tspacket{$piddata{'table_name'}} = \%piddata;
			};
			
		} else {
			$log->info(" Packet No:. $packetnum  No handler defined for pid ".$tspacket{'pid'});
			$log->debug("      TS header dump ". Dumper(\%tspacket) ) ;
			$log->info(sprintf("     Packet  %0*v2X", " ", substr($segment,$curpos, 32)));
			$curpos += $payload_size  ;
			next SEARCH;
		} ; 
		push  @tspackets,\%tspacket;  # Add the packet to the array of TS packets in the chunk
		$curpos += $payload_size  ;
	} ; 

 #  return found Pes PIDs

  return \%pes_pids;
}


sub ParseMPEG2chunk {
	
	my ( $segment, $audio_pid, $metadata_pid )  = @_;
	
	my $segmentsize = length($segment);
	my @tspackets;
	my %pes_pids;
	
	my $audiodata = '';
	
#	$log->error(" Audio pid $audio_pid");
	if ($audio_pid != -1) {
		$pes_pids{$audio_pid}{'stream_type'} = 0x0f;
	}
	
# Sanity check - chunk should be multiple of 188 (TS packet size)
	
	if (($segmentsize % 188) != 0) {
		$log->info(" Length of file $segmentsize is not a mulitple of 188 " );
		return undef;
	}
	
	my $curpos    = 0;
	my $packetnum = 0;
# Sanity check 	- quick check to see iof synnc bytes are in first 3 packets - PAT, PMT and first PES .
	 if ((substr($segment, $curpos,       1) eq "\x47") && 
	     (substr($segment, $curpos + 188, 1) eq "\x47") &&
	     (substr($segment, $curpos + 376, 1) eq "\x47") )  {
			$log->info("First 3 packets have sync bytes - looks ok ");
	} else {
			$log->info("First 3 packets headers do not have sync bytes - looks wrong ");
			$log->info(sprintf("Packet 1  %0*v2X", " ", substr($segment,$curpos,       32)));
	}
	
PACKET:	while ($curpos < $segmentsize) {
		
		my %tspacket = ();
		$packetnum += 1;
		
		my $payload_size = 188;
		$log->info(sprintf(   "Packet %02d Pos: %3d  %0*v2X", $packetnum, $curpos," ", substr($segment,$curpos,       32)));
		
		if ( substr($segment, $curpos,1) ne "\x47") {
			$log->info("sYNC BYTE NOT FOUND - ERROR ");
			return undef;
		} ;

		
		my ($head1, $head2, $head3) = unpack("CCC", substr($segment, $curpos+1,3)) ;
		$tspacket{'packet No' }         = $packetnum;
		$tspacket{'transport_error' }   = $head1 & 0x80;
		$tspacket{'payload_unit_start'} = $head1 & 0x40;
		$tspacket{'transport_piority'}  = $head1 & 0x20;
		$tspacket{'pid'}                = $head2 | (($head1 & 0x1F ) << 8);
		$tspacket{'scrambling'}         = (($head3  & 0xC0) >> 6) ;
        $tspacket{'have_adaptation_field'} = $head3 & 0x20;
        $tspacket{'have_payload'}       = $head3 & 0x10 ;
        $tspacket{'continuity_counter'} = $head3 & 0x0F ;

        $tspacket{'adaptation_field_size'} = 0;
        $curpos += 4;
        $payload_size -= 4 ;
        
		if ( $tspacket{'pid'} == $metadata_pid ) {
			$log->info( sprintf( "Metadata PID %3d ( %02x ) in stream. Packenet %d",  $tspacket{'pid'}, $tspacket{'pid'}, $packetnum));
			$log->debug("      TS header dump ". Dumper(\%tspacket) ) ;
			$log->debug(sprintf("     Packet  %0*v2X", " ", substr($segment,$curpos, 32)));
        }
      
        if ($tspacket{'have_adaptation_field'} ) {
			my $additional_length = ord(substr($segment,$curpos,1));
			if ( $additional_length == 0 ) {
				$tspacket{'adaptation_field_size'} = 0;
			} else {
				my %adaptation;
				$tspacket{'adaptation_field_size'} = $additional_length ;
				process_adaptation(\%adaptation, substr($segment,$curpos+1,$additional_length-1),$additional_length);
				$tspacket{'adaptation'} = \%adaptation;
			} ;
			$curpos       += $tspacket{'adaptation_field_size'} +1;
			$payload_size -= $tspacket{'adaptation_field_size'} +1 ;
		}
 
        if ( defined($pid_handler{$tspacket{'pid'}})) {
			my %piddata ;

			if ($tspacket{'payload_unit_start'} ) {
				$tspacket{'pointer'}  = ord(substr($segment,$curpos,1));
				$curpos += 1 + $tspacket{'pointer'};
				$payload_size -= 1 + $tspacket{'pointer'} ;
				$log->info(sprintf("*** Non zero Pointer fields %3d ", $tspacket{'pointer'})) if ( $tspacket{'pointer'} );
			}

			$pid_handler{$tspacket{'pid'}} (\%piddata,substr($segment,$curpos,$payload_size), $payload_size, $tspacket{'payload_unit_start'},\%pes_pids) ;
			if (exists($piddata{'table_name'})) {
				$tspacket{$piddata{'table_name'}} = \%piddata;
			} ;
		} elsif ( defined($pes_pids{$tspacket{'pid'}} ))  {
			

#  Found a packet with a PES PD
			if ($tspacket{'payload_unit_start'}) {
#
#				Process PES header
#
				$log->info(sprintf("*** Missing PES prefix   %0*v2X", " ", substr($segment,$curpos,3))) if ( substr($segment,$curpos,3) ne "\x00\x00\x01") ;
				my $pes_pid = $tspacket{'pid'} ;
				$pes_pids{$pes_pid}{'pes_stream_type'} = ord(substr($segment,$curpos+3,1)) ;
#
#  MPEG PES Stream Id audio is 0xC0 to 0xDF.   For HLS it is alwasy 0xC0
#
				if ($pes_pids{$pes_pid}{'pes_stream_type'}  != 0xC0 ) {
					$log->info(sprintf("***  Stream type for pes %d is not audio  Stream Id= %02x  Stream_type %02x", $pes_pid, $pes_pids{$pes_pid}{'pes_stream_type'}, $pes_pids{$pes_pid}{'stream_type'}));
				} else {
					$log->info(sprintf("Pkt No: %4d Stream type for pes %d is Audio - normal   stream_type %02x", $packetnum, $pes_pid,  $pes_pids{$pes_pid}{'stream_type'}));
					if ($tspacket{'pid'} != $audio_pid) {
						$log->error(sprintf(" Unexpected Audio PID %03d (%02x) found in packet no:. %d", $tspacket{'pid'}, $tspacket{'pid'}, $packetnum));
						$log->error("      TS header dump ". Dumper(\%tspacket) ) ;
						$log->error(sprintf("     Packet  %0*v2X", " ", substr($segment,$curpos, 32)));
					}
				};

				$pes_pids{$pes_pid}{'pes_length'}                 = unpack "n",  substr($segment,$curpos+4,2);
				my ($pes_bytes1, $pes_bytes2, $pes_header_length) = unpack "CCC",substr($segment,$curpos+6,3);

				my %pes_flags;
				$pes_flags{'must_be_one_true'}   = $pes_bytes1 & 0x80 ;
				$pes_flags{'must_be_zero_false'} = $pes_bytes1 & 0x40 ;
				$pes_flags{'scrambling_control'} = $pes_bytes1 & 0x30 ;
				$pes_flags{'pes_priority'}       = $pes_bytes1 & 0x08 ;
				$pes_flags{'data_alignment_ind'} = $pes_bytes1 & 0x04 ;
				$pes_flags{'copyright'}          = $pes_bytes1 & 0x02 ;
				$pes_flags{'original_or_copy'}   = $pes_bytes1 & 0x01 ;
				
				$pes_flags{'pts_flag'}           = $pes_bytes2 & 0x80 ;
				$pes_flags{'dts_flag'}           = $pes_bytes2 & 0x40 ;
				$pes_flags{'escr_flag'}          = $pes_bytes2 & 0x20 ;
				$pes_flags{'es_flag_rate'}       = $pes_bytes2 & 0x10 ;
				$pes_flags{'dsm_trick_mode'}     = $pes_bytes2 & 0x08 ;
				$pes_flags{'additional_copy_info'} = $pes_bytes2 & 0x04 ;
				$pes_flags{'crc_flag'}           = $pes_bytes2 & 0x02 ;
				$pes_flags{'extension_flag'}     = $pes_bytes2 & 0x01 ;
				
				$pes_pids{$pes_pid}{'flags'} = %pes_flags;
				$pes_pids{$pes_pid}{'pes_header_length'} = $pes_header_length ;
				$log->info(sprintf("PES   length %5d  pes header length %3d", $pes_pids{$pes_pid}{'pes_length'}, $pes_header_length));
				$curpos       += 9 + $pes_header_length;
				$payload_size -= 9 + $pes_header_length;

#
#  Return viable audio stream type  - it is then up to players decoders.  Long delays can be due to low bit rates / buffer threshold setting too large.
#      ADTS/AAC = 0x0f
#      MP3      = 0x03
#      MP3      = 0x04 - halved sample rate  - mono?
#
		
				if ($tspacket{'have_payload'}) {
					if (	$pes_pids{$pes_pid}{'stream_type'} == 0x0f ||
							$pes_pids{$pes_pid}{'stream_type'} == 0x03 ||
							$pes_pids{$pes_pid}{'stream_type'} == 0x04   ) {

						$log->info(" Packet No: $packetnum   - add $payload_size bytes of audio type ". $pes_pids{$pes_pid}{'stream_type'}); 
						$log->info(sprintf("    PUSI Audio %4d bytes of audio data  %0*v2X", $payload_size, " ", substr($segment,$curpos,$payload_size) ));
						$audiodata .= substr($segment,$curpos,$payload_size)  ;
						$pes_pids{$pes_pid}{'count'} = $payload_size;
					} else {
						$log->info(sprintf("    Dropping non-Audio type %02x   %4d bytes of audio data  %0*v2X", $pes_pids{$pes_pid}{'stream_type'}, $payload_size, " ", substr($segment,$curpos,32) ));
					};	
				}
			} else {
				my $pes_pid = $tspacket{'pid'} ;
				if ($tspacket{'have_payload'}) {
					if (	$pes_pids{$pes_pid}{'stream_type'} == 0x0f ||
							$pes_pids{$pes_pid}{'stream_type'} == 0x03 ||
							$pes_pids{$pes_pid}{'stream_type'} == 0x04    ) {
						$log->info(sprintf("    Audio %4d bytes of audio data  %0*v2X", $payload_size, " ", substr($segment,$curpos,$payload_size) ));
						$audiodata .= substr($segment,$curpos,$payload_size)  ;
					} else {
						$log->info(sprintf("    Dropping non-Audio type %02x   %4d bytes of audio data  %0*v2X", $pes_pids{$pes_pid}{'stream_type'}, $payload_size, " ", substr($segment,$curpos,32) ));
					};
				}
			}
		} else {
			$log->info(" Packet No:. $packetnum  No handler defined for pid ".$tspacket{'pid'});
			$log->debug("      TS header dump ". Dumper(\%tspacket) ) ;
			$log->info(sprintf("     Packet  %0*v2X", " ", substr($segment,$curpos, 32)));
			$curpos += $payload_size  ;
			next PACKET;
		} ; 

		push  @tspackets,\%tspacket;  # Add the packet to the array of TS packets in the chunk
		$curpos += $payload_size  ;
	} ; 

#  Return the audio data.
  $log->debug(" Returning ".length($audiodata). " bytes audio");
  return \$audiodata;
}
	
1;
