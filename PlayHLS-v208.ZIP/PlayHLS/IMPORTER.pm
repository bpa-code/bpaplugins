package Plugins::PlayHLS::IMPORTER;

#
#  IMPORTER module only called by scanner and defined in install.xml
#

use strict;

use Slim::Utils::Log;

my $log = logger('plugin.playhls');

#
#  HLS m3u and m3um3u8 are parsed by HLSPLAY routines in LMS when playing remote streams.  
#  When scanning,  m3u & m3u8 playlist files can be parsed by LMS default as they can't be HLS.
#
#  m3um3u8 type is defined in custom-convert.conf and a parser for type has to be registered in Scanner as well as LMS.

my $playlistClass = $Slim::Formats::tagClasses{'m3u'};
   Slim::Formats::Playlists->registerParser('m3um3u8', $playlistClass);

   $log->info(" registered m3um3u8 type with  playlist class set to $playlistClass");

1;
