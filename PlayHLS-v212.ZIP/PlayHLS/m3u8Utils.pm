package Plugins::PlayHLS::m3u8Utils;

use strict;
use bytes;

use URI::Split;
use Data::Dumper;

use Slim::Utils::Errno;
use Slim::Utils::Log;

my $log = logger('plugin.playhls');

use constant TRUE   => 1;
use constant FALSE  => 0;

sub tidym3u8body {
	
	my $body = shift;
#
#  Clean up the media playlist - various sources have "oddities"
#

	my @lines;
	foreach my $rawline (split /\n/ ,$body) {
        $rawline =~ s/\cM//g;  
# 		strip whitespace from beginning and end
#       $rawline =~ s/^\s*//; 
#       $rawline =~ s/\s*$//; 

		$rawline =~ s/^\s+|\s+$//g ;
        next if $rawline eq '';        

		push @lines, $rawline;
	}
	return @lines;
}

sub  trim_m3u8 { my $s = shift; $s =~ s/^\s+|\s+$//g; return $s };

sub test_unzip_m3u8 {
    
    my $playlist = shift;
    
    

    if (index ($playlist, '#EXTM3U') < 0 ) {
		$log->info("No EXTM3U in playlist - so check if zipped ");	
		$log->debug("First line not EXTM3U\n ". sprintf ("%0*v2X\n", "  ", substr($playlist,0,16)));

        if (!Slim::Utils::Compress::hasZlib() ) {
            $log->error(" No support for decompressing zipped M3U8 playlist - Compress::Zlib");
            return;   
        }
        
		my $output = Plugins::PlayHLS::m3u8Utils::unzip_m3u8($playlist);
		if (index ($output, '#EXTM3U') < 0 ) {
			$log->error(" Error in unzipping ");
			return;
		} 
        $playlist = $output
    };    
    return $playlist;   
}

# Copied from LMS unzip routine. Hope to remove after move away from AnyEvent https

sub unzip_m3u8 {
	
	my $contents = shift;

	my ($x, $status) = Compress::Raw::Zlib::Inflate->new( {
		-WindowBits => -Compress::Raw::Zlib::MAX_WBITS(),
	} );
		
	removeGzipHeader_m3u8( \$contents );
	my $output = '';
	$status = $x->inflate( $contents, $output );
	return $output;
}

# From Compress::Zlib, to avoid having to include all
# of new Compress::Zlib and IO::* compress modules
sub removeGzipHeader_m3u8($)
{
    my $string = shift ;

    return Compress::Raw::Zlib::Z_DATA_ERROR()
        if length($$string) < IO::Compress::Gzip::Constants::GZIP_MIN_HEADER_SIZE();

    my ($magic1, $magic2, $method, $flags, $time, $xflags, $oscode) =
        unpack ('CCCCVCC', $$string);

    return Compress::Raw::Zlib::Z_DATA_ERROR()
        unless $magic1 == IO::Compress::Gzip::Constants::GZIP_ID1() and $magic2 == IO::Compress::Gzip::Constants::GZIP_ID2() and
           $method == Compress::Raw::Zlib::Z_DEFLATED() and !($flags & IO::Compress::Gzip::Constants::GZIP_FLG_RESERVED()) ;
    substr($$string, 0, IO::Compress::Gzip::Constants::GZIP_MIN_HEADER_SIZE()) = '' ;

    # skip extra field
    if ($flags & IO::Compress::Gzip::Constants::GZIP_FLG_FEXTRA())
    {
        return Compress::Raw::Zlib::Z_DATA_ERROR()
            if length($$string) < IO::Compress::Gzip::Constants::GZIP_FEXTRA_HEADER_SIZE();

        my ($extra_len) = unpack ('v', $$string);
        $extra_len += IO::Compress::Gzip::Constants::GZIP_FEXTRA_HEADER_SIZE();
        return Compress::Raw::Zlib::Z_DATA_ERROR()
            if length($$string) < $extra_len ;

        substr($$string, 0, $extra_len) = '';
    }

    # skip orig name
    if ($flags & IO::Compress::Gzip::Constants::GZIP_FLG_FNAME())
    {
        my $name_end = index ($$string, IO::Compress::Gzip::Constants::GZIP_NULL_BYTE());
        return Compress::Raw::Zlib::Z_DATA_ERROR()
           if $name_end == -1 ;
        substr($$string, 0, $name_end + 1) =  '';
    }

    # skip comment
    if ($flags & IO::Compress::Gzip::Constants::GZIP_FLG_FCOMMENT())
    {
        my $comment_end = index ($$string, IO::Compress::Gzip::Constants::GZIP_NULL_BYTE());
        return Compress::Raw::Zlib::Z_DATA_ERROR()
            if $comment_end == -1 ;
        substr($$string, 0, $comment_end + 1) = '';
    }

    # skip header crc
    if ($flags & IO::Compress::Gzip::Constants::GZIP_FLG_FHCRC())
    {
        return Compress::Raw::Zlib::Z_DATA_ERROR()
            if length ($$string) < IO::Compress::Gzip::Constants::GZIP_FHCRC_SIZE();
        substr($$string, 0, IO::Compress::Gzip::Constants::GZIP_FHCRC_SIZE()) = '';
    }

    return Compress::Raw::Zlib::Z_OK();
}

1;
