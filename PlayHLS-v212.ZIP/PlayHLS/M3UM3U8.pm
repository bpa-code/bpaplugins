package Plugins::PlayHLS::M3UM3U8;

use strict;
use base qw(Slim::Formats::Playlists::Base);

#use URI;

#use Slim::Music::Info;
#use Slim::Utils::Misc;
#use Slim::Utils::Prefs;
use Slim::Utils::Log;

my $log = logger('plugin.playhls');

#
#  Problem - HLS remote streams can have same MIME and extension as normal streams.
#  so inital playlist has to be check for extended directive of the type #EXT-X...
#
#  Checking for #EXTM3U is not enough as LMS creates playlist with this directive
#
#  HLS playlist have #EXT-X directive. 
#  
#  so the read routine - reads the playist. check for EXT-X - and then resets file pointer and call M3U or HLS playlist processing.
#
#  In theory this handler should also have readCurTrackForM3U and writeCurTrackForM3U routines 
#  but LMS Commands.pm calls them directly in Slim::Formats::Playlists::M3U and not via a $playlistref registered parser.
#


sub read {
    my ($class, $file, $baseDir, $url) = @_;
    my @items  = ();
    my @lines;
    my $startpos;
    
    $log->info("parsing M3U/M3U8 ambiguous playlist: $url");
    
#  Save the filehandle position.
	my $curpos = tell($file);
	my $ext_x_seen = 0;
	
#  Read the playlist - if it contains a #EXT-X
    
    while (defined($file) && (my $entry = <$file>) && ($ext_x_seen == 0)) {
		
        chomp($entry);
        $entry =~ s/\cM//g;  

        # strip whitespace from beginning and end
        $entry =~ s/^\s*//; 
        $entry =~ s/\s*$//; 
		if ($entry =~ /^#EXT-X-/) {
			$ext_x_seen = 1;
		};        
     } ;

# Reset the filke point back to start so that standard M3U or HLS  playlist porocessing can restart
	seek($file,$curpos,0);
	
	if ($ext_x_seen == 1) {
		$log->info("Calling HLSPL read routine");
		Slim::Formats->loadTagFormatForType('hlspl');
		return Plugins::PlayHLS::HLSPL::read($class, $file, $baseDir, $url);
	} else {
		$log->info("Calling M3U read routine");
		Slim::Formats->loadTagFormatForType('m3u');
		return Slim::Formats::Playlists::M3U::read($class, $file, $baseDir, $url);
	}

	return;
}

#
# Duplicates from M3U.pm - as these are the same as m3u processing but will be called because part of m3um3u8 handling.
#

sub write {
	$log->info(" m3um3u8 write called ");
	return Slim::Formats::Playlists::M3U::write (@_);
}

sub _item {
	$log->info(" m3um3u8 _item called ");
	return Slim::Formats::Playlists::M3U::_item (@_);
}

1;

__END__
   


