package Plugins::PlayHLS::HLSPLAY;

# HLS protocol handler
#
# (c) Triode, 2015, triode1@btinternet.com
#
# Released under GPLv2
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

use strict;

use base qw(IO::Handle);

use Slim::Utils::Errno;
use Slim::Utils::Log;

use MyAnyEvent::HTTPhls;
use Plugins::PlayHLS::HLSmpeg2;
use Plugins::PlayHLS::ScanHLS;
use Plugins::PlayHLS::SegmentUtils;
use URI;
use URI::Split;

use Data::Dumper;

use bytes;

use constant PRE_FETCH         => 4; # number of chunks to prefetch
use constant REFETCH_INTERVAL  => 6; # Default 6 sec to refetch playlist if chunk size is unknown.
use constant HTTP_GET_TIMEOUT  => 30;
use constant IO_SELECT_FIXED => (Slim::Utils::Versions->compareVersions($::VERSION, '7.9.1') >= 0);

my $log = logger('plugin.playhls');

Slim::Player::ProtocolHandlers->registerHandler('hlsplay', __PACKAGE__);
Slim::Player::ProtocolHandlers->registerHandler('hlsplays', __PACKAGE__);
Slim::Formats::Playlists->registerParser('hlspl', 'Plugins::PlayHLS::HLSPL');
Slim::Formats::Playlists->registerParser('m3um3u8', 'Plugins::PlayHLS::M3UM3U8');


my $useragentstring = Slim::Utils::Misc::userAgentString() ;

sub isRemote { 1 }

#  This is needed because other parts of LMS checks content by URL which is m3u8 both for master and media playlist and returns hlspl (HLS playlist type)

sub formatOverride {
	my ($class, $self) =@_;
	
	my $client  = $self->master();
	my $track   = $self->currentTrack();
	my $url     = $track->url;
	$log->info('Format returned '. $track->content_type . " for url $url");
	
 return $track->content_type ;
}

#  Need to scan the stream because technically HLS can be either AAC or MP3 althouygh inreality it seems to be always AAC.
#  However it help gets details of the codec and sample rate.

sub scanStream {
	my $class = shift;
	Plugins::PlayHLS::ScanHLS::FindFormat(@_);
}

sub scanUrl {
	my ($class, $url, $args) = @_;
	
	my @argskeys = keys %{$args};
	$log->info("scanURL called $url");

	my $song   = $args->{'song'};
	my $track  = $song->track;
	my $client = $args->{'client'};
	
	my $playlist = Slim::Schema::RemoteTrack->fetch($url, 1);
	$song->pluginData(baseUrl => $url);

	Slim::Utils::Scanner::Remote->scanURL($url, $args);
	
}
#  Currently not expected to be used - so if called log an error and returned an invalid type.
sub contentType {
	my $class = shift;
	$log->error("Contenttype called ");
	return 'xyz';
}
#
#  This is not called - protocol Hnalder is deemed otbe HTTP or HTTPS so bufferThreshold is done within the HTTP protocol handler.   Elsewhere in ScanHLS bitrate is "faked" to get "better" threshold.
#

sub bufferThreshold { 
	my ( $class, $client, $url) = @_;
	
	my $song     = $client->playingSong();
	my $byterate  = $song->streambitrate() / 8;

	use constant BUFFER_SECONDS => (6 * 2);  #  Don't know chunk length at this time so pick 6 secs - minimum is typically 6 secs. Aim to have 2 times chunk ready before playing
	
	my $bufferThreshold =  int( ($byterate * BUFFER_SECONDS) / 1000);  # Threshold is in kilobytes - so number of bytes divided by 1000
			
	# Max threshold is 255
	$bufferThreshold = 255 if $bufferThreshold > 255;
	$bufferThreshold = 100 if ($song->streambitrate() > 128000);
	
	$log->error('Bitrate:'. $song->streambitrate(). "Threshold $bufferThreshold  url $url");

	return $bufferThreshold	;
}


sub new {
	my $class  = shift;
	my $args   = shift;

	my $client = $args->{'client'} ;
	my $song   = $args->{'song'};
	my $url    = ($song->can('streamUrl') ? $song->streamUrl : $song->{'streamUrl'}) || $args->{'url'};

	$log->info(" New HLSPLAY url= $url");
	
	
	my $playlist = $client->currentPlaylist();
	$log->info("Dump of playlist ". Dumper($playlist));

	$url =~ s/^hlsplays/https/;
	$url =~ s/^hlsplay/http/;
	$url =~ s/\|$//;

	my $self = $class->SUPER::new;

	my $hls_details = $client->pluginData('hls_scandata');

	${*$self}{'song'}         = $song;
	${*$self}{'_chunks'}      = [];
	${*$self}{'_pl_noupdate'} = 0;
	${*$self}{'_played'}      = 0;

	${*$self}{'_hls_content'}             = $hls_details->{'content'};
	${*$self}{'_hls_transport'}           = $hls_details->{'transport'};
	${*$self}{'_hls_mpeg2_audio_pid'}     = $hls_details->{'mpeg2_audio_pid'};
	${*$self}{'_hls_mpeg2_audio_type'}    = $hls_details->{'mpeg2_audio_type'};
	${*$self}{'_hls_mpeg2_metadata_pid'}  = $hls_details->{'mpeg2_metadata_pid'};
	
	${*$self}{'_media_sequence_no'} = 0;
	
	$song->pluginData('hls_content'  , $hls_details->{'content'});
	$song->pluginData('hls_transport', $hls_details->{'transport'});

	$log->info(' HLS content '. ${*$self}{'_hls_content'} .  'transport '. ${*$self}{'_hls_transport'} );

	# HLS Listen Again streaming requires cookies, otherwise '403' error
	# Curiously, HLS Live Streaming does not need cookies
	${*$self}{'_cookies'}    = {};
	$self->_fetchPL($url, 0);

	return $self;
}

 sub getMetadataFor {
	my $class  = shift;
	my $client = shift;
	my $url    = shift;

	if ($client && (my $song = $client->currentSongForUrl($url))) {
		
		my $bitrate = $song->streambitrate();
		my $decodeBufferdelay = $client->bufferFullness() / ( int($bitrate / 8) );
		my $outputBufferdelay = $client->outputBufferFullness() / (48000 * 8);
		
		if ( ($outputBufferdelay <= 2.0) && ($decodeBufferdelay <= 2.0) ) {
			$log->info(sprintf ("Player Buffer nearly empty:  Decode %7d (%5.2f)  output fullness %5d (%5.2f)  bitrate: %6d", $client->outputBufferFullness() , $outputBufferdelay, $client->bufferFullness() ,$decodeBufferdelay, $bitrate)) ;		
		}
		my $tagshash  = $song->pluginData('id3hash');
		my $title    = $tagshash->{'TIT2'}{'TEXT_description'};
		my $artist   = $tagshash->{'TPE1'}{'TEXT_description'};
		my $wxxx     = $tagshash->{'WXXX'}{'WXXX_value'};
		my $txxx     = $tagshash->{'TXXX'}{'TXXX_value'};

		$artist =~ s/\0$//; # get rid of null termination if any
		$title  =~ s/\0$//; # get rid of null termination if any

		$artist = undef if ($artist =~ /^ *$/) ; # Make undef if 0 or more spaces
		$title  = undef if ($title  =~ /^ *$/) ; # Make undef if 0 or more spaces

		my %wxxx_params = map { $_ =~ /(.*?)=(.*)/; $1 => $2; } split(/ /, $wxxx);
		my $icon;
		if ( ( defined($wxxx_params{'amgArtworkURL'}) )) {
			($icon) = $wxxx_params{'amgArtworkURL'} =~ /"([^"]*)"/;  # Get rid of leading and trailing quotes			
			$icon = undef unless ($icon =~ m/^(http|https):\/\//i ) ;
		};
		
		my $track = Slim::Schema::RemoteTrack->fetch($url);		
#		$log->info( sprintf (' Track title >>%s<<  bitrate Track/string  %d / %d  content %s hls content %s hls transport %s' ,
#					$track->title , $track->bitrate, $client->streamingSong()->streambitrate(),  ($track && $track->content_type) ,
#					$song->pluginData('hls_content') ,	$song->pluginData('hls_transport') ) );
		
		$icon = $song->pluginData('hls_coverurl') if (!defined($icon));

		my %metadata = ();
		$metadata{'title'}  = $title  || ($track && $track->title) ;
		$metadata{'artist'} = $artist if defined ($artist); 
		$metadata{'icon'}   = $icon   if defined ($icon); 
		$metadata{'cover'}  = $icon   if defined ($icon); 
		$metadata{'type'}   = ($track && $track->content_type) . ' (HLS)';
		return \%metadata; 
	} else {
	 $log->error(" No client or current song $client $song"); 	
	};
}


sub _make_BaseUrl {

	my $mpdurl  = shift;
	my $baseurl = shift;
	
	if ($baseurl =~ /^http:\/\//) {
	  return $baseurl;
	}

	if ($baseurl =~ /^https:\/\//) {
	  return $baseurl;
	}
	  
	my $url = URI->new_abs($baseurl,$mpdurl);
	return $url->canonical->as_string;
}

use constant HLS_FETCHDELAY_WARNING       => 3000; #   3 secs "Normal" acceptable delay
use constant HLS_FETCHDELAY_WARNING_DEBUG =>  800; # 800msecs - when debug logging - log more slow messages
use constant HLS_PERSISTENT_TIMEOUT => 20;
use constant HTTP_GET_TIMEOUT       => 30;

sub _fetchPL {
	my $self = shift;
	my $url  = shift;
	
	my $start = 0;
	my $old_refetch = ${*$self}{'_pl_refetch'} ;

	${*$self}{'_pl_prevrefetch'} = ${*$self}{'_pl_oldrefetch'};
	${*$self}{'_pl_oldrefetch'} = $old_refetch;
	${*$self}{'_pl_refetch'} = undef;	
	

# Save guard object so that timer etc get cancelled if stream is stopped when ${*$self} object is destroyed.	
	${*$self}{'_pl_hlsfetch'} = http_request (	GET => $url,
					headers => { 'User-Agent' => $useragentstring, 'Cache-Control' => 'no-cache', 'Pragma' => 'no-cache' } ,
					
					timeout => HTTP_GET_TIMEOUT,
					cookie_jar => ${*$self}{'_cookies'},

					sub {
							my ($body, $hdr) = @_;
							if ($hdr->{'Status'} eq '200') {
								_parsePL($body, $hdr, $self, $url, $start, $old_refetch);
							} else {
								$log->error("Closing stream - Fetch HLS error HTTP status = ". $hdr->{'Status'} . " Reason: ". $hdr->{'Reason'});
						  		${*$self}{'_pl_refetch'} = time() + REFETCH_INTERVAL;
								${*$self}{'_pl_url'}  = $url;
								${*$self}{'_pl_hlsfetch'} = undef;
								$self->close;
							}
					}
				);
}


sub _parsePL {
	
	my ($body, $hdr, $self, $url, $start, $refetch) = @_;

	my $is_debug = $log->is_debug;
	$is_debug && $log->debug("got: $url start: $start  refetch=$refetch");

	$log->debug("Playlist \n\n". $body . "\n\n");
	
	my @lines = split(/\n/, $body);

	my $line1 = shift @lines;
	if ($line1 !~ /#EXTM3U/) {
		$log->warn("bad m3u file: $url");
		$self->close;
		return;
	}

	my $duration = 0;
	my $lastint;
	my $chunknum;
	my @chunks = ();
	
	my $notendlist = 1;

#	$log->debug('Number of lines '. $#lines . "\n". Dumper(\@lines));

	while ($#lines >= 0) {
		
		my $line = shift @lines;
		if ($line =~ /#EXT-X-MEDIA-SEQUENCE:(\d+)/) {
			$log->is_info && $log->info("#EXT-X-MEDIA-SEQUENCE: $1");
			
			$log->error(" Broken media sequence - Number found $1   Previous: ". ${*$self}{'_media_sequence_no'} . "  Source: $line") if ($1 < ${*$self}{'_media_sequence_no'});
			${*$self}{'_media_sequence_no'} = $1;
			$chunknum = $1 + 1;   # Add one to MEDIA-SEQUENCE to ensure it is never zero (iHeart stations start with zero) - this causes problems with "false false"
			next;
		}

		if ($line =~ /#EXT-X-ENDLIST/) {
			$is_debug && $log->debug("#EXT-X-ENDLIST");
			${*$self}{'_pl_noupdate'} = 1;
			$notendlist = 0;
		}

		if ($line =~ /#EXTINF:(.*),/) {
			$duration += $1;
			$lastint  =  $1;

			$lastint = REFETCH_INTERVAL unless defined($lastint); # set default value if chunk length not given
			my $song = ${*$self}{'song'};

			my $chunkurl = shift @lines;
		# remove Carriage returns	
			$chunkurl =~ s/\cM//g;  
        # strip whitespace from beginning and end
			$chunkurl =~ s/^\s*//; 
			$chunkurl =~ s/\s*$//; 

			if ($chunkurl !~ /^http:|https:/)  {
				# relative url
				$is_debug && $log->debug("relative url: $chunkurl");
				my ($urlbase) = $url =~ /(.*)\//;
				$chunkurl = $urlbase . "/" . $chunkurl;
				$is_debug && $log->debug("converted to: $chunkurl");
			}

			if ($chunknum > ${*$self}{'_played'} && (!$start || !defined($duration) || $duration > $start)) {
				push @chunks, { url => $chunkurl, chunknum => $chunknum, len => $lastint };
			} 
			$chunknum++;
		}
	}

# On first Playlist (i.e. _played = 0 ) and not a live stream (i.e. no ENDLIST tag) - as per IETF Spec. shorten to last 3 segments in playlist if more than 3 segments in the playlist
# This means start playing near to realtime rather than perhaps 30 mins earlier - possibility for later implementation of "skip back"
	if ( (${*$self}{'_played'} == 0 ) && $notendlist && (scalar (@chunks) > 3))  {
		@chunks = splice @chunks, -3 , 3;
	} 

	$log->info("Playlist No: $chunknum  Url: $url , refetch=" . ${*$self}{'_pl_oldrefetch'} . ' interval: '.  (${*$self}{'_pl_oldrefetch'} - ${*$self}{'_pl_prevrefetch'}) )  ;

	if (${*$self}{'_pl_noupdate'} && $duration) {
		${*$self}{'song'}->duration($duration);
	}

	if ($log->is_info) {
		$log->info(sub { "existing chunks: [" . join(",", map { $_->{'chunknum'} } @{${*$self}{'_chunks'}}) . "]" });
		$log->info(sub { "new chunks: [" . join(",", map { $_->{'chunknum'} } @chunks) . "]" });
	}

	$AnyEvent::HTTP::PERSISTENT_TIMEOUT = HLS_PERSISTENT_TIMEOUT;

	if (scalar @chunks) {

		if (scalar @{${*$self}{'_chunks'}} > 0) {
			
			# only add on chunks which and more recent than existing chunk list
			for my $new (@chunks) {
				if ($new->{'chunknum'} > ${*$self}{'_chunks'}->[-1]->{'chunknum'}) {
					push @{${*$self}{'_chunks'}}, $new;
				};
			}

			if ($log->is_info) {
				$log->info("merged chunklist now " . scalar @{${*$self}{'_chunks'}} . " chunks");
				$log->info(sub { "chunks: [" . join(",", map { $_->{'chunknum'} } @{${*$self}{'_chunks'}}) . "]" });
			}

		} else {

			# new chunklist - fetch initial chunks
			${*$self}{'_chunks'} = \@chunks;

			$is_debug && $log->debug("new chunklist " . scalar @chunks . " chunks");

			for my $i(0 .. PRE_FETCH) {
				$self->_fetchChunk($chunks[$i]) if $chunks[$i];
			}
			my $client = ${*$self}{'song'}->owner->master ;
			$client->currentPlaylistUpdateTime(Time::HiRes::time());
		}
	}

	if (!${*$self}{'_pl_noupdate'}) {
		my $refresh_int = $lastint - 3 ;          # Make playlist refetch around chunk length but less 3 sec becuase timeout is driven off sysread which is a bit but simpler to manage/cancel than a Timer
		$refresh_int = 1 if ($refresh_int <= 0 ); # Make sure at least 1 sec interval in case segments are just 3 secs usually with only 3 segments so buffer can empty.
		${*$self}{'_pl_refetch'} = time() + $refresh_int ; 
		${*$self}{'_pl_url'}     = $url;
		$log->debug(" Refetch time scheduled for " . ${*$self}{'_pl_refetch'} . "now =". time(). " refresh int= $refresh_int");
	} 
	
}
#
# New fetchChunk which uses AnyEvent::HTTP to use HTTP 1.1 persistent TCP connection.
#
sub _fetchChunk {
	my $self  = shift;
	my $chunk = shift;
	$log->debug("Fetching chunknum [ $chunk->{chunknum}] at url $chunk->{url}");

	if (my $url = $chunk->{'url'}) {

		$chunk->{'fetching'} = 1;
		$chunk->{'requesttime'} = Time::HiRes::time();
		
		$log->is_info && $log->info(" GET [$chunk->{chunknum}] on url >>$url<<");
		$chunk->{'requestobj'}  = http_request (	GET => $url,
						headers => { 'User-Agent' => $useragentstring },
						timeout => HTTP_GET_TIMEOUT,
						cookie_jar => ${*$self}{'_cookies'},
					sub {
							my ($body, $hdr) = @_;
							my $fetchtime = int((Time::HiRes::time() - $chunk->{'requesttime'}) *1000);
							
#							Status of 20x means HTTP request completed OK
							if ($hdr->{'Status'} =~ /20[01234]/ ) { 
								if ($log->is_debug && ($fetchtime > HLS_FETCHDELAY_WARNING_DEBUG)) {
									$log->debug("Chunk fetch status ". $hdr->{'Status'} . " Long chunk fetch time $fetchtime" );
								} elsif ($fetchtime > HLS_FETCHDELAY_WARNING ) {  # log a message for long fetch delay 
									$log->info("Chunk fetch status ". $hdr->{'Status'} . " Long chunk fetch time $fetchtime   ". ${*$self}{'chunkdelay'}   );
								};
								$log->info("Fetched [$chunk->{chunknum}] fetch time $fetchtime size " . length($body) . ' url '. $chunk->{'url'} );
								
								delete $chunk->{'fetching'};
								delete $chunk->{'requestobj'};
								$chunk->{'chunkref'} = \$body;
							} elsif ( ($hdr->{'Status'} >= 400) && ($hdr->{'Status'} <= 511)) {
								$log->error("Aborting stream - fatal error fetching [$chunk->{chunknum}] Status=" . $hdr->{'Status'} . " Reason: ". $hdr->{'Reason'}. " Fetch time $fetchtime ms ");
								$log->error("Failed URL: ".$hdr->{'URL'} );
								$self->close;
								delete $chunk->{'fetching'};
								delete $chunk->{'requestobj'};
							} else {
								$log->error("Retrying after error fetching [$chunk->{chunknum}] Status=" . $hdr->{'Status'} . " Reason: ". $hdr->{'Reason'}. " Fetch time $fetchtime ms ");
								delete $chunk->{'fetching'};
								delete $chunk->{'requestobj'};
							}; 	
						}
			);
	}
}

sub isRemote { 1 }

sub isAudio { 1 }

sub isPlaylistURL {
	
	my $class = shift;
	my $url   = shift ;
#	$log->info("is PlaylistURL called $url");
	return ;
}


sub canSeek {
	my ($class, $client, $song) = @_;

	return $song->duration ? 1 : 0;
}

sub getSeekData {
	my ($class, $client, $song, $newtime) = @_;
	
	return { timeOffset => $newtime };
}

sub contentType {
	my $self = shift;
	return ${*$self}{'_hls_content'};
}

sub getIcon {
	my ($class, $url) = @_;

	my $handler;
	$log->error(" 1 GetIcon called ");

	if ( ($handler = Slim::Player::ProtocolHandlers->iconHandlerForURL($url)) && ref $handler eq 'CODE' ) {
		$log->error(" 2 GetIcon called " . &{$handler});

		return &{$handler};
	}

	$log->error(" 3 GetIcon called ". Plugins::PlayHLS::Plugin->_pluginDataFor('icon'));
	
	return Plugins::PlayHLS::Plugin->_pluginDataFor('icon');
}

sub close {
	my $self = shift;
# Just to be safe - explicitly, delete the cookie hash as http_request may still be in progress.
	delete ${*$self}{'_cookies'};
	${*$self}{'_close'} = 1;
}

sub sysread {
	my $self  = $_[0];
	# return in $_[1]
	my $maxBytes = $_[2];

	if (${*$self}{'_close'}) {
		$log->debug("closing");
		return 0;
	}

	my $song = ${*$self}{'song'};
	my $chunks = ${*$self}{'_chunks'};
	my $chunkref;
	my $ret = 0;
	my $hls_transport = ${*$self}{'_hls_transport'} ;
	my $hls_mpeg2ts_pespids = ${*$self}{'_hls_mpeg2ts_pespids'} ;
	
	my $hls_mpeg2_audio_pid  = ${*$self}{'_hls_mpeg2_audio_pid'}  ; 
	my $hls_mpeg2_audio_type = ${*$self}{'_hls_mpeg2_audio_type'} ;
	my $hls_mpeg2_metadata_pid =${*$self}{'_hls_mpeg2_metadata_pid'}  ; 
	
	if (scalar @$chunks) {
		$chunkref = $chunks->[0]->{'chunkref'};
	} elsif (${*$self}{'_pl_noupdate'}) {
		$log->debug("no chunks left - closing");
		return 0;
	}

	if ($chunkref) {
		$_[1] = "";
		my $nextpos = $chunks->[0]->{'nextpos'} ||= 0;

#
# HLS can have four types of trasnport
#  MPEG-2
#  Fragmented MPEG-4
#  Packed Audio	
#  WebVTT
#
# Scanning stream has determined the audio format and transprot - only 3 types supported MPEG2-ADTS, Packed-AAC and PAcked-MP3
#
		if ($hls_transport eq 'MPEG2TS-ADTS') {
			if ($nextpos == 0) {

#  HLS uses a restricted set of MPEG-2 format.  Each chunk includes a PAT, PMT and audio all in same chunk. There is a single audio stream.
#  So all MPEG2 data (e.g.PIDs, PES, program number) are self contained.

				my $mpegdata = Plugins::PlayHLS::HLSmpeg2::ParseMPEG2chunk(${$chunks->[0]->{'chunkref'}},$hls_mpeg2_audio_pid, $hls_mpeg2_metadata_pid);
				$chunks->[0]->{'chunkref'} = $chunkref = $mpegdata;
			}
			
			if ($nextpos <= length($$chunkref) && length($_[1]) < $maxBytes ) {
				
				my $availbytes = (length($$chunkref) - $nextpos);
				$availbytes = $maxBytes if ($availbytes > $maxBytes); 
				$_[1] .= substr($$chunkref, $nextpos, $availbytes);
				$nextpos += $availbytes;
				$ret  = $availbytes;
			}
#
#  Check to see if current chunk all used up
#
			if ($nextpos >= length($$chunkref)) {
				my $played = shift @$chunks;
				
				${*$self}{'_played'} = $played->{'chunknum'};
				$log->is_info && $log->info("played [$played->{chunknum}]");
			} else {
				$chunks->[0]->{'nextpos'} = $nextpos;
			}
		}
	
# HLS  aac trasnport "packed Audio" - this is ADTS frames must have ID3 metadata before with PRIV com.apple.streaming.transportStreamTimestamp
# Other ID3 tags must also be habdled.
		if ($hls_transport eq 'Packed-AAC') {
			if ($nextpos <= length($$chunkref) && length($_[1]) < $maxBytes ) {
				if ($nextpos == 0) {
					my %tagshash;
					my $bytesused = Plugins::PlayHLS::SegmentUtils::getID3frames(\%tagshash,$$chunkref);
					$log->info("ID3 Bytes skipped $bytesused");
					if ($bytesused) {
#						$log->info(" Sysread Tags found".Dumper(\%tagshash)) ;
						$song->pluginData('id3hash',\%tagshash);
						$song->pluginData('testid3hash','test set '.length($$chunkref));
						
						if (exists($tagshash{'TIT2'})) {
							if (($song->pluginData('oldtitle') ne $tagshash{'TIT2'}{'TEXT_description'})) {
									$log->debug('New title - tell clients "'. $tagshash{'TIT2'}{'TEXT_description'}.'"');
									$song->pluginData('oldtitle', $tagshash{'TIT2'}{'TEXT_description'});
									$song->owner->master->currentPlaylistUpdateTime(Time::HiRes::time());
									Slim::Control::Request::notifyFromArray($song->owner->master, [ 'newmetadata' ]);
							}
						}
					}
					$nextpos +=$bytesused;
#					$log->error(sprintf "Segment %0*v2X\n", " ", substr($$chunkref, $nextpos, 16) ) if ($bytesused) ;
				} ;
				
				my $availbytes = (length($$chunkref) - $nextpos);
				$availbytes = $maxBytes if ($availbytes > $maxBytes); 
				$_[1] .= substr($$chunkref, $nextpos, $availbytes);
				$nextpos += $availbytes;
				$ret  = $availbytes;
#				$log->debug ("sysread - returned $availbytes bytes - requested $maxBytes  nextpos =$nextpos length ". length($$chunkref));
			}
#
#  Check to see if current chunk all used up
#
			if ($nextpos >= length($$chunkref)) {
				my $played = shift @$chunks;
				${*$self}{'_played'} = $played->{'chunknum'};
				$log->is_info && $log->info("played [$played->{chunknum}]");
			} else {
				$chunks->[0]->{'nextpos'} = $nextpos;
#				$log->debug ("sysread - update chunknum " . $chunks->[0]->{'chunknum'} . "  nextpos set to $nextpos");
			}
		} ;

		if ($hls_transport eq 'Packed-MP3' ) {
			$log->info("Packed MP3 ");
			if ($nextpos <= length($$chunkref) && length($_[1]) < $maxBytes ) {
				if ($nextpos == 0) {
					my %tagshash;
					my $bytesused = Plugins::PlayHLS::SegmentUtils::getID3frames(\%tagshash,$$chunkref);
					$log->info("ID3 Bytes skipped $bytesused");
					if ($bytesused) {
						$log->info(" Tags found".Dumper(\%tagshash)) ;
						$song->pluginData('id3hash',\%tagshash);
					}
					$nextpos +=$bytesused;
				} ;
				
				my $availbytes = (length($$chunkref) - $nextpos);
				$availbytes = $maxBytes if ($availbytes > $maxBytes); 
				$_[1] .= substr($$chunkref, $nextpos, $availbytes);
				$nextpos += $availbytes;
				$ret  = $availbytes;
				$log->info ("sysread - returned $availbytes bytes - requested $maxBytes  nextpos =$nextpos length ". length($$chunkref));
			}
#
#  Check to see if current chunk all used up
#
			if ($nextpos >= length($$chunkref)) {
				my $played = shift @$chunks;
				${*$self}{'_played'} = $played->{'chunknum'};
				$log->is_info && $log->info("played [$played->{chunknum}]");
			} else {
				$chunks->[0]->{'nextpos'} = $nextpos;
				$log->info ("sysread - update chunknum " . $chunks->[0]->{'chunknum'} . "  nextpos set to $nextpos");
			}			
		} ;
	}	

	# refetch playlist if not a fixed list
	if (${*$self}{'_pl_refetch'} && ( time() > ${*$self}{'_pl_refetch'}) ) {
		$self->_fetchPL(${*$self}{'_pl_url'});
	} 

	# fetch more chunks
	
	for my $i (0 .. PRE_FETCH) {
		my $new = $chunks->[$i];
		if ($new && !$new->{'chunkref'} && !$new->{'fetching'}) {
			$self->_fetchChunk($new);
			last;
		}
	}
	$log->debug("Returning $ret bytes" )  if $ret;
	
	return $ret if $ret;

	# otherwise come back later - use EINTR as we don't have a file handle to put on select
	# In July 2018 a bug in Select was fixed - so can return EWOULDBLOCK necessary for no delay with live streams on Windows 10

	$! = IO_SELECT_FIXED ? EWOULDBLOCK : EINTR;

	return undef;
}

1;
