package Plugins::ArchiveOrg::Settings;

use strict;
use base qw(Slim::Web::Settings);

use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Utils::Strings qw(string);

use JSON::XS::VersionOneAndTwo;

use Data::Dumper;

my $log   = logger('plugin.archiveorg');
my $prefs = preferences('plugin.archiveorg');

sub name { return 'PLUGIN_ARCHIVEORG'; }

sub page { return 'plugins/ArchiveOrg/settings/basic.html'; }

sub prefs {
	return (preferences('plugin.archiveorg'), qw( is_app sortorder maxresults ));
}

sub handler {
	my ($class, $client, $params, $callback, @args) = @_;
    
    my $collections = $prefs->get('collections');

	if ( $params->{saveSettings} && $params->{pref_newcollection} ) {
		if ( my $newCollectionIdent  = $params->{pref_newcollection} ) {
			validateCollection( $newCollectionIdent, {
				cb  => sub {
					my $newCollectionName = shift;
					push @$collections, {
						name  => $newCollectionName,
						value => $newCollectionIdent,
					};
				
					my $body = $class->saveSettings( $client, $collections, $params );
					$callback->( $client, $params, $body, @args );
				},
				ecb => sub {
					my $error = shift;
				
					$params->{warning}   .= Slim::Utils::Strings::string( 'SETUP_PLUGIN_ARCHIVEORG_INVALID_FEED', $error );
					$params->{newcollectionval} = $params->{pref_newcollection};
				
					my $body = $class->saveSettings( $client, $collections, $params );
					$callback->( $client, $params, $body, @args );
				},
			} );
		
			return;
		}
	}
	return $class->saveSettings( $client, $collections, $params );
}


sub beforeRender {
	my $class = shift;
	my $params= shift;

#   Fix - show_app had output from "can" function which was a code reference 
#   which it seems was executed in Template and not just treated as a value.

	$params->{'show_app'} = Slim::Plugin::Base->can('nonSNApps') ? 1 : 0 ;
    
	my @prefSortOrderOpts =({ sortorder =>    0, sortordertext =>  'Default  '},
							{ sortorder =>    1, sortordertext =>  'Published Date '},
							{ sortorder =>    2, sortordertext =>  'Title          '});    

    $params->{'sortorderopts'} = \@prefSortOrderOpts;

	my @prefMaxResultOpts = ({ maxresult =>    50 , maxresulttext =>  '50 '},
							{  maxresult =>    100, maxresulttext =>  '100'},
							{  maxresult =>    200, maxresulttext =>  '200'},
							{  maxresult =>    300, maxresulttext =>  '300'},    
							{  maxresult =>    500, maxresulttext =>  '500'});    

    $params->{'maxresultopts'} = \@prefMaxResultOpts;


}

sub saveSettings {
	my ( $class, $client, $collections, $params ) = @_;
    
	my @delete = @{ ref $params->{delete} eq 'ARRAY' ? $params->{delete} : [ $params->{delete} ] };

	for my $deleteItem  (@delete ) {
		my $i = 0;
		while ( $i < scalar @{$collections} ) {
			if ( $deleteItem eq $collections->[$i]->{value} ) {
				splice @{$collections}, $i, 1;
				next;
			}
			$i++;
		}
	}

	$prefs->set( 'collections' , $collections );

	for my $collection ( @{$collections} ) {
		push @{ $params->{prefs}->{collections} }, [ $collection->{value}, $collection->{name} ];
	}

	return $class->SUPER::handler($client, $params);
}


sub validateCollection {

	my ( $ident, $args ) = @_;
    my $newCollectionUrl = "https://archive.org/metadata/$ident/metadata";

    $log->info("validating $ident...");
	main::INFOLOG && $log->is_info && $log->info("validating $ident...");

	Slim::Networking::SimpleAsyncHTTP->new(
    		\&_validateDone,
            \&_validateError,
            {
                ident     => $ident,
                cb      => $args->{cb},
                ecb     => $args->{ecb},
            }    
		
	)->get($newCollectionUrl);
}


sub _validateDone {

    my $http = shift;

    my $ident = $http->params('ident');
   	my $cb    = $http->params('cb');
   	my $ecb   = $http->params('ecb');

    my $jsondata = eval { from_json($http->content) };
    if ($@) {
       $log->error("Error parsing JSON data $@");
    };

    $log->info(" ident $ident Mediatype = ". $jsondata->{'result'}->{'mediatype'} . " title=". $jsondata->{'result'}->{'title'} );

    if ($jsondata->{'result'}->{'mediatype'} ne 'collection') {
        my $error = " Failed to add new collection $ident ";
        $ecb->($error);
        return;
     };

	$cb->( $jsondata->{'result'}->{'title'} );
}

sub _validateError {
    
    my $http = shift;
	my $error  = $http->error;	

	my $ident = $http->params('ident');
	my $cb    = $http->params('cb');
	my $ecb   = $http->params('ecb');

	$log->info(" Failed to get collections data $ident- error: $error");

	my $errormsg = string( 'SETUP_PLUGIN_ARCHIVEORG_INVALID_FEED', $error );
	$ecb->( $errormsg );
}
1;
