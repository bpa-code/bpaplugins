package Plugins::ArchiveOrg::LatestParser;

use strict;
use JSON::XS::VersionOneAndTwo;

use Slim::Utils::Log;
use Data::Dumper;

my $log = logger('plugin.archiveorg');

sub parse {
	my ($class, $http, $params) = @_;

    my $menu;

    my $jsondata = eval { from_json(${$http->contentRef}) };
    if ($@) {
       $log->error("Error parsing JSON data $@");
    };
    foreach my $item (@{$jsondata}) {
        
        my $title = $item->{'title'}[0];
        my $ident = $item->{'identifier'}[0];
        push (@{$menu},  {
             'name'    => $title,
             'url'     => "https://archive.org/metadata/$ident",
             'icon'    => "https://archive.org/download/$ident/__ia_thumb.jpg",
             'cover'   => "https://archive.org/download/$ident/__ia_thumb.jpg",
             'parser'  => 'Plugins::ArchiveOrg::MetadataParser',
             }
           );
    };

	return {
		'name'    => $params->{'feedTitle'},
		'items'   => $menu,
		'type'    => 'opml',
		'nocache' => 1,
	};
}

1;
