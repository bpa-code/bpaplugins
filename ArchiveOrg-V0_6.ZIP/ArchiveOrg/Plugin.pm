package Plugins::ArchiveOrg::Plugin;


# Copyright (C) 2021 baltontwo@eircom.net
#
# This file is part of LMS_ArchiveOrg_Plugin.
#
# LMS_ArchiveOrg_Plugin is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# LMS_ArchiveOrg_Plugin is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with LMS_ArchiveOrg_Plugin.  If not, see <http://www.gnu.org/licenses/>.

use strict;

use base qw(Slim::Plugin::OPMLBased);

use JSON::XS::VersionOneAndTwo;
use Digest::MD5 qw(md5_hex);
use URI::Escape;

use Slim::Utils::Log;
use Slim::Utils::Cache;
use Slim::Utils::Prefs;
use Slim::Utils::Strings qw(string);

use Plugins::ArchiveOrg::SearchParser;
use Plugins::ArchiveOrg::LatestParser;
use Plugins::ArchiveOrg::MetadataParser;

use Plugins::ArchiveOrg::Settings;
use Plugins::ArchiveOrg::ProtocolHandler;

use Data::Dumper;

my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.archiveorg',
	'defaultLevel' => 'ERROR',
	'description'  => getDisplayName(),
});

my $prefs      = preferences('plugin.archiveorg');

my $pluginName = 'ArchiveOrg';
use constant CACHEONEHOUR    =>  3600; 

my $cache = Slim::Utils::Cache->new();
$cache->clear();

# my @pref_collections = qw( audio etree librivoxaudio audio_bookspoetry audio_tech audio_music audio_news audio_foreign audio_podcast folksoundomy_bbcradio oldtimeradio); 
# my @pref_collections = qw( etree audio_tech audio_music audio_news folksoundomy_bbcradio ); 
				 

my $pref_maxresult = 200;

sub _pluginDataFor {
	my $class = shift;
	my $key   = shift;

	my $pluginData = Slim::Utils::PluginManager->dataForPlugin($class);

	if ($pluginData && ref($pluginData) && $pluginData->{$key}) {
		return $pluginData->{$key};
	}

	return undef;
}
my @sortorderterm =('','&sort[]=publicdate+desc','&sort[]=titleSorter+asc');

sub handleFeed {
	my ($client, $callback, $params, $args) = @_;
    
	if (main::INFOLOG && $log->is_info) {
		$log->info("--- Archive Collections pref list:");

		for my $item (@{ $prefs->get('collections') }) {
			$log->info( "      $item->{'name'}  ( $item->{'value'} )");
		}
		$log->info("---");
	}    
    
    my $menu;
    my @pref_collections = @{$prefs->get('collections')} ;

    if ( ! @pref_collections  ) {
        push @$menu, { 'name'  => string('PLUGIN_ARCHIVEORG_NOCOLLECTIONS'),
                       'type'  => 'text'
                    } ;
        $callback->( { items => $menu } );
        return;
    }    
    
    my $sortorder = $sortorderterm[$prefs->get('sortorder')];
    my $maxresults = $prefs->get('maxresults');
    
    foreach my $collection (@pref_collections) {
        my $ident  = $collection->{'value'};
        my $title  = $collection->{'name'};
        
        my $image = "https://archive.org/download/$ident/__ia_thumb.jpg";

        push (@$menu, {
			name   => 'Latest : '.$title,
            image  => $image ,
            icon   => $image ,
			url    => "https://archive.org/services/collection-rss.php?collection=$ident&output=json",
			parser => 'Plugins::ArchiveOrg::LatestParser',
        });
        push (@$menu, {
			name   => 'Search: '.$title,
            image  => $image ,
            icon   => $image ,
            type   => 'search', 
			url    => "https://archive.org/advancedsearch.php?q=({QUERY})+AND+collection:($ident)&fl[]=identifier$sortorder&fl[]=title&fl[]=creator&fl[]=date&rows=$maxresults&output=json",
			parser => 'Plugins::ArchiveOrg::SearchParser',
        });
    }

	$callback->( { items => $menu } );
}


sub initPlugin {
	my $class = shift;
    
	Plugins::ArchiveOrg::Settings->new($class);
    
	$prefs->init({
        is_app      => 0,
		collections => [],
        sortorder   => 0,
        maxresults  => 100
	});    

	$class->SUPER::initPlugin(
		feed   => \&handleFeed,
		tag    => 'archiveorg',
		is_app => $class->can('nonSNApps') && $prefs->get('is_app') ? 1 : undef,
		menu   => 'radios',
		weight => 1,
	);
 
}

sub getDisplayName { 'PLUGIN_ARCHIVEORG' }

sub playerMenu { shift->can('nonSNApps') && $prefs->get('is_app') ? undef : 'RADIO' }

1;
