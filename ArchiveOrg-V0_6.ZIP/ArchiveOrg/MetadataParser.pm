package Plugins::ArchiveOrg::MetadataParser;

use strict;
use JSON::XS::VersionOneAndTwo;

use Slim::Utils::Log;
use Slim::Utils::Strings qw(string);

use Data::Dumper;
use Data::Dump;

my $log = logger('plugin.archiveorg');

my %audio_formats = ( 'VBR MP3' => 'MP3', 'Ogg Vorbis' => 'OGGVORBIS', '24bit Flac' => 'FLAC24', 
                      'Flac' => 'FLAC', 'WAVE' =>'WAV', 'WMA' => 'WMA', 'TORRENT' => 'TORRENT',
                      'MPEG-4 AUDIO' => 'MPEG-4');

sub parse {
	my ($class, $http, $params) = @_;

    my $jsondata = eval { from_json(${$http->contentRef}) };
    if ($@) {
       $log->error("Error parsing JSON data $@");
    };

    my $menu;
    my %menus;

    my $ident = $jsondata->{'metadata'}->{'identifier'};
    my $icon  = "https://archive.org/download/$ident/__ia_thumb.jpg";

    foreach my $item (@{$jsondata->{'files'}}) {
        if (exists( $audio_formats{$item->{'format'}} )) {
            
            
            my $type = 'audio';
            if ($item->{'format'} eq 'TORRENT') {
               $type = 'text';   
            };

            my $codec = $audio_formats{$item->{'format'}};
            my $name = exists( $item->{'title'} ) ? $item->{'title'} : ($jsondata->{'metadata'}->{'title'} . ' - ' .$item->{'name'} ) ;
             
            if ($item->{'artist'}) {
                $name .= ' ('. $item->{'artist'} .')'                
            } elsif  ($item->{'creator'}) {
                $name .= ' ('. $item->{'creator'} .')'                
            };
            
            if ($item->{'track'}) {
                $name = $item->{'track'} . ' '.$name;
            };

            push (@{$menus{'original'}}, {
              name =>  $name,
              url  => "https://archive.org/download/$ident/". $item->{'name'} ,
              icon  => $icon,
              cover => $icon,
              type =>  $type,
 			 'on_select'   => 'play',
             description => exists ($item->{'comment'} ) ? $item->{'comment'} : $jsondata->{'metadata'}->{'description'},

            }) if ($item->{'source'} eq 'original' ) ;
                
            push (@{$menus{$codec}}, {
              name =>  $name,
              url  => "https://archive.org/download/$ident/". $item->{'name'} ,
              icon  => $icon,
              cover => $icon,
              type =>  $type,
 			 'on_select'   => 'play',
             description => exists ($item->{'comment'} ) ? $item->{'comment'} : $jsondata->{'metadata'}->{'description'},

            });
       };
    };
    

# Make MP3 menu defauilt - add other formats as submenus to MP3 menu
    my $fullmenu ;
    
    if (exists ($menus{'original'})) {
# Copy all entrier that are original
        foreach my $item (@{$menus{'original'}}) {
            push @$fullmenu, $item;
        }
# Add a playlisr of originals
        push @$fullmenu, {
                    'name'   => 'Playlist - original',
                    'items'  => $menus{'original'},
                    'type'   => 'playlist',
        }
	};
    

    if (exists ($menus{'MP3'})) {
        push @$fullmenu, {
                    'name'   => 'VBR MP3',
                    'items'  => $menus{'MP3'},
                    icon  => $icon,
                    cover => $icon,
                    'type'   => 'opml',
                    'nocache' => 1,
        }
	};


    if (exists ($menus{'OGGVORBIS'})) {
        push @$fullmenu, {
                    'name'   => 'Ogg Vorbis',
                    'items'  => $menus{'OGGVORBIS'},
                    icon  => $icon,
                    cover => $icon,
                    'type'   => 'opml',
                    'nocache' => 1,
        }
	};


    if (exists ($menus{'FLAC'})) {
        push @$fullmenu, {
                    'name'   => 'Flac',
                    'items'  => $menus{'FLAC'} ,
                    'type'   => 'opml',
                    icon  => $icon,
                    cover => $icon,
                    'nocache' => 1,
        }
	};

    if (exists ($menus{'FLAC24'})) {
        push @$fullmenu, {
                    'name'   => 'Flac 24 bit',
                    'items'  => $menus{'FLAC24'}, 
                    icon  => $icon,
                    cover => $icon,
                    'type'   => 'opml',
                    'nocache' => 1,
        }
	};

    if (exists ($menus{'WAV'})) {
        push @$fullmenu, {
                    'name'   => 'Wave',
                    'items'  => $menus{'WAV'},
                    icon  => $icon,
                    cover => $icon,
                    'type'   => 'opml',
                    'nocache' => 1,
        }
	};

    $log->debug("Dump fullmenu ". Dumper(\$fullmenu));  

    push @$fullmenu,{ 
              'name'  => string('PLUGIN_ARCHIVEORG_NOAUDIOFOUND'),
              'type'  => 'text'
           } if ( ! defined ($fullmenu ));

	return {
		'name'    => $params->{'feedTitle'},
		'items'   => $fullmenu,
		'type'    => 'opml',
		'nocache' => 1,
	};
}


1;
