package Plugins::ArchiveOrg::SearchParser;

use strict;

use JSON::XS::VersionOneAndTwo;
use Slim::Utils::Log;
use Data::Dumper;
use Slim::Utils::Strings qw(string);

my $log = logger('plugin.archiveorg');

sub parse {
	my ($class, $http, $params) = @_;
	my $params = $http->params('params');
	my $url    = $params->{'url'};

    my $jsondata = eval { from_json($http->content) };
    if ($@) {
       $log->error("Error parsing JSON data $@");
    };

# Check if search had no matches

    if (int($jsondata->{response}->{numFound}) == 0 ) {
        push my @submenu, { 'name'    => string('PLUGIN_ARCHIVEORG_FOUNDNOMATCHES'),
                            'type'  => 'text'
                          } ;

		return {
            'name'    => $params->{'feedTitle'},
            'items'   => \@submenu,
            'type'    => 'opml',
            'nocache' => 1,
		};      
    }

# create menu of matches
    my $menu;
    foreach my $item (@{$jsondata->{response}->{docs}}) {

            my $name = $item->{'title'} ;
            if ($item->{'artist'}) {
                $name .= ' ('. $item->{'artist'} .')'                
            } elsif  ($item->{'creator'}) {
                $name .= ' ('. $item->{'creator'} .')'                
            };
            
            my $ident = $item->{'identifier'};
      
        	push (@$menu, { 
				'name'    => $name,
                'url'     => "https://archive.org/metadata/$ident",
                'icon'    => "https://archive.org/download/$ident/__ia_thumb.jpg",
                'cover'   => "https://archive.org/download/$ident/__ia_thumb.jpg",
                'parser'  => 'Plugins::ArchiveOrg::MetadataParser',
                }
                );
    };
    
	return {
		'name'    => $params->{'feedTitle'},
		'items'   => $menu,
		'type'    => 'opml',
		'nocache' => 1,
	};
}
1;
