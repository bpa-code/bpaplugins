package Plugins::RadioNet::Plugin;

# Plugin to get station from Radio,net
#
# Released under GPLv2

use strict;

use base qw(Slim::Plugin::OPMLBased);

use MyText::Balanced;
use JSON::XS::VersionOneAndTwo;

use Digest::MD5 qw(md5_hex);
use URI::Escape;

use Slim::Utils::Log;
use Slim::Utils::Cache;
use Slim::Utils::Prefs;

use Plugins::RadioNet::Settings;

use Data::Dumper;

my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.radionet',
	'defaultLevel' => 'ERROR',
	'description'  => getDisplayName(),
});

my $prefs = preferences('plugin.radionet');

# Initialise some global variables to make sure they have default values.

my $localedomain      = 'https://www.radio.net';
my $localemessages;   # hash of message according to local

my $apidomain      = 'https://prod.radio-api.net';

# short lists are in SystemEnglish (i.e. domain independent key) and not localised form.

my $genresMenu;
my $countriesMenu;
my $topicsMenu;
my $podcastMenu;
my $editorMenu;
my $topTenStations;
my $topTopics;

my $pluginName = 'radionetV3';

use constant CACHEONEHOUR    =>  3600; 
use constant CACHETHREEHOURS => 10800; 
my $cache = Slim::Utils::Cache->new();
$cache->clear();


my @radionetdomains  = ('https://www.radio.net', 'https://www.radio.pt', 'https://br.radio.net', # 0,1,2
				 'https://www.radio.it', 'https://www.radio.se', 'https://www.radio.fr',         # 3,4,5
				 'https://www.radio.es', 'https://mx.radio.net', 'https://co.radio.net',         # 6,7,8
				 'https://www.radio.de', 'https://www.radio.at', 'https://www.radio.pl',         # 9, 10,11 
				 'https://www.radio.dk',                                                         # 12  
				 'https://uk.radio.net', 'https://ie.radio.net',                                 # 13,14       
				 'https://au.radio.net', 'https://nz.radio.net',                                 # 15,16 
				 'https://za.radio.net', 'https://ca.radio.net', 'https://nl.radio.net'          # 17, 18, 19
				 ); 


sub getopts {
	my $url = shift;

	my ($baseurl, $optstr) = split(/\?/, $url);
	my %opts;

	for my $opt (split /\&/, $optstr) {
		if ($opt =~ /(.*)=(.*)/       ) { $opts{lc($1)}    = $2 } 
		else                            { $opts{lc($opt)}  =  1 }
	}
	
	return ($baseurl,\%opts);
}

sub getCachedMenu {
	my $url = shift;

	my $cacheKey = $pluginName . ':' . md5_hex($url);

	if ( my $cachedMenu = $cache->get($cacheKey) ) {
		my $menu = ${$cachedMenu};
		return $menu;
	};
	return;
}

sub cacheMenu {
	my ( $url, $menu, $seconds ) = @_;	

	my $cacheKey = $pluginName . ':' . md5_hex($url);
	$cache->set( $cacheKey, \$menu, $seconds );

	return;
}

# Fixup callable routine table - fixup need because CODE cannot be saved when menu is cached.

my %subItems = (
	'getStationURLs'	 => \&getStationURLs,
	'getSearch'  		 => \&getSearch,
	'getPagedLists'   	 => \&getPagedLists,
	);

sub fixupCodeRefs {
	my $menu = shift;

	for my $menuItem (@$menu) {
		my $codeRef = $menuItem->{passthrough}[0]->{'codeRef'};
#		$log->error(" Fixup menu $codeRef for ".$menuItem->{'name'} );

		if ( defined $codeRef ) {
			$log->error("Fixup failed for undefined routine: $codeRef ") unless (exists($subItems{$codeRef}));
			$menuItem->{'url'} = $subItems{$codeRef};
		}
# Fixup submenu if one is present
		fixupCodeRefs($menuItem->{'items'}) if (defined $menuItem->{'items'}) ;
	}
	return;
}

sub getCanonicalDomain {
	my $pagedata = shift;
	my $canonical_domain;

	if (defined($pagedata->{'canonicalDomain'}) ) {
		$canonical_domain = $pagedata->{'canonicalDomain'};	
	} elsif (defined($pagedata->{'DOMAIN'}) ) {
		$canonical_domain = $pagedata->{'DOMAIN'};	
	} else {  # Only do this when web page has probably changed and so need updating
		$log->error(" Canonical Domain is not defined in Radio.net web page - plugin should be updated");
		
		Slim::Utils::Misc::bt();
		$canonical_domain  = $radionetdomains[$prefs->get('radionetlocale')];;
	}

# Just in case https has been left off in a change
	$canonical_domain = 'https://'. $canonical_domain unless ($canonical_domain =~ m/^http(s?):\/\//i ) ;
	$log->debug(" Canonical domain $canonical_domain"); 

	return $canonical_domain;		
}	


sub updateLocale {
	my $sourceurl = 'https://www.radio.net';
	$localedomain = @radionetdomains[$prefs->get('radionetlocale')];
	
	$log->info(" Locale setting $localedomain");
	$sourceurl = $localedomain if (defined($localedomain));

	Slim::Networking::SimpleAsyncHTTP->new(
		sub { 						# Success - page fetched.
			my $http = shift;
            my @keywords = qw(messages navibar);
            my $jsondata = parseWebPage($http->content, \@keywords );

# Message shoudl be in the first chunk            
            my $messagechunk = $jsondata->[0];
            if (!defined ($messagechunk->{'messages'})) {
                $log->error(" Errors - locale messages not found in first chunk of Radio.net home page ");
                return;
            }
# Walk the chunk to find the locales "messages"
            my $messages = findJSONItem($messagechunk,'messages');
			
			$cache->clear();

			makeGenreMenu();
			makeCountryMenu();
			makeTopicMenu();
		},
		
		sub { # Page fetch error 
			my $http = shift;
			my $error  = $http->error;			
			$log->error(" Failed to get initial page from Radio.net - error: $error");
		}
	)->get($sourceurl);

}

sub initPlugin {
	my $class = shift;

	Plugins::RadioNet::Settings->new($class);
	Plugins::RadioNet::Settings->init($class);
	$log->error(" Init Plugin");

	$class->SUPER::initPlugin(
		feed   => \&handleFeed,
		tag    => 'radionet',
		is_app => $class->can('nonSNApps') && $prefs->get('is_app') ? 1 : undef,
		menu   => 'radios',
		weight => 1,
	);

	Plugins::RadioNet::Settings->new;
	updateLocale();

}

sub makeGenreMenu {

  makeListMenu ($localedomain . '/genre' ,        # Base URL for lists - country, Genres, topics
				'navibar.section.genres.outlink', # Key for transalation of "all" 
				'tags',                           # key to JSON 'data' for full list of items
				'popularSearches',                 # key to JSON 'data' for short list of items
                \&getGenreStations,              # Function to be fxied up to process item. 
                \$genresMenu);                    # ref to variable to save new menu.

}

sub makeTopicMenu {

  makeListMenu ($localedomain . '/topic' ,        # Base URL for lists - country, Genres, topics
				'navibar.section.moretopics.outlink', # Key for transalation of "all" 
				'tags',                           # key to JSON 'data' for full list of items
				'popularSearches',                 # key to JSON 'data' for short list of items
                \&getTopicStations,             # Function to be called up to process item.
                \$topicsMenu);                    # ref to variable to save new menu.

}

sub makeCountryMenu {

  makeListMenu ($localedomain . '/country' ,      # Base URL for lists - country, Genres, topics
				'page.all_countries.headline',    # Key for translation of "all" 
				'tags',                           # key to JSON 'data' for full list of items
				'popularSearches',               # key to JSON 'data' for short list of items
              \&getCountryStations,             # Function to be CALLed up to process item.
              \$countriesMenu);                 # ref to variable to save new menu.
    return;
}
 
sub makeListMenu {
	
	my $sourceurl    = shift ;
  	my $keyAll       = shift ;
  	my $keyFullList  = shift ;
  	my $keyShortList = shift ;
  	my $getFunction  = shift ;
	my $listMenuref  = shift ;

#
# Find tags in JSON data
#	
	my $menulanguage = ($prefs->get('use_locale')) ? 'name' : 'systemName'  ;  #   systemName key has English menu, name key has locale veriosn of menu, slug key is to be used in URLs
#	my $allmenu      = ($prefs->get('use_locale')) ? $localemessages->{'common'}->{$keyAll}  : 'All' ;
	my $allmenu      = 'All' ;

	$log->info(">>>>>>>>>>>>>>>>>>>>>> Fetching $sourceurl");
	Slim::Networking::SimpleAsyncHTTP->new(
		sub { 						# Success - page fetched.
			my $http = shift;
            my @keywords = qw(tags);
            my $jsondata = parseWebPage($http->content, \@keywords );

# list with tags shoudl be in the first chunk            
            my $listchunk = $jsondata->[0];
            if (!defined ($listchunk->{'tags'})) {
                $log->error(" Errors - list tags not found in first chunk of Radio.net page $sourceurl");
                return;
            };
# Walk the chunk to find the hash with a key of 'tags'
            my $datalist = findJSONItem($listchunk,'tags');

			my @menu ;

            if ( $keyShortList ne '' ) {
                my $itemsShortlist = $datalist->{$keyShortList};

                foreach my $item (@$itemsShortlist) {
                    push @menu, {
                    'name'	      => $item->{'systemName'} . ' ('.$item->{'count'}.')',
                    'url'         => $getFunction,
                    'type'        => 'link',	
                    'passthrough' => [ {'url' => $sourceurl. '/'.$item->{'slug'} } ],
                    };
                };
            };
            
# Sort as depending on locale/English language, menu has different sort order.
			my @sortedMenu;
#			if ($prefs->get('use_locale') ) {
				@sortedMenu = @menu ;
#			} else { 
#				@sortedMenu = sort { $a->{'name'} cmp $b->{'name'} } @menu;
#			}	

# Make up the full sub menu of all items  (not short list)
			my @subMenu;
            my $itemsFulllist = $datalist->{'tags'};
			foreach my $item (@{$itemsFulllist}) {
				push @subMenu, {
				'name'	      =>  $item->{'systemName'} . ' ('.$item->{'count'}.')',
				'url'         => $getFunction,
				'type'        => 'link',	
				'passthrough' => [ {'url' => $sourceurl. '/'.$item->{'slug'} }],
				};
			}	

# Sort  if using English language version of a different language menu - as English traslations has different sort order.
			my @sortedSubMenu;
#			if ($prefs->get('use_locale') ) {
				@sortedSubMenu = @subMenu ;
#			} else { 
#				@sortedSubMenu = sort { $a->{'name'} cmp $b->{'name'} } @subMenu;
#			}	

# If there is a shortlist Combine full submenu in with short menu using the menu item for "all" except for podcast - no shortlist
            if ( $keyShortList ne '') {
                push @sortedMenu, {
                    'name'	      => $allmenu, #    'All',
                    'items'		  => \@sortedSubMenu
                };
			} else { # Only a long menu 
                @sortedMenu = @sortedSubMenu;        
            };

			$$listMenuref = \@sortedMenu;
		},
		sub { # Page fetch error 
			my $http = shift;
			my $error  = $http->error;			
			$log->error(" Failed to get genres list from Radio.net - fetch error: $error");
			$$listMenuref = undef;
		}
	)->get($sourceurl);	
	
	return ;
}

my @englishmenutext = ('Search','Local Stations','Top Stations', 'Genre', 'Countries', 'Topics', "Editor's tips", 'Podcasts');

my $similarStationMenuText;

sub handleFeed {
	my ($client, $callback, $params, $args) = @_;
	my $icon = Plugins::RadioNet::Plugin->_pluginDataFor('icon');
	
#	my @localemenutext  = (	$localemessages->{'common'}->{'header.search.placeholder'} , 
#							$localemessages->{'common'}->{'navibar.section.local.menu'},
#							$localemessages->{'common'}->{'navibar.section.top.menu'},
#							$localemessages->{'common'}->{'navibar.section.genres.menu'},
#							$localemessages->{'home-page'}->{'module.taglist.country.title'},
#							$localemessages->{'common'}->{'navibar.section.moretopics.alt_menu'},
#							$localemessages->{'home-page'}->{'module.tab_carousel.tab.editors_tips'},
#                           $localemessages->{'common'}->{'navibar.section.podcasts.menu'} , 
#                             );   
							
                            
#	my $menutext = ($prefs->get('use_locale')) ?  \@localemenutext : \@englishmenutext ;							
	my $menutext = \@englishmenutext ;							

	my $menu = [
			{
				name        => $menutext->[0], # name  => 'Search',
				type        => 'search',
				url         => \&getSearch,
				passthrough => [ { 'pageno' => 1} ],
			},	
			{
				name        => $menutext->[1],# name => 'Local stations',
				type        => 'link',
				url         => \&getNearYou,
			},	
			{
				name        => $menutext->[3],# name => 'Genre',
				items		=> $genresMenu
			},	
				
			{
				name        => $menutext->[5],#	name => 'Topic',
				items		=> $topicsMenu
			},	

			{
				name        => $menutext->[4],#	name => 'Countries',
				items		=> $countriesMenu
			},	
		];
	$callback->( { items => $menu } );
};

sub commonFetchParse {

	my ( $client, $callback, $args, $passthrough,$sourceUrl, $parseRoutine ) = @_;
	
	if (  my $cachemenu = getCachedMenu($sourceUrl) )  {
		fixupCodeRefs($cachemenu);
		$callback->( { items => $cachemenu } );
		return;
	}
	my $starttime  = Time::HiRes::time() ;
    
	Slim::Networking::SimpleAsyncHTTP->new(
		sub {
			my $http = shift;
			
			my $fetchedtime = Time::HiRes::time() - $starttime ;
			my $menu = $parseRoutine->($http->content,$sourceUrl);
			my $parsedtime = Time::HiRes::time() - $starttime ;
			
			$log->info(sprintf("Fetch delay %15.6f  Parse delay %15.6f for url %s ",$fetchedtime,$parsedtime, $sourceUrl)); 

			cacheMenu($sourceUrl, $menu, CACHEONEHOUR);			
			fixupCodeRefs($menu);
			$callback->( { items => $menu } );
		},

		# Called when no response was received or an error occurred.
		sub {
			$log->warn("error: $_[1]");
			$callback->( [ { name => $_[1], type => 'text' } ] );
		}
	)->get($sourceUrl);

	return;
}

# Search results are not cached - maybe it shoudl be.

sub getSearch {

	my ( $client, $callback, $args, $passthrough ) = @_;

	my $searchstr;
	my $offset =0;
    my $searchcount = 200;
	my $searchUrl;
	
	if (defined($args->{'search'})) {
	    $searchstr = URI::Escape::uri_escape_utf8($args->{'search'});
	    $searchUrl = "$apidomain/stations/search?query=$searchstr&count=$searchcount&offset=$offset"
	} 
	
	if (defined ($passthrough->{'codeRef'})) {
		$searchUrl= $passthrough->{'url'};
	};  

	commonFetchParse($client, $callback, $args, $passthrough,
					$searchUrl,
					\&parseSearchStationsReply);
};

sub getNearYou {
	my ( $client, $callback, $args, $passthrough ) = @_;
	
	commonFetchParse($client, $callback, $args, $passthrough,
					"$apidomain/stations/local?count=100",  # Max count is 100 - any higher only one station returned
					\&parseStreamsReply);
};

sub getPagedLists {
	my ( $client, $callback, $args, $passthrough ) = @_;
	
	commonFetchParse($client, $callback, $args, $passthrough,
					 $passthrough->{'url'},
					\&parseListMenuReply);
};

sub getStationURLs {

	my ( $client, $callback, $args, $passthrough ) = @_;
	my $stationUrl = $passthrough->{'stationurl'};	

	commonFetchParse($client, $callback, $args, $passthrough,
					$stationUrl,
					\&parseStationURLReply);
	return;
};


sub getTopicStations {
	
	my ($client, $callback, $args, $passthrough) = @_;
	
	commonFetchParse($client, $callback, $args, $passthrough,
					 $passthrough->{'url'},
					\&parseListMenuReply);
	return;
}

sub getGenreStations {
	
	my ($client, $callback, $args, $passthrough) = @_;
	
	commonFetchParse($client, $callback, $args, $passthrough,
					 $passthrough->{'url'},
					\&parseListMenuReply);
	return;
}

sub getCountryStations {
	
	my ($client, $callback, $args, $passthrough) = @_;
	
	commonFetchParse($client, $callback, $args, $passthrough,
					 $passthrough->{'url'},
					\&parseListMenuReply);
	return;
}

#
#  Generic parse a Radio Net web page and find fragment of JSON useful for locale messages, Genres List, by Genre content, Country list and by Country contents , Topics list and by topic contents
#

sub parseWebPage {
    
    my $htmlpage = shift;
    my $keywords = shift;
    my ($begin, $after, $middle, $tail);
    my $count = 1;
    my $i;
    
    my @fragments;
    
    $log->info("Lookgin for keywords ".Dumper($keywords));

# The page is made up of HTML and <SCRIPT ....> .... </SCRIPT> whcih can contain contain javascript and/or JSON fragments. 
#  Scan the page for next <SCRIPT> elements. 

    while (index($htmlpage,'<script') >= 0) {

# Isolate next script elements - after has the body until end of page.        
        ($begin, $after) = split (/<script/,$htmlpage,2);

# Now split on  </SCRIPT>  - middel willhave script elee,nt, and tail has remains of html page - processed in next loop.
        ($middle,$tail) = split (/<\/script>/,$after,2);
        $htmlpage = $tail;

# HTML page has many chars Javascript escaped - key ones such as quotes, \u0026 to & and also < >
#        $middle =~s/\\"/"/g;
   
        $middle=~s/\\( (?:[arnt'"\\]) )/"qq|\\$1|"/geex;   # Replace many escaped chars such as  \t \n \" \'
        $middle =~s/\\u0026/&/g;                           # REplace a few more Javascript escape sequences 
        $middle =~s/\\u003e/>/g;
        $middle =~s/\\u003c/</g;         
 
# The SCRIPTS with a jaavscript function like "self.__next_f.push" seem to have JSON fragment which will be square brackets. Find opening bracket.
        $i = index($middle, 'self.__next_f.push([') ;  

#  Interestgn <SCRIPT start with something like 
#      type="a009a1095b65087f4e4db780-text/javascript">self.__next_f.push([1,"15:[["$"
# and  type="a009a1095b65087f4e4db780-text/javascript">self.__next_f.push([1,"15:["$"
#   so look for matching string near the beginning.

# Examples
# Good type="a009a1095b65087f4e4db780-text/javascript">self.__next_f.push([1,"15:[["$","
# Bad  type="a009a1095b65087f4e4db780-text/javascript">self.__next_f.push([1,"6a:T
# Bad  type="a009a1095b65087f4e4db780-text/javascript">self.__next_f.push([1,"14:null
# Bad  type="bb0734de31b8d0c2f4c86fcc-text/javascript">self.__next_f.push([1,"6c:I[8329,["2369
# Bad  type="a009a1095b65087f4e4db780-text/javascript">self.__next_f.push([1,"\n
# Bad  type="a009a1095b65087f4e4db780-text/javascript">self.__next_f.push([1,"CNN 

# Initially check for double [[ bracket.
        if ($middle =~ m/^ type="[0-9a-fA-F]+-text\/javascript">self.__next_f.push\(\[[0-9a-z]+,"[0-9a-z]+:\[\[/ ) {
#           Found a possibledouble bracket - so pattern match to skip start and then look for a partial JSON string using balanced parenthes.

# extract strign with potential opening parenethes after initial matching string from middle ands save it in jsondata.
            my $jsondata;
            ($jsondata = $middle) =~ s/^ type="[0-9a-fA-F]+-text\/javascript">self.__next_f.push\(\[[0-9a-z]+,"[0-9a-z]+://;
#           remove excess closing brackets 
            substr($jsondata,-3) = "";

#  Extract text within outermost balanced square brackets if any text is found, assume it is JSON
            my($extract, $remain)  = Text::Balanced::extract_bracketed($jsondata , '[]' );
            my $parsedjson;
 
# Add curle brackterst as Perl JSON exepcts the - add a "Type" - may help alter when looking for specific JSON data,
            my $json_source;
            if (length($remain) < 10) {
                $parsedjson = eval { from_json('{"Type1-x":'. $extract .'}') };
                $json_source = $extract;
            } else {
                $parsedjson = eval { from_json('{"Type1-r":'. $remain .'}') };
                $json_source = $remain;
            };

#  Try to parse the string as JSON - if it valid JSON - save it. 
            if ( $@  ) {
                    $log->error( "Error parsing Type 1 json data " . $@ );
                    next;
            };
            

            if (defined($parsedjson) ) {
                my $keep = 0;
                foreach my $keyword (@{$keywords}) {
                    if ( (index($json_source, "\"$keyword\":{") > 0) || ( index($extract, "\"$keyword\":[") > 0 )) {
                        $parsedjson->{"$keyword"} = 1;
                        $keep = 1;
                    } else {
 #                      $log->error(" Failed $keyword look in JSON \n. ".Dumper($json_source)) if ($keyword eq 'tags')    
                    }
                }
                push @fragments, $parsedjson if ($keep);
            };
             
# Repeat except for a fragment with only one opening square bracket.
            
        } elsif ($middle =~ m/^ type="[0-9a-fA-F]+-text\/javascript">self.__next_f.push\(\[[0-9a-z]+,"[0-9a-z]+:\[/ ) {

            my $jsondata;
            ($jsondata = $middle) =~ s/^ type="[0-9a-fA-F]+-text\/javascript">self.__next_f.push\(\[[0-9a-z]+,"[0-9a-z]+://;
            my($extract, $remain)  = Text::Balanced::extract_bracketed($jsondata , '[]' );

            my $parsedjson = eval { from_json('{"Type2-x":'. $extract .'}' ) };
            if ( $@  ) {
                $log->error( "Error parsing Typew 2 json data " . $@ );
                next ;
            }

            if (defined($parsedjson) ) {
                my $keep = 0;
                foreach my $keyword (@{$keywords}) {
# Check the Json source for a number of tags so that 
                    if ( (index($extract, "\"$keyword\":{") > 0) || ( index($extract, "\"$keyword\":[") > 0 )) {
                        $parsedjson->{"$keyword"} = 1;
                        $keep = 1;
#                        $log->error(" Found $keyword in fragement ");

                    }
                }
                push @fragments, $parsedjson if ($keep);
            };
        };
        $count++;
    }

    return \@fragments;
}

sub parseSearchStationsReply {

	my $http = shift;
	my $url  = shift;
	
	my ($baseurl,$opts) = getopts($url);
	
	my $searchurl = $baseurl . '?query=' . $opts->{'query'};
#	$log->error("Dump of opts for $url  $baseurl \n".Dumper(\$opts)); 

	my $offset =0  ;
    my $menu;
    my $stationsmatched;
    my $totalcount;
    my $stationsperpage = 100;

#  Response is a JSON

	my $jsondata = eval { from_json($http) };
    if ( $@  ) {
         $log->error("\n\n----- error parsing ASeach reply json data " . $@ );
         return;
    }

	my $totalcount = $jsondata->{'totalCount'};
	$log->info(" Total count of station found: $totalcount");
    
# check for results
	unless (defined ($jsondata->{'playables'})) {
		$log->error(" No Playables found in search reply - perhaps plugin needs ot be updated.");
		push @$menu , {
			'name'	      => 'No programs found in search reply',
		} ;
		return $menu;
	};

	my $stationscount  = scalar (@{$jsondata->{'playables'}});
	
    my $totalpages = 1;
	if ($totalcount > $stationscount) {
		$totalpages = int(($totalcount + ($stationsperpage - 1))/ $stationsperpage); # Round up to get number of pages available
	};
	
	$menu = makePlayablesMenu($jsondata->{'playables'});

	$log->debug(" Menu ". Dumper(@$menu));

#  Having processed all items - if Page 1 of genre then add menus for other pages in same genre.  
#  First find out how many pages.

	if ($offset == 0) {        # Page 1 has offset 0
        my $offset = $stationsperpage;
		for (my $i = 2; $i <= $totalpages; $i++) { 
			push @$menu, {
				'name'	      => "Page $i of $totalpages",
				'url'         => '',
				'type'        => 'link',	
				'passthrough' => [ { 'url' => $searchurl ."&count=$stationsperpage&offset=$offset", 'pageno' => $i,
									'codeRef'     => 'getSearch'}	],
			};	
            $offset += $stationsperpage;
		}
	}

# All done 
	if (scalar @$menu == 0) {
		push @$menu , {
			'name'	      => 'No programs found',
		} ;
	}

	$log->debug("Dump of menu ". Dumper($menu));

	# return menu
	return $menu ;

}

#  Get playable URLs for a station Id.  Station type can be either a STATION or PODCAST

sub parseStationURLReply {

	my $http = shift;

	my @menu;
	
	my 	$jsondata = eval { from_json($http) };
#    $log->error(" JSON extract ". Dumper(\$jsondata));
	if ($@) {
		$log->error("Error parsing JSON data $@");
		return;
	}    
# Stations URLs are in broadcast-> streams,   (used to be result-> streams)  - this has changed with web site changes.

	unless (defined ($jsondata->[0]->{'streams'})) {
		$log->error(' No Streams found in URL reply found - perhaps plugin needs to be updated.');
		push @menu , {
			'name'	      => 'No programs found',
		} ;
		return \@menu;
	};

	my $icon   = getstationlogo($jsondata->[0]);
	my $title  = $jsondata->[0]->{'name'};
	my $desc   = $jsondata->[0]->{'description'};
	my $artist = $jsondata->[0]->{'country'};
	my $id     = $jsondata->[0]->{'id'};

# Two types ofprocessing STATION and PODCAST  - podcast have optional many episodes
	if ($jsondata->[0]->{'type'} eq 'STATION') {
		my $sourceurls = $jsondata->[0]->{'streams'};
		$log->info("STATION sourceurls $title ". Dumper(\$sourceurls));

# Note each URL seen to make list of unique URLs as there may be repeats in streamUrls
		my %seen;
		
		foreach my $stream (@{$sourceurls}) {
			if (!exists($seen{$stream->{'url'}})) {
				
				my $format = ($stream->{'url'} =~m/^https:\/\//) ? 'secure ' : undef;
				$format =  ($format . $stream->{'contentFormat'}) if (defined ($stream->{'contentFormat'}) ); 
				$format = " ($format)" if (defined($format));
				
				$seen{$stream->{'url'}} = 1;
						
				push @menu, { 
					'name'        => $title . $format,
					'image'		  => $icon,
					'type'        => 'audio',
					'url'         => $stream->{'url'},
					'on_select'   => 'play',
					'description' => $desc,
				};
			}
		}

        $log->info(" Dump menu ".Dumper(\@menu));
		return \@menu;
		
	}

#  For podcast the streamUrls has the podcast feed.  Most time works wioth LMS Podcast player.
	if ($jsondata->[0]->{'type'} eq 'PODCAST') {
		$log->error(" Podcast player ". Dumper($jsondata));			
	}

#  Not STATION or PODCAST playable type - so return undef.
	return undef;
}


sub parseListMenuReply {
	my $http = shift;
	my $url  = shift;
	
	my ($baseurl,$opts) = getopts($url);
	
	my $pageno =1  ;
	
    my $menu;
    my $stationsmatched;
    my $totalpages;
    
    if ($url =~ m/&|\?p=(\d+)/) {
		$pageno = $1;
    };
# $log->error(" Dump ".Dumper($http));

     my @keywords = qw(station messages);
#     $log->error(" Dump ".Dumper($http));

     my $jsondata = parseWebPage($http, \@keywords );
     
# Message shoudl be in the first chunk            
     my $messagechunk = $jsondata->[0];
     if (!defined ($messagechunk->{'messages'})) {
           $log->error(" Errors - locale messages not found in first chunk of Radio.net home page ");
           return;
     }

# Walk the chunk to find the locales "messages"
     my $messages = findJSONItem($messagechunk,'messages');     
#    $log->error(" Dump list reply messages ".Dumper(\$messages->{'messages'}));

# list with tags shoudl be in the first chunk            
      my $listchunk = $jsondata->[1];
      if (!defined ($listchunk->{'station'})) {
                $log->error(" Errors - list station not found in first chunk of Radio.net page ");
                return;
            };
# Walk the chunk to find the hash with stations - very messy
     my $stationslist = findStationsJSON($listchunk,'station');
     my $stationscount = scalar(@{$stationslist->{'stations'}});
     $log->info(" Dump $stationscount stations ".Dumper($stationslist));

	my $totalCount     = int ($stationslist->{'totalCount'});
    my $currentPage    = int ($stationslist->{'currentPage'});
    my $perPage        = int($stationslist->{'perPage'}) ;
    
    $perPage = $stationscount unless ($perPage > 0);
	
	my $totalpages = 1;
	if ($totalCount > $perPage) {
		$totalpages = int(($totalCount + ($perPage - 1))/ $perPage); # Round up to get number of pages available
	}

	$menu = makeStationsMenu($stationslist->{'stations'});
	$log->info(" Menu ". Dumper(@$menu));

#  Having processed all items - if Page 1 of genre then add menus for other pages in same genre.  
#  First find out how many pages.

	if ($pageno == 1) {
		for (my $i = 2; $i <= $totalpages; $i++) { 
			push @$menu, {
				'name'	      => "Page $i of $totalpages",
				'url'         => '',
				'type'        => 'link',	
				'passthrough' => [ { 'url' => $baseurl ."?p=$i", 'pageno' => $i,
									'codeRef'     => 'getPagedLists'}	],
			};	
		}
	}

# All done 
	if (scalar @$menu == 0) {
		push @$menu , {
			'name'	      => 'No stations found',
		} ;
	}

	# return menu
	$log->debug("Dump of menu ". Dumper($menu));
	return $menu ;
}

sub makePlayablesMenu {

	my $stations   = shift;
	my @menu;

	foreach my $station (@{$stations}) {
		
		my $stationname = $station->{'name'};
		next unless defined ($stationname);

		my $stationtype = $station->{'type'};
		my $stationdesc = makestationdesc($station);
		my $stationlogo = getstationlogo($station);		
		

#  If stations 'playable' is TRUE then it has streams of valid URLs
#  otherwise just a stationID which will be used later to get playable URL

#      $log->error(" Name=$stationname TYpe=$stationtype Desc=$stationdesc  ValidStreams=>>".$station->{'hasValidStreams'}."<<");
       if ( $station->{'hasValidStreams'}) { 
            my $stationurl = $station->{'streams'}[0]->{'url'};
            push @menu, {
				'name'	      => $stationname . $stationdesc,
				'image'       => $stationlogo,
				'icon'        => $stationlogo,
				'url'         => $stationurl ,
				'description' => $stationdesc,
				'on_select'   => 'play',
				'type'        => 'audio',	
            };
        }
    }

# All done 
	if (scalar @menu == 0) {
		push @menu , {
			'image'		  => undef ,
			'name'	      => 'No programs found',
			'type'        => 'text',	
		} ;
	}

	$log->info("Dump of menu ". Dumper(\@menu));
	return \@menu;
}

sub makeStationsMenu {
	my $stations = shift;

	my @menu;
	
	foreach my $station (@{$stations}) {
		
		my $stationname = $station->{'name'};
		next unless defined ($stationname);

		my $stationtype = $station->{'type'};
		my $stationdesc = makestationdesc($station);
		my $stationlogo = getstationlogo($station);		
		

#  If stations 'playable' is TRUE then it has streams of valid URLs
#  otherwise just a stationID which will be used later to get playable URL
		
		if ($stationtype eq 'STATION' ) {
			push @menu, {
				'name'	      => $stationname . $stationdesc,
				'image'       => $stationlogo,
				'icon'        => $stationlogo,
				'url'         => '' ,
				'type'        => 'link',	
				'passthrough' => [
								{	'stationurl'  => 'https://prod.radio-api.net/stations/details?stationIds='. $station->{'id'} ,                
									'stationlogo' => $stationlogo,
									'codeRef' 	  => 'getStationURLs'}
								],
			};
		} else { 		# otherwise assume it is PODCAST
				push @menu, {
					'name'	      => "$stationname (podcast) $stationdesc",
					'image'       => $stationlogo,
					'icon'        => $stationlogo,
					'url'         => '' ,
					'type'        => 'link',	
					'passthrough' => [
									{	'podcastid' 	=> $station->{'id'},
										'stationlogo'	=> $stationlogo,
										'codeRef' 		=> 'getPodcastURLs'}
									],
					};
		};
	}

# All done 
	if (scalar @menu == 0) {
		push @menu , {
			'image'		  => undef ,
			'name'	      => 'No programs found',
			'type'        => 'text',	
		} ;
	}

	$log->debug("Dump of menu ". Dumper(\@menu));
	return \@menu;    
    
}


# This reply has multiple stations - there could be multiple URLS but only first used - FIXUP
# Unusual this reply is in JSOn so have to add source type to help parsing routines
sub parseStreamsReply {
	
	my $jsoncontent = shift;
	my $jsondata = eval { from_json($jsoncontent) };
	
	if ($@) {
		$log->error("Error parsing JSON data $@");
		return;
	}

	my $menu     = makePlayablesMenu($jsondata->{'playables'},'localstations');
	
	return $menu;
}


sub makestationdesc {
	my $station     = shift;
	my $stationdesc = ' (';
	
# Check which form of station record - matched ones have a HASH with 'value' whereas others have just a string. 	
	
	if (ref($station->{'name'}) eq 'HASH' ) {
		$stationdesc .=  $station->{'city'}->{'value'} . ', ' if defined($station->{'city'}->{'value'}); 
		$stationdesc .=  $station->{'country'}->{'value'} ;
		
		if (defined ($station->{'genres'}[0]->{'value'})) {
			my $genrelist;
			foreach my $entry (@{$station->{'genres'}}) {
				$genrelist .= $entry->{'value'} .',';
			}
			chop $genrelist ; # remove last comma;
			$stationdesc .= '/'.$genrelist;
		};
		
	} else {
		$stationdesc .=  $station->{'city'} ;
        $stationdesc .=  ', ' if (($stationdesc ne '') && defined ($station->{'country'}));
		$stationdesc .=  $station->{'country'} ;
		$stationdesc .= ' / '. join(', ',@{$station->{'genres'}}) if (defined ($station->{'genres'}));
	}
	
	$stationdesc .= ')' ;

	return $stationdesc;
}


sub getstationlogo {
	my $station = shift;
	my $stationlogo =  $station->{'logo300x300'} ?  $station->{'logo300x300'} 
					 : $station->{'logo100x100'} ?  $station->{'logo100x100'} 
					 : $station->{'logo630x630'} ?  $station->{'logo630x630'} 
					 : $station->{'logo175x175'} ?  $station->{'logo175x175'} 
					 : Plugins::RadioNet::Plugin->_pluginDataFor('icon') ;

	return $stationlogo;
}


sub findStationsJSON {
    my $jsonchunk  = shift;
    my $searchtag = shift;

    my %stations_reply;

#
# Get details of station on page

#
    my $pagedetails = findJSONItem($jsonchunk,'totalCount');
    
    $stations_reply{'currentPage'} = $pagedetails->{'currentPage'};
    $stations_reply{'perPage'}     = $pagedetails->{'perPage'};
    $stations_reply{'totalCount'}  = $pagedetails->{'totalCount'};
   
    my $jsondata;
    if (      defined ($jsonchunk->{'Type1-r'})) {
        $jsondata = $jsonchunk->{'Type1-r'} ;
    } elsif ( defined ($jsonchunk->{'Type1-x'})) {
        $jsondata = $jsonchunk->{'Type1-x'} ;
    } elsif ( defined ($jsonchunk->{'Type2-x'})) {
        $jsondata = $jsonchunk->{'Type2-x'};
    };
 
    
# Traverse the JSON data looking for 
# 'className' => 'flex flex-wrap md:justify-between',
#
# Stations are located a few levels deeper children->children->Children
    my @todo = [ $jsondata ];
    my $stationroot;
    
OUTER: while (@todo) {
        my ($val, @path) = @{ shift(@todo) };
        my $reftype = ref($val);
        if (!$reftype) {
           # Nothing to do
        }
        elsif ($reftype eq 'HASH') {
           for my $key (keys(%$val)) {
#              $log->error("className = ".$val->{$key}) if ($key eq 'className');
              if ($key eq 'className'  && $val->{$key} eq 'flex flex-wrap md:justify-between' ) {
                    $stationroot = $val;
                    last OUTER;
              };
              push @todo, [ $val->{$key}, @path, $key ];
           }
        }
        elsif ($reftype eq 'ARRAY') {
           for my $i (0..$#$val) {
              push @todo, [ $val->[$i], @path, $i ];
           }
        }
        else {
           $log->error("- FindJSONItem Invalid data.");
        }
    } ;

    if (!defined($stationroot)) {
     $log->error(" Stationroot is empty");   
     return;
    }

    if (ref($stationroot) ne 'HASH') {
     $log->error(" Stationroot is not HASH");   
     return;
    }

    if (!exists ($stationroot->{'children'}) && (!defined ($stationroot->{'children'}) )) {
     $log->error(" Stationroot does not have a defined children key ");   
     return;
    }
    
#
#  Descend the list until statiosns list is found
# 
    my $p = $stationroot->{'children'};
    if (ref($p) ne 'ARRAY') {
        $log->error(" Station root expected an array");   
        return;
    }
    
    $p = $p->[0];
    if (ref($p) ne 'ARRAY') {
        $log->error(" Station root [0] expected an array");   
        return;
    }

    while(defined($p)) {
        if (ref($p->[0]) eq 'ARRAY') {
            my $station = $p->[0];
            last;
        };
        
        if ((ref($p->[3]) eq 'HASH') && (defined($p->[3]->{'children'}))) {
            $p = $p->[3]->{'children'}  
        } else {
            $p = undef;   
        }
    };
    
    return if (! defined($p));

#  Copy each station detail over into the suumary reply.

    foreach my $item (@$p) {
        push @{$stations_reply{'stations'}}, $item->[3]->{'station'};
    }

    $log->info(" Dump of station reply \n".Dumper(\%stations_reply));
    return \%stations_reply;
}   


sub findJSONItem {
    my $jsonchunk  = shift;
    my $searchtag = shift;
    
    my $jsondata;
    if (      defined ($jsonchunk->{'Type1-r'})) {
        $jsondata = $jsonchunk->{'Type1-r'} ;
    } elsif ( defined ($jsonchunk->{'Type1-x'})) {
        $jsondata = $jsonchunk->{'Type1-x'} ;
    } elsif ( defined ($jsonchunk->{'Type2-x'})) {
        $jsondata = $jsonchunk->{'Type2-x'};
    };
    
# Travers the JSON data looking for search tag as keyword.
    my @todo = [ $jsondata ];
#    $log->error(" Lokking in ".Dumper(\@todo));
    
    while (@todo) {
        my ($val, @path) = @{ shift(@todo) };
        my $reftype = ref($val);
        if (!$reftype) {
           # Nothing to do
        }
        elsif ($reftype eq 'HASH') {
           for my $key (keys(%$val)) {
              if ($key eq $searchtag ) {
#                    $log->error(" Dump $searchtag \n". Dumper(\$val->{$key}));  
#                    $log->error(" Dump path ".Dumper(\@path));
                    return $val;
              };

              push @todo, [ $val->{$key}, @path, $key ];
           }
        }
        elsif ($reftype eq 'ARRAY') {
           for my $i (0..$#$val) {
              push @todo, [ $val->[$i], @path, $i ];
           }
        }
        else {
           $log->info("- FindJSONItem unbknown ref \"$reftype\"");
        }
    }
#  Didn't find anything     
    return ;
}   
    

sub getDisplayName { 'PLUGIN_RADIONET' }

sub playerMenu { shift->can('nonSNApps') && $prefs->get('is_app') ? undef : 'RADIO' }

1;
